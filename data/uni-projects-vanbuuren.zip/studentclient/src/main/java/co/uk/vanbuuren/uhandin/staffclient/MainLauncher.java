package co.uk.vanbuuren.uhandin.staffclient;

import java.rmi.RemoteException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.uk.vanbuuren.uhandin.commons.Client;
import co.uk.vanbuuren.uhandin.commons.Directory;

public class MainLauncher {

	private static final Logger logger = LoggerFactory.getLogger(MainLauncher.class);
	
	public static void main(String[] args) throws Exception {
		if(args.length > 0) {
			try {
				Directory.setupStoreDirectory();
				Client client = new ClientImpl(args[0]);
				@SuppressWarnings("unused")
				Launcher launcher = new Launcher(client);
			} catch (SecurityException se) {
				logger.info("Access to the AppData folder is denied. Please set folder permissions.", se);
			} catch (RemoteException re) {
				logger.error("Remote Exception.",re);
			}
		} else {
			logger.info("Syntax for startup is: ClientImpl <nameServer>, Stopping.");
			logger.error("Args[0] has not been set.");
		}
	}
}
