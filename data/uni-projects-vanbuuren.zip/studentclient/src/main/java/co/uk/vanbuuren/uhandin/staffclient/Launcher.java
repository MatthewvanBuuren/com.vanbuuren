package co.uk.vanbuuren.uhandin.staffclient;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.rmi.RemoteException;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.uk.vanbuuren.uhandin.commons.Assignment;
import co.uk.vanbuuren.uhandin.commons.Client;
import co.uk.vanbuuren.uhandin.commons.FormValidation;
import co.uk.vanbuuren.uhandin.commons.LoginResult;
import co.uk.vanbuuren.uhandin.commons.Module;
import co.uk.vanbuuren.uhandin.commons.Person;
import co.uk.vanbuuren.uhandin.commons.TwoReturnValue;
import co.uk.vanbuuren.uhandin.commons.UserType;
import java.awt.CardLayout;
import java.awt.Component;
import javax.swing.AbstractListModel;
import javax.swing.border.BevelBorder;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPopupMenu;

public class Launcher {

	private static final Logger logger = LoggerFactory.getLogger(Launcher.class);
	
	private JFrame frame;
	
	private JPasswordField passwordField;
	private JTextField usernameField;
	private JLabel lblResult;
	
	private JPanel pnlMain = new JPanel();
	private JPanel pnlLogin;
	private JPanel pnlMainMenu;
	
	private JPopupMenu popupAddModule;
	
	private JList<Module> moduleList;
	private JList<Assignment> assignmentList;
	
	private Person person;

	
	private final Client client;
	private JTextField txtModuleCode;

	/**
	 * Create the application.
	 */
	public Launcher(Client client) {
		this.client = client;
		initialize();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame.setVisible(true);
				} catch (Exception e) {
					logger.error("", e);
				}
			}
		});
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("src/main/resources/images/U-HandIn.gif"));
		frame.setBounds(100, 100, 1280, 720);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		/* ---------------MenuBar---------------------------*/
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenu menuFile = new JMenu("File");
		menuBar.add(menuFile);
		
		JSeparator fileSeparator = new JSeparator();
		menuFile.add(fileSeparator);
		
		JMenuItem menuItemExit = new JMenuItem("Exit");
		menuFile.add(menuItemExit);
		
		JMenu menuHelp = new JMenu("Help");
		menuBar.add(menuHelp);
		
		JMenuItem menuItemHelp = new JMenuItem("UHand-In Help");
		menuHelp.add(menuItemHelp);
		
		JSeparator helpSeperator = new JSeparator();
		menuHelp.add(helpSeperator);
		
		JMenuItem menuItemAbout = new JMenuItem("About UHand-In");
		menuHelp.add(menuItemAbout);
		frame.getContentPane().setLayout(null);
		
		pnlMain = new JPanel();
		pnlMain.setBounds(0, 0, 1262, 630);
		frame.getContentPane().add(pnlMain);
		pnlMain.setLayout(new CardLayout(0, 0));
		pnlLogin = new JPanel();
		pnlMain.add(pnlLogin);
		pnlLogin.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JLabel lblUsername = new JLabel("Username:");
		pnlLogin.add(lblUsername);
		
		usernameField = new JTextField();
		pnlLogin.add(usernameField);
		usernameField.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password:");
		pnlLogin.add(lblPassword);
		
		passwordField = new JPasswordField();		
		passwordField.setColumns(10);
		pnlLogin.add(passwordField);
		
		JButton btnLogin = new JButton("Log In");
		pnlLogin.add(btnLogin);
		
		pnlMainMenu = new JPanel();
		pnlMain.add(pnlMainMenu, "name_6073629367466");
		pnlMainMenu.setLayout(new BorderLayout(0, 0));
		
		JPanel pnlLists = new JPanel();
		pnlMainMenu.add(pnlLists, BorderLayout.WEST);
		pnlLists.setLayout(new BorderLayout(0, 0));
		
		JPanel pnlListsWrapper = new JPanel();
		pnlLists.add(pnlListsWrapper, BorderLayout.WEST);
		pnlListsWrapper.setLayout(new BorderLayout(0, 0));
		
		moduleList = new JList<Module>();
		pnlListsWrapper.add(moduleList, BorderLayout.NORTH);
		moduleList.setValueIsAdjusting(true);
		moduleList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		
		assignmentList = new JList<Assignment>();
		pnlListsWrapper.add(assignmentList, BorderLayout.SOUTH);
		assignmentList.setValueIsAdjusting(true);
		assignmentList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		
		JSeparator sepLists = new JSeparator();
		sepLists.setPreferredSize(new Dimension(2, 0));
		sepLists.setMinimumSize(new Dimension(2, 0));
		sepLists.setOrientation(SwingConstants.VERTICAL);
		pnlMainMenu.add(sepLists, BorderLayout.CENTER);
		
		JPanel pnlAssignment = new JPanel();
		pnlMainMenu.add(pnlAssignment, BorderLayout.EAST);
		pnlAssignment.setLayout(new BorderLayout(0, 0));
		
		popupAddModule = new JPopupMenu();
		popupAddModule.setLabel("Add Module");
		pnlAssignment.add(popupAddModule, BorderLayout.NORTH);
		
		JPanel pnlModuleForm = new JPanel();
		popupAddModule.add(pnlModuleForm);
		
		JLabel lblModuleCode = new JLabel("Module Code: ");
		pnlModuleForm.add(lblModuleCode);
		
		txtModuleCode = new JTextField();
		pnlModuleForm.add(txtModuleCode);
		txtModuleCode.setColumns(10);
		
		JButton btnFormAddModule = new JButton("Apply");
		pnlModuleForm.add(btnFormAddModule);
		
		JPanel pnlControls = new JPanel();
		pnlMainMenu.add(pnlControls, BorderLayout.SOUTH);
		pnlControls.setLayout(new BorderLayout(0, 0));
		
		JSeparator sepControl = new JSeparator();
		pnlControls.add(sepControl, BorderLayout.NORTH);
		
		JPanel pnlControlsWrapper = new JPanel();
		pnlControls.add(pnlControlsWrapper);
		
		JButton btnAddModule = new JButton("Add Module");
		pnlControlsWrapper.add(btnAddModule);
		
		JButton btnRegisterStudent = new JButton("Register Student(s)");
		pnlControlsWrapper.add(btnRegisterStudent);
		
		JButton btnRegisterStaff = new JButton("Register Staff");
		pnlControlsWrapper.add(btnRegisterStaff);
		
		JButton btnCreateGroups = new JButton("Create Group(s)");
		pnlControlsWrapper.add(btnCreateGroups);
		
		JButton btnAssignStudent = new JButton("Assign Student(s)");
		pnlControlsWrapper.add(btnAssignStudent);
		
		JButton btnAssignGroups = new JButton("Assign Group(s)");
		pnlControlsWrapper.add(btnAssignGroups);
		
		JButton btnAssignstaff = new JButton("AssignStaff");
		pnlControlsWrapper.add(btnAssignstaff);
		
		//Listeners
		passwordField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				int key = e.getKeyCode();
				if (key == KeyEvent.VK_ENTER) {
					lblResult.setText(onRegister());
				}
			}
		});
		
		usernameField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				int key = e.getKeyCode();
				if (key == KeyEvent.VK_ENTER) {
					lblResult.setText(onRegister());
				}
			}
		});
		
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lblResult.setText(onRegister());
			}
		});
		
		btnAddModule.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				popupAddModule.show(e.getComponent(), frame.getX(), frame.getY());
			}
		});
		
		btnFormAddModule.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				//client.addModule(txtModuleCode);;
				popupAddModule.setVisible(false);
			}
		});
		
		JPanel pnlStatus = new JPanel();
		pnlStatus.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		pnlStatus.setBounds(0, 630, 1264, 30);
		pnlStatus.setAlignmentY(Component.BOTTOM_ALIGNMENT);
		frame.getContentPane().add(pnlStatus);
		pnlStatus.setLayout(new BorderLayout(0, 0));
		
		JPanel pnlResult = new JPanel();
		FlowLayout flowLayout = (FlowLayout) pnlResult.getLayout();
		flowLayout.setHgap(10);
		flowLayout.setVgap(0);
		pnlStatus.add(pnlResult, BorderLayout.CENTER);

		
		lblResult = new JLabel("Please enter username and password.");
		lblResult.setHorizontalAlignment(SwingConstants.CENTER);
		pnlResult.add(lblResult);
		lblResult.setAlignmentX(Component.CENTER_ALIGNMENT);
		lblResult.setFont(UIManager.getFont("ToolTip.font"));
	}
	
	private String onRegister() {
		if(usernameField.getText() == null || usernameField.getText().length() == 0) {
			lblResult.setForeground(new Color(220, 20, 60));
			return "Please enter a username.";
		} else if(passwordField.getPassword() == null || passwordField.getPassword().length == 0) {
			return "Please enter a password.";
		} else if(!FormValidation.validUsername(usernameField.getText())){
			//Avoids SQL Injection attacks.
			lblResult.setForeground(new Color(220, 20, 60));
			return "The username given must use syntax username@staff or username@student.";
		} else {
			TwoReturnValue<LoginResult, String> loginResult = null;
			String[] breakdown = FormValidation.breakdownUsername(usernameField.getText());
			try {
				 loginResult = client.register(usernameField.getText(), String.valueOf(passwordField.getPassword()));
			} catch (RemoteException re) {
				logger.error("", re);
				lblResult.setForeground(new Color(220, 20, 60));
				return "A communication error has occured, Please try again later.";
			}
			if(loginResult.getFirst().equals(LoginResult.PASSED)) {
				lblResult.setForeground(new Color(0, 0, 0));
				UserType userType = UserType.STUDENT;
				if(breakdown[1].equalsIgnoreCase(UserType.STAFF.getValue())) {
					userType = UserType.STAFF;
				}
				CardLayout cl = (CardLayout)(pnlMain.getLayout());
				cl.next(pnlMain);
				createModulePanel();
				person = new Person(breakdown[0], loginResult.getSecond(), userType);
				return "Welcome, " + loginResult.getSecond();
			} else if(loginResult.getFirst().equals(LoginResult.FAILED)) {
				lblResult.setForeground(new Color(220, 20, 60));
				return "Incorrect credentials.";
			} else if(loginResult.getFirst().equals(LoginResult.UNABLETOVERIFY)) {
				lblResult.setForeground(new Color(220, 20, 60));
				return "There is an error preventing authentication on the server, Please contact an admin.";
			} else if(loginResult.getFirst().equals(LoginResult.INCORRECTSYNTAX)) {
				lblResult.setForeground(new Color(220, 20, 60));
				return "The username given must use syntax username@staff or username@student.";
			}
		}
		lblResult.setForeground(new Color(220, 20, 60));
		return "An error has occured, Please contact an admin.";
	}
	
	private void createModulePanel() {
		try {
			moduleList.setModel(new AbstractListModel<Module>() {
				private static final long serialVersionUID = 1L;
				
				List<Module> values = client.getRegisteredModules();
				public int getSize() {
					return values.size();
				}
				public Module getElementAt(int index) {
					return values.get(index);
				}
			});
			
			// Module selection listener
			moduleList.addListSelectionListener(new ListSelectionListener() {
				@Override
				public void valueChanged(ListSelectionEvent e) {
					if(!e.getValueIsAdjusting()) {
						createAssignmentPanel(moduleList.getSelectedValue());
					}
				}
			});	
		} catch (RemoteException re) {
			logger.error("", re);
		}
	}

	private void createAssignmentPanel(final Module module) {
		try {
			assignmentList.setModel(new AbstractListModel<Assignment>() {
				private static final long serialVersionUID = 1L;
				
				List<Assignment> values = client.getAssignmentsForModule(module);
				public int getSize() {
					return values.size();
				}
				public Assignment getElementAt(int index) {
					return values.get(index);
				}
			});
			
			// Assignment selection listener
			assignmentList.addListSelectionListener(new ListSelectionListener() {
				@Override
				public void valueChanged(ListSelectionEvent e) {
					if(!e.getValueIsAdjusting()) {
						
					}
				}
			});	
		} catch (RemoteException re) {
			logger.error("", re);
		}
	}
}
