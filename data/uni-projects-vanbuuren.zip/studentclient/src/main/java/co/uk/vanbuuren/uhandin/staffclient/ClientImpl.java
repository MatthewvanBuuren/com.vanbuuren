package co.uk.vanbuuren.uhandin.staffclient;
import co.uk.vanbuuren.uhandin.commons.*;
import co.uk.vanbuuren.uhandin.commons.security.EncryptionMethods;
import co.uk.vanbuuren.uhandin.commons.security.KeyManagement;

import java.io.File;
import java.io.IOException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClientImpl extends UnicastRemoteObject implements Client
{

	private static final Logger logger = LoggerFactory.getLogger(ClientImpl.class);
	private static final long serialVersionUID = 1L;
	
	private static final String SERVER_NAME = "Central-Server";
	private Server server;
	private PublicKey serverPubKey = null;
	
	private final EncryptionMethods encryptionMethods = new EncryptionMethods();
	
	private Person thisPerson;
	
	public ClientImpl(String host) throws RemoteException {
		super();
		try {
			server = (Server) Naming.lookup("rmi://" + host + "/" + SERVER_NAME);
			logger.info("Found Server " + host + ".");
     	
			serverPubKey = KeyManagement.getPublicKey("public.key");

			//TODO : Move to another/client class for key generation.
     		//KeyPairGenerator kpg = KeyPairGenerator.getInstance(ASymmetricEncryption.KEY_ALGORITHM.getValue());
     		//kpg.initialize(Integer.valueOf(ASymmetricEncryption.KEY_SIZE.getValue()));
     		//KEYS = kpg.genKeyPair();
    
		} catch(IOException ioe) {
			logger.error("", ioe);
		} catch (NotBoundException nbe) {
			logger.error("", nbe);
		}
	}
	
	public Server getServer() {
		return this.server;
	}
	
	public TwoReturnValue<LoginResult, String> register(String uid, String password) throws RemoteException {
		try {
			TwoReturnValue<LoginResult, String> result = server.register(this, encryptionMethods.encryptString(uid, serverPubKey), encryptionMethods.encryptString(password, serverPubKey));
			if(result.getFirst().equals(LoginResult.PASSED)) {
				String[] breakdown = FormValidation.breakdownUsername(uid);
				UserType userType = UserType.STUDENT;
				if(breakdown[1].equalsIgnoreCase(UserType.STAFF.getValue())) {
					userType = UserType.STAFF;
				}
				thisPerson = new Person(breakdown[0], result.getSecond(), userType);
			}
			return result;
		} catch(RemoteException re) {
			logger.error("", re);
			return new TwoReturnValue<LoginResult, String>(LoginResult.UNABLETOVERIFY, "");
		}
	}
	
	public void sendAssignment(File assignment) throws RemoteException {
		String string = new String("Hello, Im a string about to be encrypted.");
		EncryptionMethods encryptionMethods = new EncryptionMethods();
		try {
			encryptionMethods.getMD5DigestString(string.getBytes());
		} catch (NoSuchAlgorithmException nsae) {
			logger.error("", nsae);
		}
	}
	
	public List<Module> getRegisteredModules() {
		List<Module> allModules = null;
		try {
			allModules = server.getRegisteredModules(thisPerson);
		} catch(RemoteException re) {
			logger.error("", re);
		}
		return allModules;
	}
	
	public List<Assignment> getAssignmentsForModule(Module module) {
		List<Assignment> allAssignments = null;
		try {
			allAssignments = server.getAssignmentsForModule(module, thisPerson);
		} catch(RemoteException re) {
			logger.error("", re);
		}
		return allAssignments;
	}
}
