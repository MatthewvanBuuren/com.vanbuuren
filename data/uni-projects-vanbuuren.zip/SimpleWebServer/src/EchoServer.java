import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

public class EchoServer {
	public static void main(String args[]) {
		
		int LISTEN_PORT = 80;
		String serverDirectory = ".\\www";

		FileOutputStream out;
		PrintStream printStream = null;
		
		try {
			out = new FileOutputStream("log.txt",true);
			printStream = new PrintStream(out);

			if(args.length > 0) {
				LISTEN_PORT = Integer.valueOf(args[0]);
			}
			if(args.length > 1) {
				serverDirectory = args[1];
			}
			File file = new File(serverDirectory);
			boolean exists = file.exists();
			if (!exists) {
				file.mkdir();
				//Output request to console. To be commented out before submission.
				//System.out.println("Directory '" + serverDirectory + "' Created");
			}

			ServerSocket serverSock = new ServerSocket(LISTEN_PORT);
			while(true) {
				Socket connSock = serverSock.accept();
				ServiceThread serve = new ServiceThread(connSock,printStream);
				serve.start();
			}
		} catch (IOException e) {
			System.err.println("EchoServer: error on socket");
			System.exit(1);
		} finally {
			if(printStream != null) {
				printStream.close();
			}
		}
	}
}

class ServiceThread extends Thread {

	private static final String TIME_PATTERN_RESPONSE= "E, MM MMM y H:m:s zz";
	private static final String TIME_PATTERN_LOG= "dd/MMM/y:H:m:s Z";

	private String serverDirectory = "." + File.separator + "www";

	public String getTimeDate(long date, String pattern) {
		Date longDate = new Date(date);
		SimpleDateFormat formatter =
				(SimpleDateFormat)DateFormat.getDateTimeInstance(DateFormat.LONG,
						DateFormat.LONG, Locale.UK);

		formatter.applyPattern(pattern);

		String result = formatter.format(longDate);
		return result;
	}
	
	public String getTimeDate(String pattern) {
		Calendar calendar = Calendar.getInstance();
		Date date = calendar.getTime();

		SimpleDateFormat formatter =
				(SimpleDateFormat)DateFormat.getDateTimeInstance(DateFormat.LONG,
						DateFormat.LONG, Locale.UK);

		formatter.applyPattern(pattern);

		String result = formatter.format(date);
		return result;
	}

	private final PrintStream printStream;

	private final Socket connectionSocket;



	public ServiceThread(Socket socket, PrintStream printStream) {
		connectionSocket = socket;
		this.printStream = printStream;
	}

	private String constructHeader(int responseCode, int fileType, List<String> optionalHeaders) {
		String response = "HTTP/1.0 ";
		switch (responseCode) {
		case 200:
			response = response + "200 OK";
			break;
		case 400:
			response = response + "400 Bad Request";
			break;
		case 404:
			response = response + "404 Not Found";
			break;
		case 501:
			response = response + "501 Not Implemented";
			break;
		}
		response = response + "\r\n"; //other header fields,

		//2.8 Always return 'Date:'
		response = response + "Date: " + getTimeDate(TIME_PATTERN_RESPONSE) + "\r\n";

		//2.9 Always return 'Date:'
		if(optionalHeaders.size() > 0) {
			response = response + optionalHeaders.get(0);
		}

		//Last-Modified: Fri, 22 Sep 2000 14:16:18

		//2.2 Always sends 'Connection: close'.
		response = response + "Connection: close\r\n";



		//2.7.2 Returns correct content type.
		switch (fileType) {
		case 0:
			response = response + "Content-Type: text/html\r\n";
			break;
		case 1:
			response = response + "Content-Type: text/css\r\n";
			break;
		case 2:
			response = response + "Content-Type: image/jpeg\r\n";
			break;
		case 3:
			response = response + "Content-Type: image/gif\r\n";
			break;
		case 4:
			response = response + "Content-Type: image/png\r\n";
			break;
		case 5:
			response = response + "Content-Type: text/plain\r\n";
			break;
		}

		if(optionalHeaders.size() > 1) {
			response = response + optionalHeaders.get(1);
		}
		response = response + "\r\n\r\n";

		return response;
	}

	private void handleRequest(InetAddress client, Scanner input, OutputStream output) throws IOException {
		//Method types 0=Incorrect 1=GET 2=HEAD 3=FileNotFound 9=NotSupported
		int methodType = 9;
		//File types 0=Default Html or Text 1=Css 2=Jpeg 3=Gif 4=Png 5=Txt
		int fileType = 0;
		File file = null;
		String logFirstLine = "", logHost = "", logMachine = "";

		boolean HTTP11 = false;

		ArrayList<String> currentRequest = new ArrayList<String>(20);
		String line;
		while (true) {
			line = input.nextLine();
			if(line.length()==0) {
				break;
			}
			//Output request to console. To be commented out before submission.
			//System.out.println(line);
			currentRequest.add(line);
		}

		String[] firstLine = currentRequest.get(0).split(" ");
		logFirstLine = "\"" + currentRequest.get(0) + "\"";

		//2.1 Check for '/'.
		if(firstLine[1].startsWith("/") && firstLine[1].length() > 1) {
			//File request.
			file = new File(serverDirectory + File.separator + firstLine[1].substring(1).replaceAll("%20", " "));
			if (firstLine[1].endsWith(".css")) {
				fileType = 1;
			}
			if (firstLine[1].endsWith(".jpeg") || firstLine[1].endsWith(".jpg")) {
				fileType = 2;
			}
			if (firstLine[1].endsWith(".gif")) {
				fileType = 3;
			}
			if (firstLine[1].endsWith(".png")) {
				fileType = 4;
			}
			if (firstLine[1].endsWith(".txt")) {
				fileType = 5;
			}
			if (file.isDirectory()) {
				File index1 = new File(serverDirectory + File.separator + firstLine[1].substring(1).replaceAll("%20", " ") + File.separator + "index.html");
				File index2 = new File(serverDirectory + File.separator + firstLine[1].substring(1).replaceAll("%20", " ") + File.separator + "index.htm");

				//2.10 Preferance is on .html file over .htm but if either exists return.
				if(index2.exists()) {
					file = index2;
				}
				if(index1.exists()) {
					file = index1;
				}
			}
			if(!file.exists()){
				methodType = 3;
			}
		} else if(!firstLine[1].startsWith("/")) {
			methodType = 0;
		}
		if (firstLine[1].startsWith("/") && firstLine[1].length() == 1) {

			File index1 = new File(serverDirectory + File.separator + firstLine[1].substring(1).replaceAll("%20", " ") + File.separator + "index.html");
			File index2 = new File(serverDirectory + File.separator + firstLine[1].substring(1).replaceAll("%20", " ") + File.separator + "index.htm");
			file = index1;

			//2.10 Preferance is on .html file over .htm but if either exists return.
			if(index2.exists()) {
				file = index2;
			}
			if(index1.exists()) {
				file = index1;
			}
			if(!index1.exists() && !index2.exists()){
				methodType = 3;
			}
		}

		//Assumption that the first line is the request type.
		//2.4 Deals with HEAD AND GET.
		if(!(methodType == 0) && firstLine[0].trim().equals("GET")) {
			methodType = 1;
		}
		if(!(methodType == 0) && firstLine[0].trim().equals("HEAD")) {
			methodType = 2;
		}
		//2.3 Returns 501 if not GET or HEAD.
		if(!(methodType == 0) && !firstLine[0].trim().equals("HEAD") && !firstLine[0].trim().equals("GET")) {
			methodType = 9;
		}

		if(!(methodType == 0) && !(firstLine[2].equals("HTTP/1.1") || firstLine[2].equals("HTTP/1.0"))) {
			//Http protocol versions supported "HTTP:/1.0" and "HTTP:/1.1"
			methodType = 9;
		}

		if(!(methodType == 0) && firstLine[2].equals("HTTP/1.1")) {
			HTTP11 = true;
		}

		boolean containsHost = false;
		//Loop through the remaining lines, If request method is recognized.
		//To do other functions, Right now it does nothing
		for(int index = 1 ; index < currentRequest.size() ; index++) {
			String part = currentRequest.get(index);
			if(part.contains("Host:")) {
				containsHost = true;
				logHost = "\"" + part.substring(6) + "\"";
			}
			if(part.contains("User-Agent: ")) {
				logMachine = part.substring(12);
			}
		}

		//2.5 Protocol 'HTTP/1.1' but not 'Host:' line return 400.
		if(HTTP11 && !containsHost && methodType != 3) {
			methodType = 0;
		}

		List<String> additionalHeaders = new ArrayList<String>();

		switch(methodType) {
		case 0:
			output.write(constructHeader(400,fileType, additionalHeaders).getBytes());
			printStream.println(client.getHostAddress() + " - " + getTimeDate(TIME_PATTERN_LOG) + " - " + logFirstLine + " 400 " + logHost + " " + logMachine);
			break;
		case 1:
			if(file != null) {
				//Place to add additional headers for files.
				//2.9 'Last-Modified:' header added.
				additionalHeaders.add("Last-Modified: " + getTimeDate(file.lastModified(), TIME_PATTERN_RESPONSE) + "\r\n");
				//2.7.1 Returns correct content type.
				additionalHeaders.add("Content-Length: " + file.length() + "\r\n");
			}
			output.write(constructHeader(200, fileType, additionalHeaders).getBytes());
			if(file != null) {
				FileInputStream fis = new FileInputStream(file);
				//Size of output byte buffer.
				byte[] pagebuf = new byte[100];
				while (true) {
					pagebuf = new byte[100];
					int ok = fis.read(pagebuf);
					if (ok == -1) {
						fis.close();
						break; //end of file
					}
					output.write(pagebuf);
				}
			}
			printStream.println(client.getHostAddress() + " - " + getTimeDate(TIME_PATTERN_LOG) + " - " + logFirstLine + " 200 " + logHost + " " + logMachine);
			break;
		case 2:
			if(file != null) {
				//Place to add additional headers for files.
				//2.9 'Last-Modified:' header added.
				additionalHeaders.add("Last-Modified: " + getTimeDate(file.lastModified(), TIME_PATTERN_RESPONSE) + "\r\n");
				//2.7.1 Returns correct content type.
				additionalHeaders.add("Content-Length: " + file.length() + "\r\n");
			}
			output.write(constructHeader(200,fileType, additionalHeaders).getBytes());
			printStream.println(client.getHostAddress() + " - " + getTimeDate(TIME_PATTERN_LOG) + " - " + logFirstLine + " 200 " + logHost + " " + logMachine);
			break;
		case 3:
			output.write(constructHeader(404,0, additionalHeaders).getBytes());
			printStream.println(client.getHostAddress() + " - " + getTimeDate(TIME_PATTERN_LOG) + " - " + logFirstLine + " 404 " + logHost + " " + logMachine);
			break;
		case 9:
			output.write(constructHeader(501,0, additionalHeaders).getBytes());
			printStream.println(client.getHostAddress() + " - " + getTimeDate(TIME_PATTERN_LOG) + " - " + logFirstLine + " 501 " + logHost + " " + logMachine);
			break;
		}

		output.close();
	}

	@Override
	public void run() {
		try {
			//Output request to console. To be commented out before submission.
			InetAddress client = connectionSocket.getInetAddress();
			//System.out.println(client.getHostAddress() + " connected to the server.");

			//Open the input connection, Read the stream.
			Scanner input = new Scanner(connectionSocket.getInputStream());
			//Open the output connection.
			OutputStream toClient = connectionSocket.getOutputStream();

			//Seperate processing of request from handling connections.
			handleRequest(client, input, toClient);
			connectionSocket.close();
		} catch(Exception e) {
			printStream.println(e.getMessage());
		}
	}
}



