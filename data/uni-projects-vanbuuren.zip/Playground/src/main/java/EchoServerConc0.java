import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;

public class EchoServerConc0 {

	private static int LISTEN_PORT = 80;
	private static String serverDirectory = ".\\www";

	private static FileOutputStream out;
	private static PrintStream printStream;

	public static void main(String args[]) {

		try {
			out = new FileOutputStream("log.txt",true);
			printStream = new PrintStream(out);

			if(args.length > 0) {
				LISTEN_PORT = Integer.valueOf(args[0]);
			}
			if(args.length > 1) {
				serverDirectory = args[1];
			}
			File file = new File(serverDirectory);
			boolean exists = file.exists();
			if (!exists) {
				file.mkdir();
				//Output request to console. To be commented out before submission.
				//System.out.println("Directory '" + serverDirectory + "' Created");
			}

			ServerSocket serverSock = new ServerSocket(LISTEN_PORT);
			while(true) {
				Socket connSock = serverSock.accept();
				ServiceThread serve = new ServiceThread(connSock,printStream);
				serve.start();
			}
		} catch (IOException e) {
			System.err.println("EchoServer: error on socket");
			System.exit(1);
		} finally {
			if(printStream != null) {
				printStream.close();
			}
		}
	}
}

