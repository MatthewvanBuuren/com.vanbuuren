
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class ZipFunctions {

	public static void zipFiles(List<File> allFiles, File output) {
		try {
			byte[] buffer = new byte[1024];
			FileOutputStream fout = new FileOutputStream(output);
			ZipOutputStream zout = new ZipOutputStream(fout);
			zout.setLevel(9);

			for(File file : allFiles) {
				FileInputStream fin = new FileInputStream(file);
				zout.putNextEntry(new ZipEntry(file.getName()));
				int length;
				while((length = fin.read(buffer)) > 0)
				{
					zout.write(buffer, 0, length);
				}
				zout.closeEntry();
				fin.close();
			}

			zout.close();
		} catch(IOException ioe) {
			System.out.println("IOException :" + ioe);
		}
	}
}