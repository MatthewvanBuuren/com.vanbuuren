


public class StringReplacement {

	public static void main(String[] args) {
		String path = "C:\\Program Files\\Blah\\File.zip";

		path = path.replaceAll("\\\\", "\\\\\\\\");

		path.contains("\\");
	}
}

