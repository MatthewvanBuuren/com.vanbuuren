//Charlie Riddle//08177401//



import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class myServer {
	public static void main(String args[]) throws Exception {
		int port = Integer.parseInt(args[0]);
		ServerSocket serverSock=new ServerSocket(port);
		//System.out.println("Listening on Port: " + (port));
		//System.out.println("Successful");

		FileOutputStream out = new FileOutputStream("log.txt",true);
		PrintStream log = new PrintStream(out);

		//System.out.println("logfile has been ceated");
		while(true) {
			Socket conn = serverSock.accept();
			MyServerThread serverthread = new MyServerThread(conn,log);
			serverthread.start();
		}
	}
}

class MyServerThread extends Thread {
	Socket conn;
	PrintStream log;

	public MyServerThread(Socket c, PrintStream l) { conn = c; log = l; }

	@Override
	public void run () {
		try{
			Scanner scanin = new Scanner(conn.getInputStream());
			String line=null;
			int nlines=0;
			String [] mySource = new String [32];
			int count = 0;

			while (true) {
				line = scanin.nextLine();
				if(line.length()==0) {
					break;
				}
				mySource[count] = line;
				count++;
				nlines = nlines + 1;
				//System.out.println("line "+nlines+": "+line);
				//log.println(nlines+": "+line);
				//System.out.println(scanin);
			}

			OutputStream outs = conn.getOutputStream();

			Scanner scanout = new Scanner(mySource[0]);
			//Scanner scanout = new Scanner(conn.getInputStream());
			//System.out.println(mySource);

			byte [] myPage = new byte[156];

			String command=scanout.next();
			String resource=scanout.next();
			String http=scanout.next();
			String type1="";

			//System.out.println("command is:" + command);
			//System.out.println("Resource: " + resource);
			//System.out.println("http Req: " + http);
			//log.println("Resource: " + resource);

			InetAddress client = conn.getInetAddress();
			//System.out.println(client.getHostAddress() + " connected to the server.");
			//log.println(client.getHostAddress());

			DateFormat dateFormat= new SimpleDateFormat("dd MMM yyyy HH:mm:ss");
			Date longDate = new Date();
			//System.out.println("date: " + longDate);
			String slongDate= dateFormat.format(longDate);

			String date = "Date: " + slongDate;

			if (! resource.startsWith("/")) {
				String reply3=(http) + " 400 Bad Request\r\n" +
						"Connection: close\r\n" +
						(date) + "\r\n" +
						"Content-Type: text/html\r\n" +
						"\r\n" +
						"<h1>400 Bad Request</h1>\r\n";

				//resource = reply3;
				//System.out.println(resource);
				//System.out.println(reply3);
				outs.write(reply3.getBytes());

			}else{
				//Automically divert to index.html even if / not in put.
				if (resource.endsWith("/")) {
					resource = resource + "index.html";
				}

				if (resource.endsWith(".html")||resource.endsWith(".htm")){
					type1 = "text/html";
					//System.out.println(type1);
				}else
					if (resource.endsWith(".jpeg")||resource.endsWith(".jpg")){
						type1 = "image/jpeg";
						//System.out.println(type1);
					}else
						if (resource.endsWith(".png")){
							type1 = "image/png";
							//System.out.println(type1);
						}else
							if (resource.endsWith(".txt")){
								type1 = "text/plain";
								//System.out.println(type1);
							}else
								if (resource.endsWith(".ico")){
									type1 = "image/ico";
									//System.out.println(type1);
								}
				//System.out.println("type: " + type1);

				String type = "Content-type: " + type1;

				//resource Automatically includes a slash (I dont know why????) but throws an exception if not entered.
				//This if statment looks to see if the resource only equals "/" and if so throws a 400 error.

				if (!(command.equals("GET") || command.equals("HEAD"))) {
					String reply4=(http) + " 501 Not Implemented\r\n" +
							"Connection: close\r\n" +
							(date) + "\r\n" +
							(type) + "\r\n" +
							"\r\n" +
							"<h1>501 Not Implemented</h1>\r\n";

					//System.out.println(resource);
					//System.out.println(reply4);
					outs.write(reply4.getBytes());
				}else{
					if (command.equals("HEAD")){
						boolean containsHost = false;
						for(String lineConn : mySource) {
							if(lineConn == null) { break; }
							if(lineConn.contains("Host:")) {
								containsHost = true;
							}
						}
						if(!containsHost) {
							String reply3=(http) + " 400 Bad Request\r\n" +
									"Connection: close\r\n" +
									(date) + "\r\n" +
									(type) + "\r\n" +
									"\r\n" +
									"<h1>400 Bad Request</h1>\r\n";

							//System.out.println(reply3);
							outs.write(reply3.getBytes());
						}
					}else{
						String myFile = "www" + resource;
						//System.out.println(myFile);

						File iFile=new File(myFile);

						Date lastMod = new Date(iFile.lastModified());
						//System.out.println(lastMod);

						if (!iFile.exists()) {
							String reply=(http) + " 404 Not Found\r\n" +
									"Connection: close\r\n" +
									(date) + "\r\n" +
									(type) + "\r\n" +
									"\r\n" +
									"<h1>404 Not Found</h1>\r\n";

							outs.write(reply.getBytes());
							//System.out.println(reply);
						}else{
							String lastModi = "Last-Modified: " + lastMod;
							String sizestr = "Content-Length: " + iFile.length();

							String reply2=(http) + " 200 OK\r\n" +
									"Connection: close\r\n" +
									(lastModi) + "\r\n" +
									(date) + "\r\n" +
									(type) + "\r\n" +
									(sizestr) + "\r\n" +
									"\r\n";

							InputStream fins = new FileInputStream(iFile);

							outs.write(reply2.getBytes());
							System.out.println(reply2);

							while(true) {
								int rc = fins.read(myPage, 0, 100);
								if (rc <=0) {
									break;
								}
								outs.write(myPage, 0, rc);

							}
						}
					}
				}
			}
			log.println("Log: clientIP= "+client+" Date= "+longDate+" FirstLine= "+mySource[0]);
			if(log != null) {
				log.close();
			}
			outs.close();
			conn.close();
		}catch (IOException e) {
			System.err.println("myServer: error on socket");
			System.exit(1);
		}
	}
}