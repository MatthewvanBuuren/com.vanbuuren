package co.uk.vanbuuren.commons;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.uk.vanbuuren.serviceconnect.commons.Application;
import co.uk.vanbuuren.serviceconnect.commons.Command;
import co.uk.vanbuuren.serviceconnect.commons.SimpleXmlMarshaller;

import org.apache.commons.io.FileUtils;

public class SimpleXmlMarshallerTest {
	
	private static final Logger logger = LoggerFactory.getLogger(SimpleXmlMarshallerTest.class);
	
	@Test
	 public void testWriteApplicationsXml() {
		
		List<Application> applications = new ArrayList<Application>();
		Application app1 = new Application("Spotify");
		app1.getAllCommands().add(new Command("PlayPause","./spotifyctrl.exe /playpause"));
		app1.getAllCommands().add(new Command("Next","./spotifyctrl.exe /next"));
		app1.getAllCommands().add(new Command("Previous","./spotifyctrl.exe /prev"));
		
		applications.add(app1);
		
		Application app2 = new Application("Test","./image.ico");
		app2.getAllCommands().add(new Command("Help","help"));

		applications.add(app2);
		
		String xml = SimpleXmlMarshaller.writeApplicationsXml(applications);
		
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("test-data01.xml").getFile());
		String content = "";
        try {
            content = FileUtils.readFileToString(file);
        } catch(IOException e) {
            fail(e.getMessage());
        }
   
        logger.info(String.valueOf(xml.length()));
        logger.info(String.valueOf(content.length()));
        
		assertEquals(xml, content);
	 }
	
	@Test
	public void testParseXMLApplications() {
		List<Application> applications = new ArrayList<Application>();
		Application app1 = new Application("Spotify");
		app1.getAllCommands().add(new Command("PlayPause","./spotifyctrl.exe /playpause"));
		app1.getAllCommands().add(new Command("Next","./spotifyctrl.exe /next"));
		app1.getAllCommands().add(new Command("Previous","./spotifyctrl.exe /prev"));
		
		applications.add(app1);
		
		Application app2 = new Application("Test","./image.ico");
		app2.getAllCommands().add(new Command("Help","help"));

		applications.add(app2);
		
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("test-data01.xml").getFile());
		String content = "";
        try {
            content = FileUtils.readFileToString(file);
        } catch(IOException e) {
            fail(e.getMessage());
        }
        
		List<Application> allApplications = SimpleXmlMarshaller.parseXMLApplications(content);
	}
}
