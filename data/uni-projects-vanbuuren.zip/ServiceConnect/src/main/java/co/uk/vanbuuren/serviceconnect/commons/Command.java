package co.uk.vanbuuren.serviceconnect.commons;

import java.io.Serializable;

public class Command implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String commandName;
	private String commandValue;
	
	public Command(String commandName, String commandValue) {
		this.commandName = commandName;
		this.commandValue = commandValue;
	}

	public String getCommandName() {
		return commandName;
	}

	public void setCommandName(String commandName) {
		this.commandName = commandName;
	}

	public String getCommandValue() {
		return commandValue;
	}

	public void setCommandValue(String commandValue) {
		this.commandValue = commandValue;
	}
}
