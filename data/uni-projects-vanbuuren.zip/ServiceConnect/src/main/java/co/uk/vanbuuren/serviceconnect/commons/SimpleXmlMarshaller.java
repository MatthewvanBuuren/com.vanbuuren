package co.uk.vanbuuren.serviceconnect.commons;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SimpleXmlMarshaller {

	@SuppressWarnings("unused")
	private static final Logger logger = LoggerFactory.getLogger(SimpleXmlMarshaller.class);
	
	private static final String applicationNameStart = "<applicationname>";
	private static final String applicationNameEnd = "</applicationname>";
	private static final String applicationIconStart = "<applicationicon>";
	private static final String applicationIconEnd = "</applicationicon>";
	private static final String commandNameStart = "<commandname>";
	private static final String commandNameEnd = "</commandname>";
	private static final String commandValueStart = "<commandvalue>";
	private static final String commandValueEnd = "</commandvalue>";
	
	public static String writeApplicationsXml(List<Application> applications) {
		String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
		xml = xml.concat("<applications>\n");
	
		for(Application app : applications) {
			xml = xml.concat("\t<application>\n");
			
			xml = xml.concat("\t\t<applicationname>" + app.getApplicationName() + "</applicationname>\n");
			xml = xml.concat("\t\t<applicationicon>" + app.getApplicationIcon() + "</applicationicon>\n");
			
			xml = xml.concat("\t\t<commands>\n");
			for(Command command : app.getAllCommands()) {
				xml = xml.concat("\t\t\t<command>\n");
				
				xml = xml.concat("\t\t\t\t<commandname>" + command.getCommandName() + "</commandname>\n");
				xml = xml.concat("\t\t\t\t<commandvalue>" + command.getCommandValue() + "</commandvalue>\n");
				
				xml = xml.concat("\t\t\t</command>\n");
			}
			xml = xml.concat("\t\t</commands>\n");
			xml = xml.concat("\t</application>\n");
		}
		
		xml = xml.concat("</applications>\n");
		return xml;
	}
	
	public static List<Application> parseXMLApplications(final String xml) {
		final List<Application> result = new ArrayList<Application>();
		
		String[] xml2 = xml.split("</application>");
		for(String xml2part : xml2) {
			String[] xml3 = xml2part.split("<application>");
			if(xml3.length > 1) {
				Application application = getApplication(xml3[1]);
				result.add(application);
			}
		}
		
		return result;
	}
	
	public static int getRequestType(String xml) {
		int request = 0;
		for(Request req : Request.getRequests()) {
			if(xml.contains("<Request>" + req.getRequestString() + "</Request>")) {
				request = req.getRequestInt();
				break;
			}
		}
		return request;
	}
	
	private static Application getApplication(String application) {
		String applicationName = application.substring((application.indexOf(applicationNameStart) + applicationNameStart.length()), application.indexOf(applicationNameEnd));
		
		int startPos = application.indexOf(applicationIconStart) + applicationIconStart.length();
		int endPos = application.indexOf(applicationIconEnd);
		String applicationIcon = "";
		if(startPos != endPos) {
			applicationIcon = application.substring(startPos, endPos);
		}
		
		Application app = new Application(applicationName,applicationIcon);
		
		final List<Command> allCommands = new ArrayList<Command>();
		
		String[] application2 = application.split("</command>");
		for(String application2part : application2) {
			String[] application3 = application2part.split("<command>");
			if(application3.length > 1) {
				allCommands.add(getCommand(application3[1]));
			}
		}
		app.setAllCommands(allCommands);

		return app;
	}
	
	private static Command getCommand(String command) {
		String commandName = command.substring((command.indexOf(commandNameStart) + commandNameStart.length()), command.indexOf(commandNameEnd));
		String commandValue = command.substring((command.indexOf(commandValueStart) + commandValueStart.length()), command.indexOf(commandValueEnd));
		return new Command(commandName, commandValue);
	}
}
