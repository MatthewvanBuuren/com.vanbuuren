package co.uk.vanbuuren.serviceconnect.commons;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Application implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String applicationName;
	private String applicationIcon;
	
	public List<Command> allCommands;
	
	public Application(String applicationName, String applicationIcon) {
		this.applicationName = applicationName;
		this.applicationIcon = applicationIcon;
		this.allCommands = new ArrayList<Command>();
	}
	
	public Application(String applicationName) {
		this.applicationName = applicationName;
		this.applicationIcon = "";
		this.allCommands = new ArrayList<Command>();
	}
	
	public Application() {
	        this.allCommands = new ArrayList<Command>();
	}
	
	public String getApplicationName() {
		return applicationName;
	}
	
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}
	
	public String getApplicationIcon() {
		return applicationIcon;
	}
	
	public void setApplicationIcon(String applicationIcon) {
		this.applicationIcon = applicationIcon;
	}
	
	public List<Command> getAllCommands() {
		return allCommands;
	}
	
	public void setAllCommands(List<Command> allCommands) {
		this.allCommands = allCommands;
	}
}
