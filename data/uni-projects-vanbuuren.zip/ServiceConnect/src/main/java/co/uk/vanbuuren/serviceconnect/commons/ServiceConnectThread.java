package co.uk.vanbuuren.serviceconnect.commons;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ServiceConnectThread extends Thread {
	
	private static final Logger logger = LoggerFactory.getLogger(ServiceConnectThread.class);
	
	private Socket conn;
	private List<Application> allApplications;

	public ServiceConnectThread(Socket conn, List<Application> allApplications) { 
		this.conn = conn;
		this.allApplications = allApplications;
	}
	
	@Override
	public void run () {
		try {
			OutputStream toClient = conn.getOutputStream();
			
			InputStream in = conn.getInputStream();
			InputStreamReader is = new InputStreamReader(in);
			BufferedReader br = new BufferedReader(is);
			String read = br.readLine();
			String fullRequest = read;
			while(read != null) {  
			    read = br.readLine();
			    if(read != null) {fullRequest = fullRequest + read; }
			}
			logger.info(fullRequest);
			conn.shutdownInput();
			
			switch (SimpleXmlMarshaller.getRequestType(fullRequest)) { 
				case 21:
					String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
					xml = xml.concat("<applications>\n");
				
					for(Application app : allApplications) {
						xml = xml.concat("\t<application>\n");
						
						xml = xml.concat("\t\t<applicationname>" + app.getApplicationName() + "</applicationname>\n");
						xml = xml.concat("\t\t<applicationicon>" + app.getApplicationIcon() + "</applicationicon>\n");
						xml = xml.concat("\t\t<commands>\n");
						for(Command command : app.getAllCommands()) {
							xml = xml.concat("\t\t\t<command>\n");
							xml = xml.concat("\t\t\t\t<commandname>" + command.getCommandName() + "</commandname>\n");
							xml = xml.concat("\t\t\t</command>\n");
						}
						xml = xml.concat("\t\t</commands>\n");
						xml = xml.concat("\t</application>\n");
					}
					
					xml = xml.concat("</applications>\n");
					
					byte buf[] = xml.getBytes(); 
					toClient.write(buf);
					break;
				case 22:
					String applicationStr = fullRequest.substring(fullRequest.indexOf("<Application>") + 13, fullRequest.indexOf("</Application>"));
					String commandStr = fullRequest.substring(fullRequest.indexOf("<Command>") + 9, fullRequest.indexOf("</Command>"));
					String res = "";
					for(Application app : allApplications) {
						if(app.getApplicationName().equals(applicationStr)) {
							for(Command command : app.allCommands) {
								if(command.getCommandName().equals(commandStr)) {
									try {
								 		Process pr = Runtime.getRuntime().exec(command.getCommandValue());
								 		
								 		BufferedReader input = new BufferedReader(new InputStreamReader(pr.getInputStream()));
							
								 		String line=null;
							
								 		while((line=input.readLine()) != null) {
								 			res = res +(line);
								 		}
							
								 		int exitVal = pr.waitFor();
								 		logger.debug("Exited with error code "+exitVal);
							
								 	} catch(Exception e) {
								 		logger.error(e.toString());
								 		e.printStackTrace();
								 	}
								}
							}
						}
					}
					toClient.write(res.getBytes());
					break;
				default : 
					break;
			}
			conn.shutdownOutput();
			conn.close();
		} catch(IOException e) {
			logger.error("myServer: error on socket");
			/** Not closing application because of error on socket, Multiple threads so just report. */
			//System.exit(1);
		}
	}
}
