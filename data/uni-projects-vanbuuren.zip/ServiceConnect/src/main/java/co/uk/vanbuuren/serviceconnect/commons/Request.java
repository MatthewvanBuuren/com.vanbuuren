package co.uk.vanbuuren.serviceconnect.commons;

import java.util.ArrayList;
import java.util.List;

public enum Request {
	
	GETAPPLICATIONS("getApplications",21),
	EXECUTE("execute",22);
	
	private final String request;
	private final int requestId;
	
	private Request(String request, int requestId) {
		this.request = request;
		this.requestId = requestId;
	}
	
	public String getRequestString() {
		return request;
	}
	
	public static List<Request> getRequests() {
		List<Request> allRequests = new ArrayList<Request>();
		allRequests.add(Request.EXECUTE);
		allRequests.add(Request.GETAPPLICATIONS);
		return allRequests;
	}
	
	public int getRequestInt() {
		return requestId;
	}
}

