package co.uk.vanbuuren.serviceconnect.commons;

import static org.junit.Assert.fail;

import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ServiceConnectServer{
	
	private static final Logger logger = LoggerFactory.getLogger(ServiceConnectServer.class);
	
	private ServerSocket serverSocket = null;
	private List<Application> allApplications = null;
	
	public static void main(String args[]) throws Exception {
		int port = 27925;
		try {
			port = Integer.parseInt(args[0]);
		} catch(ArrayIndexOutOfBoundsException aioobe) {
			logger.debug("Missing port argument, Using deafult: " + port);
		}
		
		ServiceConnectServer server = new ServiceConnectServer(port);
		server.initialize();
		server.run();
	}
	
	public ServiceConnectServer(int port) {
		try {
			serverSocket = new ServerSocket(port);
			logger.info("Listening on Port: " + (port));
			logger.info("Successful");
		} catch(IOException ioe) {
			logger.error(ioe.getMessage());
			System.exit(1);
		}
	}
	
	private void run() {
		try {
			while(true) {
				Socket conn = serverSocket.accept();
				ServiceConnectThread serverthread = new ServiceConnectThread(conn, allApplications);
				serverthread.start();
			}
		} catch(IOException ioe) {
			logger.error(ioe.getMessage());
			System.exit(1);
		}
	}
	
	private void initialize() {
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("DefaultServiceConnect.xml").getFile());
		String content = "";
        try {
            content = FileUtils.readFileToString(file);
            allApplications = SimpleXmlMarshaller.parseXMLApplications(content);
        } catch(IOException e) {
            logger.error(e.getMessage());
            System.exit(1);
        }
	}
}
