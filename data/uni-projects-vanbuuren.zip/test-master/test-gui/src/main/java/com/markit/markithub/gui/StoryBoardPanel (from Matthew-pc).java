package com.markit.markithub.gui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.markit.markithub.test.model.State;
import com.markit.markithub.test.model.Story;
import com.markit.markithub.test.model.Task;

/**
 * Represents the story-board panel
 */
public class StoryBoardPanel extends JPanel implements Story<Task> {

	private static final long serialVersionUID = 1L;
	private static Logger logger = LoggerFactory.getLogger(StoryBoardPanel.class);

	private static final String ADD_CMD = "add";
	private static final String UP_CMD = "up";
	private static final String DOWN_CMD = "down";
	private static final String BIN_CMD = "bin";
	private static final String NEW_CMD = "new";

	private static final String ADD_ICON = "images/add.png";
	private static final String UP_ICON = "images/uparrow.png";
	private static final String DOWN_ICON = "images/downarrow.png";
	private static final String BIN_ICON = "images/bin.png";
	private static final String NEW_ICON = "images/new.png";

	private final StoryList story;
	private final StoryListModel model;

	private JButton  addButton;
	private JButton upButton;
	private JButton downButton;
	private JButton binButton;
	private JButton newButton;

	private JTextField name;

	private NewListener newStoryListener;
	private final JFrame selectorPopup; //task selector

	public StoryBoardPanel(StoryCreator creator) {
		super(new BorderLayout());
		this.selectorPopup = new TaskSelectorPopup(this);
		logger.info("Laying out Story panel");
		model = new StoryListModel();
		story = new StoryList(model);
		name = new JTextField("Untitled Story");
		JScrollPane scroll = new JScrollPane(story);
		add(scroll, BorderLayout.CENTER);
		story.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		JPanel controls = createControls();
		add(controls, BorderLayout.SOUTH);
		add(name, BorderLayout.NORTH);
		lock();
	}

	private JPanel createControls() {
		JPanel controls = new JPanel();
		ImageIcon addIcon = new ImageIcon(StoryCreator.getClasspathImage(ADD_ICON));
		ImageIcon upIcon = new ImageIcon(StoryCreator.getClasspathImage(UP_ICON));
		ImageIcon downIcon = new ImageIcon(StoryCreator.getClasspathImage(DOWN_ICON));
		ImageIcon binIcon = new ImageIcon(StoryCreator.getClasspathImage(BIN_ICON));
		ImageIcon newIcon = new ImageIcon(StoryCreator.getClasspathImage(NEW_ICON));

		addButton = new ImageButton(addIcon, "Add Tasks");
		upButton = new ImageButton(upIcon, "Move Task Up");
		downButton = new ImageButton(downIcon, "Move Task Up");
		binButton = new ImageButton(binIcon, "Delete Task");
		newButton = new ImageButton(newIcon, "New Story");

		binButton.setActionCommand(BIN_CMD);
		downButton.setActionCommand(DOWN_CMD);
		addButton.setActionCommand(ADD_CMD);
		upButton.setActionCommand(UP_CMD);
		newButton.setActionCommand(NEW_CMD);
		upButton.addActionListener(new UpDownListener());
		downButton.addActionListener(new UpDownListener());
		binButton.addActionListener(new DeleteListener());
		addButton.addActionListener(new AddListener());
		newStoryListener = new NewListener(model, this);
		newButton.addActionListener(newStoryListener);
		controls.add(addButton);
		controls.add(upButton);
		controls.add(downButton);
		controls.add(binButton);
		controls.add(newButton);
		return controls;
	}

	/**
	 * Move Tasks up and down in the list
	 */
	class UpDownListener implements ActionListener {

		public void actionPerformed(ActionEvent e) {
			int moveMe = story.getSelectedIndex();
            if (e.getActionCommand().equals(UP_CMD)) {
            	if (moveMe != 0) {
                    swap(moveMe, moveMe-1);
                    story.setSelectedIndex(moveMe-1);
                    story.ensureIndexIsVisible(moveMe-1);
                }
            }
            else {
                if (moveMe != model.getSize()-1) {
                    swap(moveMe, moveMe+1);
                    story.setSelectedIndex(moveMe+1);
                    story.ensureIndexIsVisible(moveMe+1);
                }
            }
        }
    }

	/**
	 * Delete Tasks
	 */
	class DeleteListener implements ActionListener {

		public void actionPerformed(ActionEvent e) {
			ListSelectionModel lsm = story.getSelectionModel();
			int firstSelected = lsm.getMinSelectionIndex();
			int lastSelected = lsm.getMaxSelectionIndex();
			model.removeRange(firstSelected, lastSelected);
			int size = model.size();
			if (size == 0) {
				lock();
			}
			else {
				if (firstSelected == model.getSize()) {
					firstSelected--;
				}
				story.setSelectedIndex(firstSelected);
			}
		}
    }

	/**
	 * Move Tasks up and down in the list
	 */
	class AddListener implements ActionListener {

		public void actionPerformed(ActionEvent e) {
	        if (!selectorPopup.isVisible()) {
	            // show the popup if not visible
	        	addButton.setEnabled(false);
	            selectorPopup.setVisible(true);
	            selectorPopup.requestFocus();
	        }
		}
    }

    private void swap(int a, int b) {
        Object aObject = model.getElementAt(a);
        Object bObject = model.getElementAt(b);
        model.set(a, bObject);
        model.set(b, aObject);
    }

	public List<Task> getTasks() {
		Object[] array = model.toArray();
		List<Task> tasks = new ArrayList<Task>();
		for (Object o : array) {
			tasks.add(Task.class.cast(o));
		}
		return tasks;
	}

	public void setTasks(List<Task> allTasks){
		for(Task task : allTasks){
			addTask(task);
		}
	}

	public void resetAllToPending() {
		for (int i=0; i < model.getSize(); i++) {
			Task Task = Task.class.cast(model.get(i));
			Task.setState(State.PENDING);
		}
		SwingUtilities.invokeLater(new Runnable() {

			public void run() {
				repaint();
			}

		});
	}

	public void lock() {
		SwingUtilities.invokeLater(new Runnable() {

			public void run() {
				upButton.setEnabled(false);
				downButton.setEnabled(false);
				binButton.setEnabled(false);
				newButton.setEnabled(false);
			}
		});
	}

	public void unlock() {
		upButton.setEnabled(true);
		downButton.setEnabled(true);
		binButton.setEnabled(true);
		newButton.setEnabled(true);
	}

	public String getTitle() {
		return name.getText();
	}

	public void setTitle(String title) {
		name.setText(title);
	}

	public void addTask(final Task task) {
		SwingUtilities.invokeLater(new Runnable() {

			public void run() {
				int index = story.getSelectedIndex();
		        int size = model.getSize();

		        if (index == -1 || (index + 1 == size)) {
		        	try {
		        		Class<? extends Task> clazz = task.getClass();
						model.addElement(clazz.newInstance());
						story.setSelectedIndex(size);
					} catch (InstantiationException e) {
						logger.error("Error instantizing ",e);
					} catch (IllegalAccessException e) {
						logger.error("Illegal Access ",e);
					}
		        }
		        else {
		            model.insertElementAt(task, index + 1);
		            story.setSelectedIndex(index+1);
		        }
		        unlock();
			}
		});
	}


	public void clearStory() {
		model.clear();
	}

	public void popupClosing() {
		final JButton button = this.addButton;
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				button.setEnabled(true);
			}
		});
	}

}

