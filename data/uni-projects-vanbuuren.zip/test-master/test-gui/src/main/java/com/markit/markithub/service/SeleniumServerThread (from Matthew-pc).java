package com.markit.markithub.service;

import java.io.File;

import org.openqa.selenium.server.RemoteControlConfiguration;
import org.openqa.selenium.server.SeleniumServer;


/**
 * Thread which will runs the Selenium Server
 */
public class SeleniumServerThread extends Thread {

	private final SeleniumServer server;

	public SeleniumServerThread(boolean trustAllSSLCertificates, boolean avoidProxy,File FirefoxProfile) throws Exception {
		RemoteControlConfiguration conf = new RemoteControlConfiguration();
		conf.shouldOverrideSystemProxy();
		conf.setTrustAllSSLCertificates(trustAllSSLCertificates);
		conf.setAvoidProxy(avoidProxy);
		conf.setFirefoxProfileTemplate(FirefoxProfile);
		setDaemon(true);
		server = new SeleniumServer(conf);
	}

	public SeleniumServerThread(boolean trustAllSSLCertificates, boolean avoidProxy) throws Exception {
		RemoteControlConfiguration conf = new RemoteControlConfiguration();
		conf.shouldOverrideSystemProxy();
		conf.setTrustAllSSLCertificates(trustAllSSLCertificates);
		conf.setAvoidProxy(avoidProxy);
		setDaemon(true);
		server = new SeleniumServer(conf);
	}

	@Override
	public void run() {
		try {
			server.start();
		}
		catch (Exception x) {
			throw new RuntimeException("Could not start Selenium Server", x);
		}
	}

	public void kill() {
		server.stop();
	}

}
