package com.markit.markithub.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoginDetailsDao {

	private static final String SEPERATOR = ":_=_:";
	private static Logger logger = LoggerFactory.getLogger(LoginDetailsDao.class);

	public static void writeDetails(File file,Map<String,String> allDetails) throws IOException{
		try{
			PrintWriter outputStream   = new PrintWriter(new FileWriter(file));
            for(Map.Entry<String, String> entry : allDetails.entrySet()) {
                outputStream.println(entry.getKey() + SEPERATOR + entry.getValue());
            }
            outputStream.close();
        } catch (IOException e) {
            logger.error("IOException: ",e);
            throw e;
        }
	}

	public static Map<String,String> readDetails(File file) throws IOException{
		Map<String,String> allDetails = new HashMap<String,String>();
		try{
			BufferedReader inputStream = new BufferedReader(new FileReader(file));
			String inLine = null;
			while((inLine = inputStream.readLine()) != null){
				allDetails.put((inLine.substring(0, inLine.indexOf(SEPERATOR))),
						(inLine.substring((inLine.indexOf(SEPERATOR)+ 5), inLine.length())));
			}
		}catch(IOException e){
			logger.error("IOException: ",e);
			throw e;
		}
		return allDetails;
	}

}
