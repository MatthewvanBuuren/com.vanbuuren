package com.markit.markithub.gui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.SwingUtilities;

import com.markit.markithub.test.TaskManager;
import com.markit.markithub.test.model.StorySettings;

public class StoryControlPanel extends JPanel {

	private static final long serialVersionUID = 1L;

	private TaskManager taskManager;
	private final StoryBoardPanel story;
	private final StoryCreator creator;

	private final JButton runButton = new JButton("Run Test");;
	private final JProgressBar progressBar;
	private final JButton resultsFolderButton =  new JButton("Results Folder");
	private final JButton resultsFileButton = new JButton("Results File"); ;

	public StoryControlPanel(StoryBoardPanel story, StoryCreator creator) {
		this.story = story;
		this.creator = creator;
		resultsFolderButton.addActionListener(new ResultsListener());
		resultsFileButton.addActionListener(new ResultsFileListener());
		resultsFileButton.setEnabled(false);
		runButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				run();
			}
		});

		JPanel buttons = new JPanel();
		buttons.add(runButton);
		buttons.add(resultsFolderButton);
		buttons.add(resultsFileButton);

		JPanel progress = new JPanel();
		progressBar = new JProgressBar();
		progress.add(progressBar);

		JPanel content = new JPanel(new BorderLayout());

		content.add(buttons, BorderLayout.CENTER);
		content.add(progress, BorderLayout.SOUTH);
		add(content);
	}

	public JProgressBar getProgressBar() {
		return progressBar;
	}

	/*
	 * Run test
	 */
	public void run() {
		try{
			final StorySettings settings = creator.getTestProperties();
			@SuppressWarnings("unused")
			URL url = new URL(settings.getUrl());
			if (story.getTasks().size()==0) {
				JOptionPane.showMessageDialog(this, "This Story contains no Tests");
			}
			else {
				progressBar.setValue(0);
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						testStarted();
						taskManager.run(story, settings); //run and enable at the end
					}
				});
			}
		}
		catch(MalformedURLException mue){
			JOptionPane.showMessageDialog(this, "Malformed Url, Check the Url has a valid protocol. I.e 'Http://www.hub.com' and not 'www.hub.com'");
		}
	}

	private void testStarted() {
		runButton.setEnabled(false);
		resultsFileButton.setEnabled(false);
		story.lock(); //can't order
		story.resetAllToPending(); //set all to pending
		creator.testRunning();
	}

	public void testFinished() {
		runButton.setEnabled(true);
		resultsFileButton.setEnabled(true);
		story.unlock();
		creator.testFinished();
	}

	public void setTaskManager(TaskManager taskManager) {
		this.taskManager = taskManager;
	}

}
