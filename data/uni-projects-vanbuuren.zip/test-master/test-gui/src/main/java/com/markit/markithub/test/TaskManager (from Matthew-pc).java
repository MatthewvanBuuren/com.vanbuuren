package com.markit.markithub.test;

import java.beans.PropertyChangeListener;
import java.io.File;

import javax.swing.JProgressBar;

import com.markit.markithub.gui.ResultsListener;
import com.markit.markithub.test.model.Story;
import com.markit.markithub.test.model.StorySettings;
import com.markit.markithub.test.model.Task;

public class TaskManager {

	private final JProgressBar progress;
	private final Runnable finishedCallback;
	private final PropertyChangeListener progressListener;

	public TaskManager(JProgressBar progress, Runnable finishedCallback) {
		this.progress = progress;
		this.finishedCallback = finishedCallback;
		this.progressListener = new TaskExecutionListener(progress);
	}

	public void run(Story<Task> story, StorySettings storySettings) {
		progress.setIndeterminate(true);

		TaskExecutingSwingWorker worker = null;
		worker = new TaskExecutingSwingWorker(story, finishedCallback, storySettings);
		worker.addPropertyChangeListener(progressListener);
		worker.execute();

	}

	public File getResultsFolder() {
		String resultsFolder = System.getProperty("user.home") + File.separator
				+ ResultsListener.RESULTS_FOLDER;
		File folder = new File(resultsFolder);
		if (!folder.exists()) {
			folder.mkdirs();
		}
		return folder;
	}

}
