package com.markit.markithub.gui;

import java.awt.Component;
import java.awt.Insets;

import javax.swing.border.CompoundBorder;

public class PaddingBorder extends CompoundBorder {

	private static final long serialVersionUID = 1L;

	private final int top;
	private final int bottom;
	private final int left;
	private final int right;

	public PaddingBorder(int top, int bottom, int left, int right) {
		this.top = top;
		this.bottom = bottom;
		this.left = left;
		this.right = right;
	}

	public PaddingBorder(int horizontal, int vertical) {
		this(horizontal, horizontal, vertical, vertical);
	}

	public PaddingBorder(int padding) {
		this(padding, padding);
	}

	@Override
	public Insets getBorderInsets(Component c) {
		Insets borderInsets = super.getBorderInsets(c);
		borderInsets.left = left;
		borderInsets.right = right;
		borderInsets.top = top;
		borderInsets.bottom = bottom;
		return borderInsets;
	}

}
