package com.markit.markithub.service;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.util.NoSuchElementException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.markit.markithub.service.api.StoryDao;
import com.markit.markithub.test.model.Story;
import com.markit.markithub.test.model.Task;

public class XmlSerilializedStoryDao implements StoryDao {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static Logger logger = LoggerFactory.getLogger(XmlSerilializedStoryDao.class);

	/*
	 * (non-Javadoc)
	 * @see com.markit.markithub.service.api.StoryDao#write(com.markit.markithub.test.model.story.Story, java.net.URI)
	 */
    public void write(Story<Task> story, URI uri) throws FileNotFoundException {
    	File file = new File(uri);
        XMLEncoder encoder =
           new XMLEncoder(
              new BufferedOutputStream(
                new FileOutputStream(file)));
        encoder.writeObject(story);
        encoder.close();
    }

    /*
     * (non-Javadoc)
     * @see com.markit.markithub.service.api.StoryDao#read(java.net.URI)
     */
	public Story<Task> read(URI uri) throws IOException {
		File file = new File(uri);
		XMLDecoder decoder =
			new XMLDecoder(new BufferedInputStream(
					new FileInputStream(file)));
		// Parser will write to terminal any exception, And a default story will return.
		try {
			Object obj = decoder.readObject();
			@SuppressWarnings("unchecked")
			Story<Task>  story = Story.class.cast(obj);
			decoder.close();
			return story;
		}
		catch (NoSuchElementException x) {
			logger.error("Could not decode XML", x);
			throw new IOException("Bad file");
		}
    }
}
