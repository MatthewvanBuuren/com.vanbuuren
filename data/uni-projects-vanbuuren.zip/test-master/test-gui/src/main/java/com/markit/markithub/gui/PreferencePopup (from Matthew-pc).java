package com.markit.markithub.gui;

import java.awt.BorderLayout;
import java.awt.ComponentOrientation;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.markit.markithub.service.LoginDetailsDao;
import com.markit.markithub.service.loginDetails;

public class PreferencePopup extends JFrame {

	private static final long serialVersionUID = 1L;

	private static final Logger logger = LoggerFactory.getLogger(PreferencePopup.class);

	private static final String TITLE = "Preferences";
	private static final int POPUP_WIDTH = 270;
	private static final int POPUP_HEIGHT = 250;

	private static JCheckBox jcb_saveLoginDetails;
	private static JTextField jtf_url;
	private static JTextField jtf_username;
	private static JPasswordField jpf_password;
	private static JCheckBox jcb_seperateSession;

	private static JButton applyButton;
	private static JButton closeButton;

	private static final File settings = new File(System.getProperty("user.home") + File.separator + "Elequince.htr");

	public static void main(String[] args) {
		new PreferencePopup().setVisible(true);
	}

	public PreferencePopup(){
		setSize(POPUP_WIDTH,POPUP_HEIGHT);
		setResizable(false);
		setTitle(TITLE);
		setLocationRelativeTo(rootPane);
		Container contentPane = getContentPane();
		JPanel panel = new JPanel(new BorderLayout());
		panel.add(createLoginDetails(), BorderLayout.WEST);
		panel.add(createButtons(), BorderLayout.SOUTH);
		contentPane.add(panel);
		try{
			if(settings.exists()){
				Map<String,String> map = LoginDetailsDao.readDetails(settings);
				if(map.get(loginDetails.SAVEDSETTINGS.toString()).equals("true") && !map.get(loginDetails.SAVEDSETTINGS.toString()).equals("false")){
					jcb_saveLoginDetails.setSelected(true);
					jtf_url.setText(map.get(loginDetails.URL.toString()));
					jtf_username.setText(map.get(loginDetails.USERNAME.toString()));
					jpf_password.setText(map.get(loginDetails.PASSWORD.toString()));
					jcb_seperateSession.setSelected(map.get(loginDetails.SEPERATESESSION.toString()).equals("true"));
					jtf_url.setEnabled(true);
					jtf_username.setEnabled(true);
					jpf_password.setEnabled(true);
					jcb_seperateSession.setEnabled(true);
					System.out.println(map.get(loginDetails.PASSWORD.toString()));
					logger.info("Read settings from HubTestRunner.htr");
				}
			}
	    }catch(Exception e){
	    	logger.error("Failed to read settings from HubTestRunner.htr",e);
	    }
	}

	public JPanel createLoginDetails(){
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel,BoxLayout.PAGE_AXIS));
		panel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		panel.setBorder(BorderFactory.createTitledBorder("Login"));

		jcb_saveLoginDetails = new JCheckBox("Save login details");
		jcb_saveLoginDetails.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(jcb_saveLoginDetails.isSelected()){
					jtf_url.setEnabled(true);
					jtf_username.setEnabled(true);
					jpf_password.setEnabled(true);
					jcb_seperateSession.setEnabled(true);
				}else{
					jtf_url.setEnabled(false);
					jtf_username.setEnabled(false);
					jpf_password.setEnabled(false);
					jcb_seperateSession.setEnabled(false);
				}
			}
		});
		panel.add(jcb_saveLoginDetails);

		JPanel panelUr = new JPanel(new FlowLayout());
		JLabel lb1 = new JLabel("           Url: ");
		jtf_url = new JTextField(15);
		jtf_url.setEnabled(false);
		panelUr.add(lb1);
		panelUr.add(jtf_url);
		panel.add(panelUr);

		JPanel panelUs = new JPanel(new FlowLayout());
		JLabel lb2 = new JLabel("Username: ");
		jtf_username = new JTextField(15);
		jtf_username.setEnabled(false);
		panelUs.add(lb2);
		panelUs.add(jtf_username);
		panel.add(panelUs);

		JPanel panelP = new JPanel(new FlowLayout());
		JLabel lb3 = new JLabel("Password: ");
		jpf_password = new JPasswordField(15);
		jpf_password.setEnabled(false);
		panelP.add(lb3);
		panelP.add(jpf_password);
		panel.add(panelP);

		JPanel panelS = new JPanel(new FlowLayout());
		JLabel lb4 = new JLabel("Seperate Session: ");
		jcb_seperateSession = new JCheckBox();
		jcb_seperateSession.setEnabled(false);
		panelS.add(lb4);
		panelS.add(jcb_seperateSession);
		panel.add(panelS);
		return panel;
	}

	public JPanel createButtons(){
		JPanel panel = new JPanel();
		applyButton = new JButton("Apply");
		closeButton = new JButton("Close");
		applyButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
			       try{
			    	   Map<String,String> allDetails = new HashMap<String,String>();
			    	   allDetails.put(loginDetails.URL.toString(),jtf_url.getText());
			    	   allDetails.put(loginDetails.PASSWORD.toString(),String.copyValueOf(jpf_password.getPassword()));
			    	   allDetails.put(loginDetails.USERNAME.toString(),jtf_username.getText());
			    	   allDetails.put(loginDetails.SEPERATESESSION.toString(),isSeperateSessionSelected());
			    	   allDetails.put(loginDetails.SAVEDSETTINGS.toString(),isSaveLoginDetailsSelected());
			    	   LoginDetailsDao.writeDetails(settings, allDetails);
			    	   logger.info("Writing settings to Elequince.htr complete");
			       }catch(Exception f){
			    	   logger.error("Failed to write settings to Elequince.htr",f);
			       }
			}
		});
		closeButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				PreferencePopup.this.setVisible(false);
			}
		});
		panel.add(applyButton);
		panel.add(closeButton);
		return panel;
	}

	private String isSeperateSessionSelected(){
		if(jcb_seperateSession.isSelected()){
			return "true";
		}else{
			return "false";
		}
	}

	private String isSaveLoginDetailsSelected() {
		if(jcb_saveLoginDetails.isSelected()){
			return "true";
		} else {
			return "false";
		}
	}
}
