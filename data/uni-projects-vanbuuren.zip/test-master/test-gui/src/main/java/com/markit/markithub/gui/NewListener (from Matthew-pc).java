package com.markit.markithub.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultListModel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NewListener implements ActionListener {

	private static final Logger logger = LoggerFactory.getLogger(NewListener.class);

	private final DefaultListModel model;
	private final StoryBoardPanel panel;

	public NewListener(DefaultListModel model, StoryBoardPanel panel) {
		this.model = model;
		this.panel = panel;
	}

	public void actionPerformed(ActionEvent e) {
		logger.info("Clearing the Storyboard");
		model.removeAllElements();
		panel.setTitle("Untitled Story");
		panel.lock();
	}

}
