package com.markit.markithub.gui;

import javax.swing.Icon;
import javax.swing.JButton;

/**
 * Button specialised for use with images
 */
public class ImageButton extends JButton {

	private static final long serialVersionUID = 1L;

	public ImageButton(Icon icon, Icon pressed, Icon rollover, String tooltip) {
		super(icon);
		setFocusPainted(false);
		setRolloverEnabled(true);
		setRolloverIcon(rollover);
		setPressedIcon(pressed);
		setContentAreaFilled(false);
		setToolTipText(tooltip);
	}

	public ImageButton(Icon icon, String tooltip) {
		this(icon, icon, icon, tooltip);
	}

	public ImageButton(Icon icon, String tooltip, String text) {
		this(icon, icon, icon, tooltip);
		setText(text);
	}

}
