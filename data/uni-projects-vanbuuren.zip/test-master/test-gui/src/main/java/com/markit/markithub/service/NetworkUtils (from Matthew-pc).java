package com.markit.markithub.service;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;

/**
 * General Network Utilities
 */
public class NetworkUtils {

	/**
	 * Is specified port available.
	 * Default timeout of 2 seconds
	 *
	 * @param host - host name
	 * @param port - port
	 * @return connection available
	 */
	public static boolean isConnectionAvailable(String host, int port) {
		return isConnectionAvailable(host, port, 2000);
	}

	/**
	 * Is specified port available.
	 *
	 * @param host
	 * @param port
	 * @param timeout
	 * @return connection available
	 */
	public static boolean isConnectionAvailable(String host, int port, int timeout) {
        Socket socket = new Socket();
        InetSocketAddress endPoint = new InetSocketAddress(host, port);
        try {
            socket.connect(endPoint, timeout);
            return true;
        }
        catch(Exception x) {
            return false;
        }
        finally {
            if (socket != null) try {
                socket.close();
            }
            catch(IOException ioe) {}
        }
	}


}
