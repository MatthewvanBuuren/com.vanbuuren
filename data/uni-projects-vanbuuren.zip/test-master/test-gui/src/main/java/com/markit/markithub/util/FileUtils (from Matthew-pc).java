package com.markit.markithub.util;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Create a test output folder in the Users home directory using date formatting ect
 */
public class FileUtils {

	/**
	 * Create a folder in the users home directory
	 *
	 * @param localFolderName - name of folder
	 * @return - the created folder
	 */
	public static File createResultsFolder(String baseFolder, String folderPostfix) {
		String home = System.getProperty("user.home");
		String basePath = home + File.separator + baseFolder;
		if (home==null || home.trim().length() ==0) {
			throw new RuntimeException("Unable to determine users home directory");
		}
		Date now = Calendar.getInstance().getTime();
		String theseResults = new SimpleDateFormat("MMM dd HH.mm.ss").format(now);
		theseResults = folderPostfix + " - " + theseResults;
		File results = new File (new File(basePath), theseResults);
		results.mkdirs();
		System.setProperty("RESULTS_FILE", theseResults);
		return results;
	}
}
