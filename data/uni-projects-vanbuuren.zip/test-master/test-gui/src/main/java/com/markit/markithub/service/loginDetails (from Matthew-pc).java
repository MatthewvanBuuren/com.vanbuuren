package com.markit.markithub.service;
/**
 * Keys for saving the details of a login.
 *
 * These are the keys that are used to access the values, Changing
 * these will corrupt the savedDetails and will have to be resaved.
 *
 * @author matthew.vanbuuren
 *
 */
public enum loginDetails {
	SAVEDSETTINGS,URL,USERNAME,PASSWORD,SEPERATESESSION;
}
