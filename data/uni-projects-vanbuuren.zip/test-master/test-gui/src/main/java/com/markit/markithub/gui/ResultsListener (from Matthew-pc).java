package com.markit.markithub.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class ResultsListener implements ActionListener {

	public static final String RESULTS_FOLDER = "hub-test-results";

	public static final boolean IS_WINDOWS = !System.getProperty("os.name").startsWith("Mac");
	
	/*
	 * (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e) {
		Runtime runtime = Runtime.getRuntime();
		try {
			String resultsFolder = System.getProperty("user.home") + File.separator + RESULTS_FOLDER;
			new File(resultsFolder).mkdirs();
			String folder = System.getProperty("user.home") + File.separator + RESULTS_FOLDER;
			if (IS_WINDOWS) {
				Process exec = runtime.exec("cmd.exe /C explorer " + folder);
				exec.waitFor();
			}
			else {
				//mac
				Process exec = runtime.exec("open " + folder);
				exec.waitFor();
			}
		}
		catch (IOException e1) {
			e1.printStackTrace();
		}
		catch (InterruptedException ex) {
			ex.printStackTrace();
		}
	}

}
