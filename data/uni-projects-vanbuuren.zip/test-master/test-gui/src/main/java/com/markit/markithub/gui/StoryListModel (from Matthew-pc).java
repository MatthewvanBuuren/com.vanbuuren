package com.markit.markithub.gui;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.Serializable;

import javax.swing.DefaultListModel;

import com.markit.markithub.test.model.TaskBase;

public class StoryListModel extends DefaultListModel implements PropertyChangeListener,Serializable {

	private static final long serialVersionUID = 1L;

	public void propertyChange(PropertyChangeEvent evt) {
		if (evt.getPropertyName().equals("state")) {
			fireContentsChanged(evt.getSource(), 0, this.size());
		}
	}

	@Override
	public void insertElementAt(Object obj, int index) {
		listen(obj);
		super.insertElementAt(obj, index);
	}

	@Override
	public void addElement(Object obj) {
		listen(obj);
		super.addElement(obj);
	}

	@Override
	public void add(int index, Object element) {
		listen(element);
		super.add(index, element);
	}

	public void listen(Object taskbase) {
		TaskBase task = TaskBase.class.cast(taskbase);
		task.addPropertyChangeListener(this);
	}

}
