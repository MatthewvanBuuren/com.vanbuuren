package com.markit.markithub.service.api;

import java.io.IOException;
import java.io.Serializable;
import java.net.URI;

import com.markit.markithub.test.model.Story;
import com.markit.markithub.test.model.Task;

public interface StoryDao extends Serializable{

	public void write(Story<Task> story, URI uri) throws IOException;

	public Story<Task> read(URI uri) throws IOException;

}