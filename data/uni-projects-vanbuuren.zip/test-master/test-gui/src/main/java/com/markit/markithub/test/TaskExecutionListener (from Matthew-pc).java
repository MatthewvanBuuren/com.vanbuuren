package com.markit.markithub.test;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JProgressBar;

/**
 * Listens to Property changes from the SwingWorker thread {@link TaskExecutingSwingWorker} making appropriate
 * updates to the GUI.
 */
public class TaskExecutionListener implements PropertyChangeListener {

	private final JProgressBar progressBar;

	public TaskExecutionListener(JProgressBar progress) {
		this.progressBar = progress;
		this.progressBar.setValue(0);
	}

	public void propertyChange(PropertyChangeEvent evt) {
		String strPropertyName = evt.getPropertyName();
		if ("progress".equals(strPropertyName)) {
			progressBar.setIndeterminate(false);
			int progress = (Integer) evt.getNewValue();
			progressBar.setValue(progress);
		}
	}

}
