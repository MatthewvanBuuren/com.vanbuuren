package com.markit.markithub.gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.markit.markithub.service.SeleniumServerThread;
import com.markit.markithub.service.XmlSerilializedStoryDao;
import com.markit.markithub.service.api.StoryDao;
import com.markit.markithub.test.TaskManager;
import com.markit.markithub.test.model.SimpleStory;
import com.markit.markithub.test.model.Story;
import com.markit.markithub.test.model.StorySettings;
import com.markit.markithub.test.model.Task;

/**
 * Markit Hub Functional Test Chooser application
 */
public class StoryCreator extends JFrame {

	private static final long serialVersionUID = 1L;
	private static Logger logger = LoggerFactory.getLogger(StoryCreator.class);

	private static final String ICON = "images/favicon.png";
	private static final String FRAME_NAME = "Markit Elequince";

	private static final String firefoxProfileString = "customFirefoxProfile=";
	private static final String defaultStoryLoad = "defaultStoryLoad=";
	private static final String autoStartOption = "-A";

	private final TaskManager taskManager; //responsible for execution

	private final LoginPanel loginPanel; //login details
	private final StoryBoardPanel storyPanel; //the story
	private StoryControlPanel controlPanel; //controls

	private JMenuItem loadStory;
	private JMenuItem saveStory;
	private JMenuItem preferences;
	private JFileChooser loadFile;
	private JFileChooser saveFile;

	private final StoryDao Dao = new XmlSerilializedStoryDao();
	private final SeleniumServerThread server;

	public StoryCreator(File firefoxProfile) throws Exception {
		if(firefoxProfile != null){
			server = new SeleniumServerThread(true, true, firefoxProfile);
		}else{
			server = new SeleniumServerThread(true, true);
		}
		server.run();
		setTitle(FRAME_NAME);
		setSizeAndCenter(700, 600);
		setIconImage(getClasspathImage(ICON));
		setJMenuBar(createMenuBar());
		getContentPane().setLayout(new BorderLayout());

		storyPanel = new StoryBoardPanel(this);
		controlPanel = new StoryControlPanel(storyPanel, this);

		this.taskManager = new TaskManager(controlPanel.getProgressBar(), new Runnable() {

			public void run() {
				logger.debug("Story has finished executing");
				controlPanel.testFinished();
				controlPanel.getProgressBar().setValue(0);
				controlPanel.getProgressBar().setIndeterminate(false);
			}
		});

		controlPanel.setTaskManager(taskManager);

		loginPanel = new LoginPanel();

		JPanel top = new JPanel(new BorderLayout());
		top.add(loginPanel, BorderLayout.NORTH);

		getContentPane().add(top, BorderLayout.NORTH);
		getContentPane().add(storyPanel, BorderLayout.CENTER);
		getContentPane().add(controlPanel, BorderLayout.SOUTH);

		setDefaultCloseOperation(EXIT_ON_CLOSE);

		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				setVisible(true);
			}
		});
	}

	private void loadStory(){
		loadFile = new JFileChooser(System.getProperty("home"));
		int check = loadFile.showOpenDialog(null);
		if (check == JFileChooser.APPROVE_OPTION) {
			File savedFile = null;
			savedFile = loadFile.getSelectedFile();
			URI location = savedFile.toURI();
			loadStory(location);
		}
	}

	public void loadStory(URI location){
		try {
			Story<Task> loadedStory = Dao.read(location);
			clearStory();
			for (Task task : loadedStory.getTasks()) {
				storyPanel.addTask(task);
				storyPanel.setTitle(loadedStory.getTitle());
			}
		}catch (IndexOutOfBoundsException ioobe) {
			JOptionPane.showMessageDialog(null, "Could not load Story. IndexOutOfBoundsException",
					"Error", JOptionPane.ERROR_MESSAGE);
		} catch (IOException iox) {
			JOptionPane.showMessageDialog(null, "Could not load Story. IOException",
					"Error", JOptionPane.ERROR_MESSAGE);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Could not load Story.",
					"Error", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void saveStory(){
		File f = new File(storyPanel.getTitle() + ".story");
		saveFile = new JFileChooser(System.getProperty("home"));
		saveFile.setSelectedFile(f);
		int check = saveFile.showSaveDialog(null);
		if (check == JFileChooser.APPROVE_OPTION) {
			File savedFile = null;
			try {
				savedFile = saveFile.getSelectedFile();
				URI location = savedFile.toURI();
				Story<Task> story = new SimpleStory();
				story.setTitle(storyPanel.getTitle());
				story.setTasks(storyPanel.getTasks());
				Dao.write(story, location);
			} catch (Exception e) {
				logger.error("Could not save storyboard", e);
				JOptionPane.showMessageDialog(null, e.getMessage()
						+ " Story was not Saved", "Error",
						JOptionPane.ERROR_MESSAGE);
			}
		}
	}

	private void loadPreferencePopup(){
		PreferencePopup.main(null);
	}

	/**
	 * Create the Menu Bar for preferences etc
	 */
	private JMenuBar createMenuBar() {
		JMenuBar bar = new JMenuBar();
		JMenu menuFil = new JMenu("File");
		menuFil.setMnemonic(KeyEvent.VK_F);

		loadStory = new JMenuItem("Load Story");
		loadStory.setMnemonic(KeyEvent.VK_L);
		loadStory.setToolTipText("Click here to load a Story.");
		loadStory.addActionListener(new LoadStoryListener());
		menuFil.add(loadStory);

		saveStory = new JMenuItem("Save Story");
		saveStory.setMnemonic(KeyEvent.VK_S);
		saveStory.setToolTipText("Click here to save a Story.");
		saveStory.addActionListener(new SaveStoryListener());
		menuFil.add(saveStory);

		menuFil.addSeparator();

		JMenuItem menuItem = new JMenuItem("Exit");
		menuItem.setMnemonic(KeyEvent.VK_X);
		menuItem.addActionListener(new ExitStoryListener());

		JMenu menuOpt = new JMenu("Options");
		menuFil.setMnemonic(KeyEvent.VK_O);
		preferences = new JMenuItem("Preferences");
		preferences.setMnemonic(KeyEvent.VK_P);
		preferences.addActionListener(new PreferencesListener());
		menuOpt.add(preferences);

		menuFil.add(menuItem);
		bar.add(menuFil);
		bar.add(menuOpt);
		return bar;
	}

	private void setSizeAndCenter(int width, int height) {
		setSize(width, height);
	    Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
	    int w = getSize().width;
	    int h = getSize().height;
	    int x = (dim.width-w) / 2;
	    int y = (dim.height-h) / 2;
	    setLocation(x, y);
	}

	public static ImageIcon getClasspathImageIcon(String classpathImagename) {
		URL url = ClassLoader.getSystemResource(classpathImagename);
		logger.info("Icon '" + classpathImagename + "' found at: " + url);
		return new ImageIcon(url);
	}

	public static Image getClasspathImage(String classpathImagename) {
		return getClasspathImageIcon(classpathImagename).getImage();
	}

	public static void main(String[] args) throws Exception {
		try {
			if (ResultsListener.IS_WINDOWS) {
				UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
			}

			File profilePath = null;
			File storyPath = null;
			boolean autoStart = false;
			boolean loadStory = false;
			URI storyXml = null;

			if(args.length > 0){
				for (int i = 0; i < args.length; i++){
					if(args[i].equals(autoStartOption)){
						autoStart = true;
					}
					if(args[i].contains(firefoxProfileString)){
						File tmp = new File(args[i].substring(firefoxProfileString.length()));
						if(tmp.exists()){
							profilePath = new File(args[i].substring(firefoxProfileString.length()));
						}
					}
					if(args[i].contains(defaultStoryLoad)){
						File tmp = new File(args[i].substring(defaultStoryLoad.length()));
						if(tmp.exists()){
							storyPath = new File(args[i].substring(defaultStoryLoad.length()));
							loadStory = true;
							storyXml = storyPath.toURI();
						}
					}
				}
			}
			StoryCreator story = new StoryCreator(profilePath);
			if(loadStory){
				story.loadStory(storyXml);
			}
			if(autoStart == true){
				story.autoStart();
			}
		}
		catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}
	}

	//Trigger for Auto-Start argument.
	private void autoStart(){
		controlPanel.run();
	}

	public void clearStory() {
		storyPanel.clearStory();
	}

	private class LoadStoryListener implements ActionListener {

		public void actionPerformed(ActionEvent e) {
	    	loadStory();
	    }

	}

	private class SaveStoryListener implements ActionListener {

		public void actionPerformed(ActionEvent e) {
			saveStory();
		}

	}

	private class ExitStoryListener implements ActionListener {

		public void actionPerformed(ActionEvent e){
			System.exit(1);
		}

	}

	private class PreferencesListener implements ActionListener {

		public void actionPerformed(ActionEvent e) {
	    	loadPreferencePopup();
	    }

	}

	/**
	 * This will be executed in order to repaint the StoryBoardList
	 * @return
	 */
	@SuppressWarnings("unused")
	private Runnable createStoryBoardRepainter() {
		return new Runnable() {

			/**
			 * Repaint callback
			 */
			public void run() {
				try {
					SwingUtilities.invokeAndWait(new Runnable() {

						public void run() {
							storyPanel.repaint();
						}
					});
				}
				catch (Exception x) {
					//tough luck
				}
			}

		};
	}

	public StorySettings getTestProperties(){
		StorySettings storySettings = new SimpleStorySettings(
				loginPanel.getUrl(),
				loginPanel.getUsername(),
				loginPanel.getPassword(),
				loginPanel.getSeperateSession()
				);
		return storySettings;
	}

	public void testRunning() {
		loadStory.setEnabled(false);
	}

	public void testFinished() {

		loadStory.setEnabled(true);
	}

}
