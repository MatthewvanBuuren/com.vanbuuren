package com.markit.markithub.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListCellRenderer;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;

import com.markit.markithub.test.model.Result;
import com.markit.markithub.test.model.State;
import com.markit.markithub.test.model.Task;

public class ChapterListCellRenderer extends JPanel implements ListCellRenderer {

	private static final long serialVersionUID = 1L;

	private static final String PENDING_IMG = "images/pending.png";
	private static final String EXECUTING_IMG = "images/exe.png";
	private static final String FINISHED_IMG = "images/fin.png";

	private final Color foreground = new Color(0, 0, 0);
	private final Color pending = new Color(190, 190, 190);
	private final Color executing = new Color(225, 255, 51);
	private final Color finishedSucceeded = new Color(100, 255, 100);
	private final Color finishedFailed = new Color(200, 0, 0);

	private final JLabel taskName;
	private final JLabel taskState;

	//Synonymous with Task.state
	private final ImageIcon pendingIcon;
	private final ImageIcon executingIcon;
	private final ImageIcon finishedIcon;

	public ChapterListCellRenderer() {
		super(new BorderLayout());
		pendingIcon = new ImageIcon(StoryCreator.getClasspathImage(PENDING_IMG));
		executingIcon = new ImageIcon(StoryCreator.getClasspathImage(EXECUTING_IMG));
		finishedIcon = new ImageIcon(StoryCreator.getClasspathImage(FINISHED_IMG));

		taskName = new JLabel();
		taskState = new JLabel(executingIcon);

		add(taskName, BorderLayout.WEST);
		add(taskState, BorderLayout.EAST);
		setBorder(new PaddingBorder(10));
	}

	public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
		if (value!=null) {
			taskName.setText(value.toString());
			update((Task) value);
			taskName.setForeground(foreground);
			setBorder(new PaddingBorder(10));
		}
		if (isSelected) {
			setBorder(new CompoundBorder
				      (BorderFactory.createRaisedBevelBorder(),
				       new EmptyBorder(8,8,8,8)));
		}
	    return this;
	}

	private void update(Task task) {
		switch (State.valueOf(task.getState().toString())) {
			case PENDING:
				taskState.setIcon(pendingIcon);
				setBackground(pending);
				break;
			case EXECUTING: taskState.setIcon(executingIcon);
				setBackground(executing);
				break;
			case FINISHED: taskState.setIcon(finishedIcon);
				if(task.getTaskResult().getResult().equals(Result.succeeded)){
					setBackground(finishedSucceeded);
				} else {
					setBackground(finishedFailed);
				}

				break;
		}
	}

}
