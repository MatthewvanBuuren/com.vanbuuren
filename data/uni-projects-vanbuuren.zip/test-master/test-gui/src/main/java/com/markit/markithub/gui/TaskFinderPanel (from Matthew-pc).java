package com.markit.markithub.gui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SpringLayout;
import javax.swing.SwingUtilities;
import javax.swing.border.TitledBorder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.markit.markithub.test.model.Story;
import com.markit.markithub.test.model.Task;
import com.markit.markithub.test.model.TaskArea;
import com.markit.markithub.test.model.TaskBase;
import com.markit.markithub.test.model.TaskLibrary;

/**
 * Task Runner Application
 */
public class TaskFinderPanel extends JPanel implements ActionListener {

	private static Logger logger = LoggerFactory.getLogger(StoryCreator.class);
	private static final long serialVersionUID = 1L;

	private static final String ADD_IMAGE = "images/add.png";

	private final List<TaskArea> taskAreas;

	private final JPanel taskChooserPanel;
	private final JPanel taskDetailsPanel;
	private final JPanel taskControlPanel;

	private JLabel countLabel;
	private Integer taskCount = 1;

	private TaskArea lastSelectedArea = null;
	private JComboBox areasCombo;
	private JComboBox taskCombo;
	private DefaultComboBoxModel taskModel;

	private JTextArea taskName;
	private JTextArea taskDesc;
	private JButton addButton;

	private final Story<Task> story;

	public TaskFinderPanel(Story<Task> story, TaskLibrary library) {
		this.story = story;
		this.taskAreas = library.getTaskAreas();
		GridBagConstraints c = new GridBagConstraints();
		setLayout(new GridBagLayout());
		setBorder(new PaddingBorder(10, 0, 10, 10));

		taskChooserPanel = createTaskSelectorPanel();
        taskDetailsPanel = createTaskDetailsPanel();
		taskControlPanel = createTaskControlPanel();

		// selector
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 0;
		c.fill = GridBagConstraints.HORIZONTAL;
		c.anchor = GridBagConstraints.FIRST_LINE_START;
		add(taskChooserPanel, c);

		// details
		c = new GridBagConstraints();
		c.gridx = 1;
		c.gridy = 0;
		c.fill = GridBagConstraints.HORIZONTAL;
		c.anchor = GridBagConstraints.PAGE_START;
		c.insets.left = 10;
		add(taskDetailsPanel, c);

		// controls
		c = new GridBagConstraints();
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 2;
		c.weightx = 1;
		c.anchor = GridBagConstraints.LINE_END;
		c.insets.left = 10;
		add(taskControlPanel, c);
		updateTaskList();
	}

	private JPanel createTaskSelectorPanel() {
		JPanel taskChooserPanel = new JPanel(new SpringLayout());
		JLabel areaLabel = new JLabel("Area", JLabel.TRAILING);
		JLabel taskLabel = new JLabel("Task", JLabel.TRAILING);
		areasCombo = getTaskAreas();
		taskCombo = getTasks();
		areasCombo.addActionListener(this);
		taskCombo.addActionListener(this);
		areaLabel.setLabelFor(areasCombo);
		taskLabel.setLabelFor(taskCombo);
		taskChooserPanel.add(areaLabel);
		taskChooserPanel.add(areasCombo);
		taskChooserPanel.add(taskLabel);
		taskChooserPanel.add(taskCombo);
		taskChooserPanel.setBorder(new TitledBorder("Choose Task"));
        SpringUtilities.makeCompactGrid(taskChooserPanel,
        		2, 2, 		 //rows, cols
                6, 6,        //initX, initY
                10, 10);       //xPad, yPad
		return taskChooserPanel;
	}

	private JPanel createTaskDetailsPanel() {
		JPanel taskDetailsPanel = new JPanel(new SpringLayout());
		JLabel nameLabel = new JLabel("Name:");
		JLabel descLabel = new JLabel("Description:");
		taskName = new JTextArea();
		taskDesc = new JTextArea(3, 20);
		taskDesc.setEditable(false);
		taskDesc.setWrapStyleWord(true);
		JScrollPane scroll = new JScrollPane(taskDesc);
		scroll.setBorder(null);
		taskDesc.setLineWrap(true);
		taskName.setEditable(false);

		nameLabel.setLabelFor(taskName);
		descLabel.setLabelFor(taskDesc);

		taskDetailsPanel.add(nameLabel);
		taskDetailsPanel.add(taskName);
		taskDetailsPanel.add(descLabel);
		taskDetailsPanel.add(scroll);

		taskDetailsPanel.setBorder(new TitledBorder("Task Details"));
		SpringUtilities.makeCompactGrid(taskDetailsPanel,
        		2, 2, 		 //rows, cols
                6, 6,        //initX, initY
                10, 10);       //xPad, yPad
		return taskDetailsPanel;
	}

	private JPanel createTaskControlPanel() {
		JPanel controls = new JPanel();
		ImageIcon addIcon = new ImageIcon(StoryCreator.getClasspathImage(ADD_IMAGE));
		addButton = new ImageButton(addIcon, "Add Task to Story");
		addButton.addActionListener(this);
		addButton.setMargin(new Insets(1,1,1,1));
		controls.add(addButton);
		return controls;
	}

	/*
	 * Get the different Task Areas
	 */
	private JComboBox getTaskAreas() {
		JComboBox combo = new JComboBox(taskAreas.toArray());
		return combo;
	}

	/*
	 * Get the different Task Areas
	 */
	private JComboBox getTasks() {
		taskModel = new DefaultComboBoxModel();
		return new JComboBox(taskModel);
	}

	public boolean decreaseTaskCount() {
		if (taskCount!=1) {
			taskCount--;
			return true;
		}
		return false;
	}

	public void increaseTaskCount() {
		taskCount++;
	}

	public int getCurrentTaskCount() {
		return taskCount;
	}

	public void updateTaskCount() {
		countLabel.setText(taskCount.toString());
	}

	private void updateTaskList() {
		TaskArea selectedArea = TaskArea.class.cast(areasCombo.getSelectedItem());
		if (lastSelectedArea != selectedArea) {
			lastSelectedArea = selectedArea;
			logger.debug("Updating area to " + selectedArea);
			updateModel(taskModel, selectedArea);
		}
		else {
			logger.debug("Not updating combos as the index has not changed");
		}
	}

	private void updateModel(DefaultComboBoxModel model, TaskArea selectedArea) {
		model.removeAllElements();
		for (Task task : selectedArea.getTasks()) {
			model.addElement(task);
		}
        SpringUtilities.makeCompactGrid(taskCombo.getParent(),
        		2, 2, 		 //rows, cols
                6, 6,        //initX, initY
                6, 6);       //xPad, yPad
	}

	private void updateTask() {
		Task task = Task.class.cast(taskCombo.getSelectedItem());
		if (task!=null) {
			taskName.setText(task.getName());
			taskDesc.setText(task.getDescription());
		}
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == addButton) {
			addTask();
		}
		else if (e.getSource() == areasCombo) {
			updateTaskList();
		}
		else if (e.getSource() == taskCombo) {
			updateTask();
		}
		else {
			return;
		}
	}

	private void addTask() {
		SwingUtilities.invokeLater(new Runnable() {

			public void run() {
				try {
					Task selected = TaskBase.class.cast(taskCombo.getSelectedItem());
					Task newTask = selected.getClass().newInstance();
					story.addTask(newTask);
					repaint();
				}
				catch (Exception x) {
					logger.error("Could not add task to Storyboard", x);
				}
			}
		});
	}

	public void lock() {
		addButton.setEnabled(false);
	}

	public void unlock() {
		addButton.setEnabled(true);
	}

}
