package com.markit.markithub.test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.markit.markithub.test.model.State;
import com.markit.markithub.test.model.StepResult;
import com.markit.markithub.test.model.TaskResult;
import com.markit.markithub.test.service.FutureManager;

/**
 * Responsible for processing Futures and updating accordingly.
 */
public class TaskCheckerThread implements Callable<Void> {

	private static final Logger logger = LoggerFactory.getLogger(TaskCheckerThread.class);

	private final FutureManager<TaskResult<StepResult>> provider;
	private final List<TaskResult<StepResult>> results;

	public TaskCheckerThread(FutureManager<TaskResult<StepResult>> provider) {
		this.provider = provider;
		this.results = new ArrayList<TaskResult<StepResult>>();
	}

	/*
	 * Check Futures of Tasks and handle appropriately
	 *
	 * (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public Void call() throws Exception {
		while (!isFinished()) {
			Set<Future<TaskResult<StepResult>>> finished = new HashSet<Future<TaskResult<StepResult>>>();
			Set<Future<TaskResult<StepResult>>> cancelled = new HashSet<Future<TaskResult<StepResult>>>();
			Set<Future<TaskResult<StepResult>>> errors = new HashSet<Future<TaskResult<StepResult>>>();
			for (Future<TaskResult<StepResult>> result : provider.getFutures()) {
				if (result.isDone()) {
					try {
						result.get();
						logger.info("Task finished");
						finished.add(result);
					}
					catch (ExecutionException ee) {
						logger.error("Task execution failed", ee);
						errors.add(result);
					}
				}
				else if (result.isCancelled()) {
					logger.info("Task cancelled");
					cancelled.add(result);
				}
				else {
					logger.info("Task still running");
				}
			}
			processCancelledResult(cancelled);
			processFinishedResult(finished);
			processErroneousTasks(errors);
			Thread.sleep(1000);
		}
		return null;
	}

	private boolean isFinished() throws InterruptedException, ExecutionException {
		Iterator<Future<TaskResult<StepResult>>> iterator = provider.getFutures().iterator();
		while (iterator.hasNext()) {
			Future<TaskResult<StepResult>> future = iterator.next();
			if (!future.isDone()) {
				return false;
			}
		}
		return true;
	}

	/*
	 * Do something with finished Result
	 */
	private void processFinishedResult(Set<Future<TaskResult<StepResult>>> finished) throws InterruptedException, ExecutionException {
		for (Future<TaskResult<StepResult>> result : finished) {
			TaskResult<StepResult> task = result.get();
			task.setState(State.FINISHED);
			addToResultList(task);
		}
		provider.removeFutures(finished);
	}

	/*
	 * Remove cancelled Result
	 */
	private void processCancelledResult(Set<Future<TaskResult<StepResult>>> cancelled) throws InterruptedException, ExecutionException {
		for (Future<TaskResult<StepResult>> result : cancelled) {
			TaskResult<StepResult> task = result.get();
			task.setState(State.FINISHED);
			addToResultList(task);
		}
		provider.removeFutures(cancelled);
	}

	/*
	 * Handle Tasks which failed
	 */
	private void processErroneousTasks(Set<Future<TaskResult<StepResult>>> exceptions) throws InterruptedException, ExecutionException {
		for (Future<TaskResult<StepResult>> result : exceptions) {
			TaskResult<StepResult> task = result.get();
			task.setState(State.FINISHED);
			addToResultList(task);
		}
		provider.removeFutures(exceptions);
	}

	/**
	 * Cancel all Future tasks
	 */
	public void cancelAllFutures() {
		for (Future<TaskResult<StepResult>> result : provider.getFutures()) {
			result.cancel(true);
		}
	}

	/*
	 * Add a result to List<TaskResult> results to keep list of results in order
	 */
	private void addToResultList(TaskResult<StepResult> result){
		results.add(result);
	}

	/*
	 * Add a result to List<TaskResult> results to keep list of results in order
	 */
	public List<TaskResult<StepResult>> getResultList(){
		return results;
	}
}
