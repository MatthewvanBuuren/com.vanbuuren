package com.markit.markithub.gui;

import com.markit.markithub.test.model.StorySettings;

public class SimpleStorySettings implements StorySettings {

	private final String url;
	private final String username;
	private final String password;
	private final boolean seperateSession;

	public SimpleStorySettings(String url,String username,String password,boolean seperateSession){
		this.url = url;
		this.username = username;
		this.password = password;
		this.seperateSession = seperateSession;
	}

	public String getUrl() {
		return url;
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	public boolean getSeperateSession() {
		return seperateSession;
	}

}
