package com.markit.markithub.service;

import java.util.concurrent.TimeoutException;

import com.thoughtworks.selenium.Selenium;

public class TimedFunctionsMs {

	private final Selenium instance;

	private static final int MAX_WAIT_MS = 6000;

	public TimedFunctionsMs(Selenium instance){
		this.instance = instance;
	}

	public long waitForElementMs(String locator) throws TimeoutException{
		return waitForElementMs(locator, MAX_WAIT_MS);
	}

	public long waitForElementMs(String locator, long timeoutMs) throws TimeoutException{
		long startTime = System.currentTimeMillis();
		for(int x = 0 ;; x++){
			if(x > timeoutMs){
				throw new TimeoutException();
			}
			if(instance.isElementPresent(locator)){
				return System.currentTimeMillis() - startTime;
			}
		}
	}
}
