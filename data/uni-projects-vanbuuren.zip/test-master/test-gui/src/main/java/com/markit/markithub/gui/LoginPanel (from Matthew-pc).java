package com.markit.markithub.gui;

import java.awt.FlowLayout;
import java.io.File;
import java.net.URL;
import java.util.Map;
import java.util.Properties;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.markit.markithub.service.LoginDetailsDao;
import com.markit.markithub.service.loginDetails;

public class LoginPanel extends JPanel {

	private static final Logger logger = LoggerFactory.getLogger(LoginPanel.class);

	private static final String DEFAULT_USERNAME = "username";
	private static final String DEFAULT_PASSWORD = "password";
	private static final String DEFAULT_URL = "http://www.hub.com";

	private static final long serialVersionUID = 1L;

	private final JTextField url;
	private final JTextField user;
	private final JTextField pass;
	private final JRadioButton seperateSession;

	public LoginPanel() {
		url = new JTextField(DEFAULT_URL, 10);
		user = new JTextField(DEFAULT_USERNAME, 10);
		pass = new JPasswordField(DEFAULT_PASSWORD, 10);
		seperateSession = new JRadioButton();
		setLayout(new FlowLayout());
		add(new JLabel("URL:"));
		add(url);
		add(new JLabel("Username:"));
		add(user);
		add(new JLabel("Password:"));
		add(pass);
		add(new JLabel("Seperate Browser Session:"));
		add(seperateSession);
		loadUserSettings();
	}

	private void loadUserSettings() {
       URL propsUrl = ClassLoader.getSystemResource("application.properties");
       if (propsUrl!=null) {
    	   try {
	    	   Properties p = new Properties();
	    	   p.load(propsUrl.openStream());
	    	   user.setText(p.getProperty(DEFAULT_USERNAME));
	    	   pass.setText(p.getProperty("password"));
	    	   url.setText(p.getProperty("url"));
	    	   seperateSession.setEnabled((p.getProperty("sharedSession").equals("1")));
    	   }
    	   catch (Exception x) {}
       }
       else {
    	   logger.debug("Could not find application properties");
       }
       File settings = new File(System.getProperty("user.home") + File.separator + "Elequince.htr");
       try{
    	   if(settings.exists()){
    		   Map<String,String> map = LoginDetailsDao.readDetails(settings);
    		   if(map.get(loginDetails.SAVEDSETTINGS.toString()).equals("true") && !map.get(loginDetails.SAVEDSETTINGS.toString()).equals("false")){
    			   	url.setText(map.get(loginDetails.URL.toString()));
    			   	user.setText(map.get(loginDetails.USERNAME.toString()));
    		   		pass.setText(map.get(loginDetails.PASSWORD.toString()));
    		   		seperateSession.setSelected(map.get(loginDetails.SEPERATESESSION.toString()).equals("true"));
    		   		logger.info("Read settings from HubTestRunner.htr");
    		   }
    	   }
       }catch(Exception e){
    	   logger.error("Failed to read settings from HubTestRunner.htr",e);
       }
	}

	public String getUsername() {
		return user.getText();
	}

	public String getPassword() {
		return pass.getText();
	}

	public String getUrl() {
		return url.getText();
	}

	public boolean getSeperateSession(){
		return seperateSession.isSelected();
	}

}
