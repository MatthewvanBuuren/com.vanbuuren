package com.markit.markithub.gui;

import java.io.Serializable;

import javax.swing.JList;
import javax.swing.ListModel;

public class StoryList extends JList implements Serializable {

	private static final long serialVersionUID = 1L;

	public StoryList(ListModel dataModel) {
		super(dataModel);
		this.setCellRenderer(new ChapterListCellRenderer());
	}

}

