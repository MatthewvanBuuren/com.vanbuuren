package com.markit.markithub.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class ResultsFileListener implements ActionListener {

	public static final String RESULTS_FOLDER = "hub-test-results";
	public static final String RESULTS_FILE = "test-results.html";

	public static final boolean IS_WINDOWS = !System.getProperty("os.name").startsWith("Mac");
	/*
	 * (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e) {
		Runtime runtime = Runtime.getRuntime();
		try {
			String file = System.getProperty("user.home") + File.separator + RESULTS_FOLDER + File.separator + System.getProperty("RESULTS_FILE") + File.separator + RESULTS_FILE;
			if (IS_WINDOWS) {
				Process exec = runtime.exec("cmd.exe /C " + "\"" + file + "\"");

				exec.waitFor();
			}else{
				//mac
				Process exec = runtime.exec("open " + file);
				exec.waitFor();
			}
		}
		catch (IOException e1) {
			e1.printStackTrace();
		}
		catch (InterruptedException ex) {
			ex.printStackTrace();
		}
	}

}
