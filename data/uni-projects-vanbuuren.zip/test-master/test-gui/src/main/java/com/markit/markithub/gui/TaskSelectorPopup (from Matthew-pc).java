package com.markit.markithub.gui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.markit.markithub.test.main.SimpleTaskLibrary;
import com.markit.markithub.test.model.Task;
import com.markit.markithub.test.model.TaskArea;
import com.markit.markithub.test.model.TaskLibrary;

public class TaskSelectorPopup extends JFrame implements WindowListener, ListSelectionListener {

	private static final long serialVersionUID = 1L;
	private final StoryBoardPanel boardPanel;
	private final TaskLibrary library = new SimpleTaskLibrary();

	private DefaultListModel areas;
	private DefaultListModel tasks;
	private JList taskList;
	private JList areaList;
	private JButton addButton;
	private JLabel description;

	private static final int POPUP_WIDTH = 500;
	private static final int POPUP_HEIGHT = 300;
	private static final int BORDER_WIDTH = 10;
	private static final int SCROLLBAR_WIDTH = 15;

	private static final int NUMBER_DISPLAY_CELLS = 10;

	public TaskSelectorPopup(StoryBoardPanel boardPanel) {
		this.boardPanel = boardPanel;
		setSize(POPUP_WIDTH,POPUP_HEIGHT);
		setResizable(false);
		setLocationRelativeTo(boardPanel);
		addWindowListener(this);
		Container contentPane = getContentPane();
		JPanel panel = new JPanel(new BorderLayout());
		panel.add(createDescription(), BorderLayout.NORTH);
		panel.add(createTaskLists(), BorderLayout.CENTER);
		panel.add(createAddButton(), BorderLayout.SOUTH);
		contentPane.add(panel);
	}

	private JPanel createDescription() {
		JPanel panel = new JPanel(new FlowLayout());
		this.description = new JLabel(" ");
		panel.add(description);
		return panel;
	}

	private JPanel createAddButton() {
		JPanel panel = new JPanel();
		addButton = new JButton(" Add +");
		JButton closeButton = new JButton("close");
		closeButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				TaskSelectorPopup.this.setVisible(false);
				boardPanel.popupClosing();
			}
		});
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				addButton.setEnabled(false);
			}
		});
		addButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int[] selectedIndices = taskList.getSelectedIndices();
				for (int i : selectedIndices) {
					Task task = (Task) tasks.get(i);
					addToStory(task);
				}
			}

		});
		panel.add(addButton);
		panel.add(closeButton);
		return panel;
	}

	private JPanel createTaskLists() {
		JPanel panel = new JPanel(new GridLayout(0,2));
		panel.setSize(getWidth(), getHeight()-50);
		areas = new DefaultListModel();

		for (TaskArea area : library.getTaskAreas()) {
			areas.addElement(area);
		}


		tasks = new DefaultListModel();
		areaList = new JList(areas);
		areaList.setVisibleRowCount(NUMBER_DISPLAY_CELLS);
		JScrollPane scrollPaneArea = new JScrollPane(areaList);
		taskList = new JList(tasks);
		taskList.setVisibleRowCount(NUMBER_DISPLAY_CELLS);
		JScrollPane scrollPaneTask = new JScrollPane(taskList);
		areaList.addListSelectionListener(this);
		taskList.addListSelectionListener(this);
		areaList.setSelectedIndex(0);
		areaList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		taskList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

		JPanel panelArea = new JPanel(new FlowLayout());
		panelArea.add(new JLabel("Areas"));
		panelArea.add(scrollPaneArea);
		panel.add(panelArea);
		JPanel panelTask = new JPanel(new FlowLayout());
		panelTask.add(new JLabel("Tasks"));
		panelTask.add(scrollPaneTask);
		panel.add(panelTask);
		panelTask.setSize(panel.getWidth()/2, panel.getHeight());
		panelArea.setSize(panel.getWidth()/2, panel.getHeight());
		scrollPaneTask.setSize(panelTask.getWidth(), panelTask.getHeight());
		scrollPaneArea.setSize(panelArea.getWidth(),panelArea.getHeight());
		taskList.setSize(scrollPaneTask.getWidth()- BORDER_WIDTH,scrollPaneTask.getHeight());
		areaList.setSize(scrollPaneArea.getWidth()- BORDER_WIDTH,scrollPaneArea.getHeight());
		if(areas.size() > NUMBER_DISPLAY_CELLS){
			areaList.setFixedCellWidth((POPUP_WIDTH/2)- SCROLLBAR_WIDTH - (BORDER_WIDTH*2));
		} else {
			areaList.setFixedCellWidth((POPUP_WIDTH/2) - (BORDER_WIDTH*2));
		}
		if(tasks.size() > NUMBER_DISPLAY_CELLS){
			taskList.setFixedCellWidth((POPUP_WIDTH/2)- SCROLLBAR_WIDTH - (BORDER_WIDTH*2));
		} else {
			taskList.setFixedCellWidth((POPUP_WIDTH/2) - (BORDER_WIDTH*2));
		}

		taskList.addMouseListener(new MouseAdapter() {
		    public void mouseClicked(MouseEvent evt) {
		        JList list = (JList)evt.getSource();
		        if (evt.getClickCount() == 2) {          // Double-click
		            int index = list.locationToIndex(evt.getPoint());
		            Task task = (Task) tasks.get(index);
					addToStory(task);
		        }
		    }
		});
		return panel;
	}

	/*
	 * When Area is changed
	 * (non-Javadoc)
	 * @see javax.swing.event.ListSelectionListener#valueChanged(javax.swing.event.ListSelectionEvent)
	 */
	@Override
	public void valueChanged(ListSelectionEvent e) {
		 if (e.getValueIsAdjusting() == false) {
			 if (e.getSource() == areaList) {
				 areaUpdated();
			 }
			 else if (e.getSource() == taskList) {
				 taskUpdated();
			 }
		 }
	}

	public void areaUpdated() {
		if (areaList.getSelectedIndex() != -1) {
			final TaskArea area = (TaskArea) areaList.getSelectedValue();
			SwingUtilities.invokeLater(new Runnable() {

				@Override
				public void run() {

					tasks.removeAllElements();
					for (Task task : area.getTasks()) {
						tasks.addElement(task);
					}
				}
			});
		}
	}

	public void taskUpdated() {
		if (taskList.getSelectedIndex() != -1) {
			int lastSelected = taskList.getLeadSelectionIndex();
			final Task task = (Task) tasks.getElementAt(lastSelected);
			SwingUtilities.invokeLater(new Runnable() {

				@Override
				public void run() {
					updateDescription(task);
					addButton.setEnabled(true);

				}

			});
		}
		else {
			SwingUtilities.invokeLater(new Runnable() {

				@Override
				public void run() {
					addButton.setEnabled(false);
				}
			});
		}
		if(tasks.size() > NUMBER_DISPLAY_CELLS){
			taskList.setFixedCellWidth((POPUP_WIDTH/2)- SCROLLBAR_WIDTH - (BORDER_WIDTH*2));
		} else {
			taskList.setFixedCellWidth((POPUP_WIDTH/2) - (BORDER_WIDTH*2));
		}

	}

	private void updateDescription(final Task task) {
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				description.setText(task.getDescription());
			}
		});
	}

	private void addToStory(Task task) {
		boardPanel.addTask(task);
	}

	@Override
	public void windowClosing(WindowEvent e) {
		boardPanel.popupClosing();
	}
	@Override
	public void windowOpened(WindowEvent e) {}
	@Override
	public void windowClosed(WindowEvent e) {}
	@Override
	public void windowIconified(WindowEvent e) {}
	@Override
	public void windowDeiconified(WindowEvent e) {}
	@Override
	public void windowActivated(WindowEvent e) {}
	@Override
	public void windowDeactivated(WindowEvent e) {}

	public static void main(String[] args) {
		new TaskSelectorPopup(null).setVisible(true);
	}

}
