package com.markit.markithub.test;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingWorker;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.markit.markithub.reporter.Reporter;
import com.markit.markithub.test.model.Result;
import com.markit.markithub.test.model.SeleniumInstanceFactory;
import com.markit.markithub.test.model.SeleniumStartOptions;
import com.markit.markithub.test.model.State;
import com.markit.markithub.test.model.StepBase;
import com.markit.markithub.test.model.StepResult;
import com.markit.markithub.test.model.Story;
import com.markit.markithub.test.model.StorySettings;
import com.markit.markithub.test.model.Task;
import com.markit.markithub.test.model.TaskResult;
import com.markit.markithub.test.service.SeleniumInstanceExecutor;
import com.markit.markithub.test.service.SimpleStepExecutor;
import com.markit.markithub.util.FileUtils;
import com.thoughtworks.selenium.Selenium;

public class TaskExecutingSwingWorker extends SwingWorker<Story<Task>, Task> {

	private static Logger logger = LoggerFactory.getLogger(TaskExecutingSwingWorker.class);

	private final Story<Task> story;
	private final Runnable finishedCallback;
	private final Reporter reporter;
	private final StorySettings storySettings;
	private static final String RESULTS_FOLDER = "hub-test-results";
	private static final int MAX_ATTEMPTS = 1;
	private File outputFile;

	private final SeleniumInstanceFactory seleniumFactory = new SeleniumInstanceExecutor();
	private SimpleStepExecutor executor;

	private Selenium sharedSelenium;

	public TaskExecutingSwingWorker(Story<Task> story, Runnable finishedCallback, StorySettings storySettings) {
		this.story = story;
		this.finishedCallback = finishedCallback;
		this.storySettings = storySettings;
		executor = new SimpleStepExecutor(storySettings);
		if (!storySettings.getSeperateSession()) {
			sharedSelenium = seleniumFactory.createSeleniumInstance(storySettings.getUrl());
			logger.debug("Creating shared instance.");
		}
		try {
			reporter = new Reporter();
		}
		catch(Exception e){
			throw new RuntimeException("Reporter could not be initialised");
		}
	}

	@Override
	protected Story<Task> doInBackground() throws Exception {
		if (!storySettings.getSeperateSession()) {
			logger.debug("Starting shared selenium instance");
			sharedSelenium.start(SeleniumStartOptions.captureNetworkTraffic_True);
			logger.debug("Starting.... With captureNetworkTraffic=true");
			logger.debug("Succesfully started shared selenium instance");
		}
		int total = story.getTasks().size();
		int processed = 0;
		outputFile = FileUtils.createResultsFolder(RESULTS_FOLDER,story.getTitle());
		setProgress((int) (((100/total)/2)+0.5));
		for (Task task : story.getTasks()) {
			task.setUrl(storySettings.getUrl());
			task.setState(State.EXECUTING);
			int attempt = 0;
			boolean rerun = true;
			while(rerun && attempt < MAX_ATTEMPTS){
				if (!storySettings.getSeperateSession()) {
					processTaskSingleSession(task,outputFile);
				}
				else {
					processTaskMultiSession(task,outputFile);
				}
				//Re-run Task if it failed, Else continue.
				if(!task.getTaskResult().getResult().equals(Result.failed)){
					rerun = false;
				}
				attempt++;
			}
			//TODO - If Failed twice email duty officer.
			publish(task);
			processed++;
			setProgress(100 * processed / total);
		}
		if (!storySettings.getSeperateSession()) {
			sharedSelenium.stop();
		}
		return story;
	}

	/*
	 * When it's done we will create a Report and free up the GUI for the next
	 * Story
	 *
	 * # THIS IS ON THE EVENT THREAD
	 *
	 * (non-Javadoc)
	 *
	 * @see javax.swing.SwingWorker#done()
	 */
	@Override
	protected void done() {
		setProgress(100);
		logger.info("Story has finished executing");
		finishedCallback.run();
		List<TaskResult<StepResult>> storyReport = new ArrayList<TaskResult<StepResult>>();
		for(Task task : story.getTasks()){
			storyReport.add(task.getTaskResult());
		}
		try{
			reporter.generateStoryReport(story.getTitle(), storyReport, outputFile);
		}
		catch(Exception e){
			logger.info("Error creating story report.: " + e.getMessage());
		}
	}


	/* Intermediate Result updates to the GUI
	 *
	 * # THIS IS ON THE EVENT THREAD
	 *
	 * (non-Javadoc)
	 * @see javax.swing.SwingWorker#process(java.util.List)
	 */
	@Override
	protected void process(List<Task> chunks) {
		for (Task t : chunks) {
			t.setState(State.FINISHED);
		}
	}

	/*
	 * New Session for each Task
	 */
	private void processTaskMultiSession(final Task task,final File outputFile) {
		Selenium selenium = seleniumFactory.createSeleniumInstance(task.getUrl());
		selenium.start(SeleniumStartOptions.captureNetworkTraffic_True);
		try {
			logger.info("executing task (sleep)");
			task.setSelenium(selenium);
			for(StepBase step : task.getSteps()){

				step.setStepResult(executor.run(step,outputFile));
			}
		}
		catch (Exception x) {
			logger.error("Could not process task", x);
		}
		finally {
			selenium.stop();
		}
	}


	/*
	 * Single Session for all Tasks
	 */
	private void processTaskSingleSession(final Task task,final File outputFile) {
		try {
			logger.info("executing task (sleep)");
			task.setSelenium(sharedSelenium);
			for(StepBase step : task.getSteps()) {
				step.setStepResult(executor.run(step,outputFile));
			}
		}
		catch (Exception x) {
			logger.error("Could not process task", x);
		}
	}
}
