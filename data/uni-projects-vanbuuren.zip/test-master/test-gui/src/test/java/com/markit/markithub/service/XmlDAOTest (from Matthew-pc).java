package com.markit.markithub.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.util.Random;

import org.junit.Test;

import com.markit.markithub.service.api.StoryDao;
import com.markit.markithub.test.model.SimpleStory;
import com.markit.markithub.test.model.Story;
import com.markit.markithub.test.model.Task;
import com.markit.markithub.test.tasks.LoginTask;

public class XmlDAOTest {

	private StoryDao DAO = new XmlSerilializedStoryDao();

	private static final String COMPLETE_FOUR_TASKS = "COMPLETE_FOUR_TASKS";
	private static final String COMPLETE_ZERO_TASKS = "COMPLETE_ZERO_TASKS";
	private static final String COMPLETE_TWO_TASKS = "COMPLETE_TWO_TASKS";
	private static final String MISSING_FILE = "";

	@Test
	public void testStoryName() throws Exception {
		Story<Task> story = new SimpleStory();
		String title = "Test Story Title";
		story.setTitle(title);

		File tmp = createTempDir();
		assertTrue(tmp.exists());

		String outputFilename = "Test";
		File outputFile = new File(tmp, outputFilename);
		outputFile.createNewFile();

		System.out.println(outputFile);

		DAO.write(story, outputFile.toURI());
		Story<Task> storyDes = DAO.read(outputFile.toURI());
		assertEquals(title, storyDes.getTitle());
	}

	@Test
	public void testSerializeToXml() throws Exception {
		Story<Task> story = createDummyStory();
		int orgSize = story.getTasks().size();

		File tmp = createTempDir();
		assertTrue(tmp.exists());

		String outputFilename = "Test";
		File outputFile = new File(tmp, outputFilename);
		outputFile.createNewFile();

		DAO.write(story, outputFile.toURI());
		System.out.println(outputFile.toURI());
		Story<Task> storyDes = DAO.read(outputFile.toURI());
		assertEquals(orgSize, storyDes.getTasks().size());
	}

	@Test
	public void testCompleteXml4Tasks() throws Exception {
		URI resource = getFileLocation(COMPLETE_FOUR_TASKS);
		Story<Task> story = DAO.read(resource);
		assertEquals(4,story.getTasks().size());
	}

	@Test
	public void testCompleteXml0Tasks() throws Exception {
		URI resource = getFileLocation(COMPLETE_ZERO_TASKS);
		Story<Task> story = DAO.read(resource);
		assertEquals(0,story.getTasks().size());
	}

	@Test
	public void testCompleteXml2Tasks() throws Exception {
		URI resource = getFileLocation(COMPLETE_TWO_TASKS);
		Story<Task> story = DAO.read(resource);
		assertEquals(2,story.getTasks().size());
	}

	@Test (expected=FileNotFoundException.class)
	public void testMissingFile() throws Exception {
		URI resource = getFileLocation(MISSING_FILE);
		@SuppressWarnings("unused")
		Story<Task> story = DAO.read(resource);
	}

	public URI getFileLocation(String classpathFileName) throws Exception {
		URL resource = ClassLoader.getSystemResource(classpathFileName);
		if (resource == null) {
			throw new IOException("Could not find '" + classpathFileName + "' on the classpath");
		}
		else {
			return resource.toURI();
		}
	}

	private Story<Task> createDummyStory() {
		Story<Task> story = new SimpleStory();
		story.addTask(new LoginTask());
		story.addTask(new LoginTask());
		story.addTask(new LoginTask());
		story.addTask(new LoginTask());
		return story;
	}

	public static File createTempDir() {
	    final String baseTempPath = System.getProperty("java.io.tmpdir");

	    Random rand = new Random();
	    int randomInt = 1 + rand.nextInt();

	    File tempDir = new File(baseTempPath + File.separator + "tempDir" + randomInt);
	    if (tempDir.exists() == false) {
	        tempDir.mkdir();
	    }

	    tempDir.deleteOnExit();

	    return tempDir;
	}

}
