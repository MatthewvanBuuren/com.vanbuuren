//package com.markit.markithub.service;
//
//import com.markit.markithub.test.methods.ResponseFinder;
//import com.markit.markithub.test.model.SeleniumInstanceFactory;
//import com.markit.markithub.test.model.SeleniumStartOptions;
//import com.markit.markithub.test.service.SeleniumInstanceExecutor;
//import com.thoughtworks.selenium.Selenium;
//
//public class SeleniumServerThreadTest {
//
//	private static Selenium selenium;
//	private SeleniumServerThread server;
//
//	private SeleniumInstanceFactory factory = new SeleniumInstanceExecutor();
//
//	public static void main(String[] args){
//		new SeleniumServerThreadTest();
//	}
//
//	public SeleniumServerThreadTest(){
//		server = null;
//		try {
//			server = new SeleniumServerThread(true, true);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		server.start();
//
//		try{
//			selenium = factory.createSeleniumInstance("https://www.qa.hub.com/mp/");
//			selenium.start(SeleniumStartOptions.captureNetworkTraffic_True);
//			selenium.open("/");
//			Thread.sleep(6000);
//			ResponseFinder response = new ResponseFinder();
//			response.get200GETResponse("//input[@value='Submit']", selenium);
//		}catch(Exception e){
//			try {
//				Thread.sleep(1000);
//			} catch (InterruptedException e1) {
//				e1.printStackTrace();
//			}
//			System.out.println("Error here... " + e);
//		}finally{
//			selenium.stop();
//			server.kill();
//		}
//	}
//}
