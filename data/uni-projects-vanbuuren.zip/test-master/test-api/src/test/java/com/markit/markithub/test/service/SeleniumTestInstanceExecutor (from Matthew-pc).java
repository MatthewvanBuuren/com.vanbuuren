package com.markit.markithub.test.service;

import org.junit.Test;

import com.markit.markithub.test.model.SeleniumInstanceFactory;
import com.thoughtworks.selenium.Selenium;

public class SeleniumTestInstanceExecutor {

	private SeleniumInstanceFactory factory = new SeleniumInstanceExecutor();
	private Selenium seleniumInstance1;
	private Selenium seleniumInstance2;

	@Test
	public void testLoadInstance(){
		seleniumInstance1 = factory.createSeleniumInstance("http://www.google.com");
		seleniumInstance1.start();
		seleniumInstance1.windowFocus();
		seleniumInstance1.windowMaximize();
		seleniumInstance1.open("/");
		seleniumInstance1.close();
		factory.destroySeleniumInstance(seleniumInstance1);
	}

	@Test
	public void testMultipleInstances(){
		try{
			seleniumInstance1 = factory.createSeleniumInstance("http://www.google.com");
			seleniumInstance1.start("captureNetworkTraffic=True");
			seleniumInstance1.windowFocus();
			seleniumInstance1.windowMaximize();
			seleniumInstance1.open("/");
			seleniumInstance2 = factory.createSeleniumInstance("http://www.hub.com");
			seleniumInstance2.start();
			seleniumInstance2.windowFocus();
			seleniumInstance2.windowMaximize();
			seleniumInstance2.open("/");
			factory.destroySeleniumInstance(seleniumInstance1);
			factory.destroySeleniumInstance(seleniumInstance2);
		}catch(Exception e){}
	}

	@Test
	public void testStartAndStop(){
		seleniumInstance1 = factory.createSeleniumInstance("Http://www.google.com");
		seleniumInstance1.start();
		seleniumInstance1.stop();
		seleniumInstance1.start("captureNetowrkTraffic=True");
		seleniumInstance1.windowMaximize();
		seleniumInstance1.close();
		factory.destroySeleniumInstance(seleniumInstance1);
	}



}
