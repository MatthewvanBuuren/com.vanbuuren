package com.markit.markithub.test.model;

public class SimpleStepResult implements StepResult{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private Result result = Result.stateless;
	private String tt = "0";
	private String screenshotName = "";

	public SimpleStepResult(String name){
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public Result getResult() {
		return result;
	}

	public void setResult(Result result) {
		this.result = result;
	}

	public String getTimeTaken() {
		return tt;
	}

	public void setTimeTaken(String tt) {
		this.tt = tt;
	}

	public String getScreenshotName() {
		return screenshotName;
	}

	public void setScreenshotName(String screenshotName) {
		this.screenshotName = screenshotName;
	}

}
