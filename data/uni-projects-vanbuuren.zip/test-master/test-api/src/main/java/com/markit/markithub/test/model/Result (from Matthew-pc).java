package com.markit.markithub.test.model;

public enum Result {

	/*
	 * Test succeeded
	 */
	succeeded,

	/*
	 * Test failed unexpectedly
	 */
	failed,

	/*
	 * Error with a locator caused the test to fail.
	 */
	suspect,

	/*
	 * The State of this Result has not been set.
	 */
	stateless;

}
