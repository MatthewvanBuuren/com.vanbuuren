package com.markit.markithub.test.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PopupManagement {

	private static final Logger logger = LoggerFactory.getLogger(PopupManagement.class);

	/**
	 * Using separate executable confirm Continue/Cancel Pop up
	 * @throws Exception
	 */
	public boolean confirmSecurityWarning() throws Exception {
		try{
			InputStream src =this.getClass().getResourceAsStream("/bin/SecurityWarning.txt");
			if(src!=null) {
				File exeTempFile = File.createTempFile("SecurityWarning", ".exe");
				FileOutputStream out = new FileOutputStream(exeTempFile);
				byte[] temp = new byte[32768];
				int rc;
				while((rc = src.read(temp)) > 0){
					out.write(temp, 0, rc);
				}
				src.close();
				out.close();
				exeTempFile.deleteOnExit();
				logger.info("Outputting temp file: " + exeTempFile.getAbsolutePath());
				Runtime.getRuntime().exec(exeTempFile.toString());
			}else {
	    	System.out.println("Executable not found");
			}
			return true;
		}
		catch (Exception e) {
			logger.debug("Outputting temp file: tmpDirectory\\SecurityWarningxxxxxxxxx.exe Falied!!!! Verify File Available.");
			return false;
		}
	}


	public boolean closePopup(String windowName) {
		try{
			InputStream src =this.getClass().getResourceAsStream("/bin/Close_Window.txt");
			if(src!=null) {
				File exeTempFile = File.createTempFile("Close_Window", ".exe");
				FileOutputStream out = new FileOutputStream(exeTempFile);
				byte[] temp = new byte[32768];
				int rc;
				while((rc = src.read(temp)) > 0){
					out.write(temp, 0, rc);
				}
				src.close();
				out.close();
				exeTempFile.deleteOnExit();
				logger.info("Outputting temp file: " + exeTempFile.getAbsolutePath());
				Runtime.getRuntime().exec(exeTempFile.toString()+ " \"" + windowName + "\"");
			}else {
	    	System.out.println("Executable not found");
			}
			return true;
		}
		catch (Exception e) {
			logger.debug("Outputting temp file: tmpDirectory\\Close_Windowxxxxxxxxx.exe Falied!!!! Verify File Available.");
			return false;
		}
	}

}
