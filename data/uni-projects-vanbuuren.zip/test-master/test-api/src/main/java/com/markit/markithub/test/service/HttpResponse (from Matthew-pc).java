package com.markit.markithub.test.service;

import com.markit.markithub.test.model.ContentType;
import com.markit.markithub.test.model.SpecialContentType;


public class HttpResponse {


	public String code;
	public String method;
	public String host;
	public ContentType contentType;
	public String server;
	public String fileName;

	//Used to get the extensions from the url of the file.
	public SpecialContentType specialContentType;

	/**
	 * A Constructor that takes the Response Code,Method,Host,Content-Type and the file name.
	 *
	 * @param code - String - The Response Code i.e. 200,400,300
	 * @param method - String - The Response method i.e. GET,UPDATE
	 * @param host - String - The host that these come from
	 * @param contentType - String - The type of content being returned, The extension.
	 * @param fileName - String - The file name.
	 */

	public HttpResponse(String code, String method, String host, String contenttype, String fileName, String specialContentType){
		this(code, method, host, contenttype,fileName);
		this.specialContentType = getSpecialType(specialContentType);
	}

	/**
	 * A Constructor that takes the Response Code,Method,Host,Content-Type and the file name.
	 *
	 * @param code - String - The Response Code i.e. 200,400,300
	 * @param method - String - The Response method i.e. GET,UPDATE
	 * @param host - String - The host that these come from
	 * @param contentType - String - The type of content being returned, The extension.
	 * @param fileName - String - The file name.
	 */

	public HttpResponse(String code, String method, String host, String contenttype, String fileName){
		this(code, method, host, contenttype);
		this.fileName = fileName;
	}

	/**
	 * A Shortened Constructor that takes the Response Code,Method,Host and Content-Type.
	 *
	 * @param code - String - The Response Code i.e. 200,400,300
	 * @param method - String - The Reponse method i.e. GET,UPDATE
	 * @param host - String - The host that these come from
	 * @param contentType - String - The type of content being returned, The extension.
	 */

	public HttpResponse(String code, String method, String host, String contentType){
		this.code = code;
		this.method = method;
		this.host = host;
		this.contentType = getType(contentType);
	}

	public ContentType getType(String contentType) {
		if (contentType.contains("text/plain")) {
			return ContentType.PLAIN;
		}
		if (contentType.equals("text/css")) {
			return ContentType.CSS;
		}
		if (contentType.equals("image/gif")) {
			return ContentType.GIF;
		}
		if(contentType.equals("image/png")){
			return ContentType.PNG;
		}
		if (contentType.contains("text/html")) {
			return ContentType.HTML;
		}
		if (contentType.contains("application/pdf")) {
			return ContentType.PDF;
		}
		if (contentType.equals("application/xls")) {
			return ContentType.XLS;
		}
		if (contentType.equals("application/vnd.ms-excel")) {
			return ContentType.XLS;
		}
		if(contentType.equals("application/javascript")) {
			return ContentType.JVS;
		}
		if(contentType.equals("text/javascript")) {
			return ContentType.JVS;
		}
		if(contentType.equals("application/x-javascript")){
			return ContentType.XJVS;
		}
		return ContentType.UNKNOWN;
	}

	/**
	 * Get the special content type enum from a string by matching certains cases.
	 * @param contentType - String - The content type string to be matched.
	 * @return
	 */
	public SpecialContentType getSpecialType(String specialContentType) {
		if (specialContentType.equals("pdf")) {
			return SpecialContentType.PDF;
		}
		if(specialContentType.equals("doc")){
			return SpecialContentType.DOC;
		}
		if(specialContentType.equals("htm")){
			return SpecialContentType.HTM;
		}
		return SpecialContentType.UNKNOWN;
	}

	/**
	 * The content type of this reponse.
	 * @return ContentType - The content type.
	 */
	public ContentType getContentType(){
		return this.contentType;
	}

	public String toString(){
		return "Code: " + code
		+ " Method: " + method
		+ " Host: " + host
		+ " Content-Type: " + contentType.toString()
		+ " Server: " + server
		+ " FileName: " + fileName
		+ " Special Content Type: " + specialContentType;
	}

}
