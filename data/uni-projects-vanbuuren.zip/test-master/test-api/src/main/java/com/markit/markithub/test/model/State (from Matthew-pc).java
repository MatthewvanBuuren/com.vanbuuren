package com.markit.markithub.test.model;

public enum State {

	PENDING, EXECUTING, FINISHED;

}

