package com.markit.markithub.test.model;

public enum ContentType {

	PLAIN,
	XLS,
	PDF,
	GIF,
	PNG,
	HTML,
	CSS,
	JVS,
	XJVS,
	UNKNOWN;

}
