package com.markit.markithub.test.model;

public interface StorySettings {

	public String getUrl();

	public String getUsername();

	public String getPassword();

	public boolean getSeperateSession();
}
