package com.markit.markithub.test.model;

import java.io.Serializable;
import java.util.List;



/**
 * A Story is tasks.
 */
public interface Story<T> extends Serializable {

	/**
	 * Get the name of the Story
	 */
	public String getTitle();

	/**
	 * Set the name of this story.
	 */
	public void setTitle(String name);

	/**
	 * Add a Task to a Story
	 */
	public void addTask(T task);

	/**
	 * Get all Tasks
	 */
	public List<T> getTasks();

	public void setTasks(List<T> allTasks);

}
