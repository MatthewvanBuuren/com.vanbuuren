package com.markit.markithub.test.model;

import java.util.List;



/**
 * Responsible for making the full range of {@link TaskArea} and
 * their contained {@link Task tasks} to the caller.
 */
public interface TaskLibrary {

	/**
	 * Get all available {@link TaskArea taskAreas}
	 */
	public List<TaskArea> getTaskAreas();

}
