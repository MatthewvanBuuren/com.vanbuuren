package com.markit.markithub.test.model;

public enum SpecialContentType {

	DOC,
	PDF,
	HTM,
	UNKNOWN,
	NOT_SPECIFIED;
}
