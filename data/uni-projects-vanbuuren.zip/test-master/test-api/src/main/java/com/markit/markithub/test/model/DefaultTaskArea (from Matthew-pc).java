package com.markit.markithub.test.model;

import java.util.List;

public class DefaultTaskArea implements TaskArea {

	private List<Task> tasks;
	private String name;

	public DefaultTaskArea(List<Task> tasks, String name) {
		this.tasks = tasks;
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public List<Task> getTasks() {
		return tasks;
	}

	@Override
	public String toString() {
		return name;
	}

}
