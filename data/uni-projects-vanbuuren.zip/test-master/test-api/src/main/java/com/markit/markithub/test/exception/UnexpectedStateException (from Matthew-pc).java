package com.markit.markithub.test.exception;

public class UnexpectedStateException extends Exception{
	/**
	 *	An error with a locator has occurred, That element is missing or not found.
	 */
	private static final long serialVersionUID = 1L;

	public UnexpectedStateException(String message){
		super(message);
	}
}
