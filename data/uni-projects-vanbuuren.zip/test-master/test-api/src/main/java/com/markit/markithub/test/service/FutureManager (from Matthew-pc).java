package com.markit.markithub.test.service;

import java.util.Set;
import java.util.concurrent.Future;

/**
 * Responsible for maintaining a list of futures
 * @param <T> - Type of the future
 */
public interface FutureManager<T> {

	public Set<Future<T>> getFutures();

	public void addFuture(Future<T> future);

	public void removeFutures(Set<Future<T>> future);

}
