package com.markit.markithub.test.model;

import java.io.File;

import com.thoughtworks.selenium.Selenium;

public interface Step {

	public void setSeleniumInstance(Selenium selenium);

	public String getName();

	public void primer()throws Exception;

	public void execute() throws Exception;

	public void teardown() throws Exception;


	public void takeScreenshot(String screenshotName, File outputFile);

	public StepResult getStepResult();

	public void setStepResult(StepResult stepResult);
}
