package com.markit.markithub.test.model;

import java.io.Serializable;


public interface StepResult extends Serializable{

	/**
	 *The Name/Description of the Step.
	 * @return String name - Get a name for the step.
	 */
	public String getName();

	/**
	 * The Result of a Step after being executed. {@link Result}
	 * @return Result result - The Result enum.
	 */
	public Result getResult();

	/**
	 * Set the result of this step.
	 * @param result - {@link Result} to be set.
	 */
	public void setResult(Result result);

	/**
	 * Get the time taken to execute this step.
	 * @return tt - The TimeTaken
	 */
	public String getTimeTaken();

	/**
	 * Set the TimeTaken to execute this command.
	 * @param tt - The TimeTaken
	 */
	public void setTimeTaken(String tt);

	/**
	 * Get the name of the screenshot of this step.
	 * @return screenshot - The name of the screenshot
	 */
	public String getScreenshotName();

	/**
	 * Set the name of the screenshot taken for this step.
	 * @param screenshotName - The name of the screenshot.
	 */
	public void setScreenshotName(String screenshotName);
}
