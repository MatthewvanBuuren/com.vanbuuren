package com.markit.markithub.test.model;

import java.io.Serializable;
import java.util.List;




/**
 * Represent the result of a {@link Task} execution
 */
public interface TaskResult<S> extends Serializable{

	/**
	 * Get the name of the task
	 */
	public String getName();

	/**
	 * Get the state of the TaskResult
	 */
	public Result getResult();

	/**
	 * Each {@link StepResult} represents the outcome of the Steps which
	 * composed the representative {@link Task}
	 */
	public List<S> getStepResults();

	/**
	 * Return the number of StepResults
	 */
	public int getNumberOfStepResults();

	/**
	 * Add a StepResult to the List.
	 * @param stepResult
	 */
	public void addStepResult(StepResult stepResult);

	/**
	 * Set the final state of the TaskResult.
	 */
	public void setState(State state);

	/**
	 * Check the state of the TaskResult is Finished.
	 */
	public boolean isFinished();
}
