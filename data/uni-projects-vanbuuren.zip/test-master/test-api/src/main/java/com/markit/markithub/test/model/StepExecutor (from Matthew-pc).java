package com.markit.markithub.test.model;

import java.io.File;

public interface StepExecutor {

	public StepResult run(StepBase step,File outputFile);

}
