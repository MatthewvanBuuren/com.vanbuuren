package com.markit.markithub.test.service;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.markit.markithub.test.model.SeleniumInstanceFactory;
import com.thoughtworks.selenium.DefaultSelenium;
import com.thoughtworks.selenium.Selenium;


public class SeleniumInstanceExecutor implements SeleniumInstanceFactory {

	private static final Logger logger = LoggerFactory.getLogger(SeleniumInstanceExecutor.class);

	private static final String BASE_ADDRESS = "127.0.0.1";
	private static final int BASE_PORT = 4444;
	private static final String BASE_BROWSER_32 = "*firefox C:\\Program Files\\Mozilla Firefox\\firefox.exe";
	private static final String BASE_BROWSER_64 = "*firefox C:\\Program Files (x86)\\Mozilla Firefox\\firefox.exe";

	public Selenium createSeleniumInstance(String baseUrl) {
		try{
			File settings_32 = new File("C:\\Program Files\\Mozilla Firefox\\firefox.exe");
			if(settings_32.exists()){
				logger.debug("Creating Default Selenium on 32-Bit Windows");
				return new DefaultSelenium(BASE_ADDRESS, BASE_PORT, BASE_BROWSER_32, baseUrl);
			} else {
				logger.debug("Creating Default Selenium on 64-Bit Windows");
				return new DefaultSelenium(BASE_ADDRESS, BASE_PORT, BASE_BROWSER_64, baseUrl);
			}
		} catch(Exception e){
			logger.error("Error in createSeleniumInstance: " + e.toString());
			return null;
		} finally {
			logger.debug("Succesfully Created Default Selenium");
		}
	}

	public void destroySeleniumInstance(Selenium selenium) {
		try{
			if(!(selenium == null)){
				selenium.close();
				selenium.stop();
			}
		} catch(Exception e) {
			logger.error("Error in destroySeleniumInstance: " + e.toString());
		}
	}

	public Selenium startSelenium(String baseUrl, boolean networkTraffic) throws Exception{
		Selenium selenium = null;
		try{
			selenium = createSeleniumInstance(baseUrl);
			if(networkTraffic){
				selenium.start("captureNetworkTraffic=true");
				logger.info("Started Selenium Instance with captureNetworkTraffic=true");
			} else {
				selenium.start();
				logger.info("Started Selenium Instance");
			}
			return selenium;
		}catch(Exception e){
			destroySeleniumInstance(selenium);
			logger.error(e.toString());
			throw e;
		}
	}
}
