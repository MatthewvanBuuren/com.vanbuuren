package com.markit.markithub.test.model;

import com.thoughtworks.selenium.Selenium;

/**
 * Responsible for creation and destruction of Selenium runtime
 */
public interface SeleniumInstanceFactory {

	/**
	 * Create a Selenium instance
	 */
	public Selenium createSeleniumInstance(String baseUrl);

	/**
	 * Destroy Selenium instance
	 */
	public void destroySeleniumInstance(Selenium selenium);

}
