package com.markit.markithub.test.model;

import java.io.Serializable;
import java.util.List;

import com.thoughtworks.selenium.Selenium;

public interface Task extends Serializable {

	public String getName();

	public String getDescription();

	public List<StepBase> getSteps();

	public void addStep(StepBase step);

	public void setUrl(String url);

	public String getUrl();

	public State getState();

	public void setState(State state);

	//TODO: move into TaskBase
	public void setSelenium(Selenium selenium);

	public TaskResult<StepResult> getTaskResult();

}
