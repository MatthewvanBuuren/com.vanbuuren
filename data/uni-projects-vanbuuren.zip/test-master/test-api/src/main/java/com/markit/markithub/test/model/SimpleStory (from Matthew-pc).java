package com.markit.markithub.test.model;

import java.util.ArrayList;
import java.util.List;

public class SimpleStory implements Story<Task>{

	private static final long serialVersionUID = 1L;

	private String name;
	private List<Task> allTasks = new ArrayList<Task>();

	public SimpleStory(){

	}

	public String getTitle() {
		return name;
	}

	public void setTitle(String name) {
		this.name = name;
	}

	public void addTask(Task task) {
		allTasks.add(task);
	}

	public List<Task> getTasks() {
		return allTasks;
	}

	public void setTasks(List<Task> allTasks){
		this.allTasks = allTasks;
	}



}
