package com.markit.markithub.test.model;

import java.io.File;
import java.io.Serializable;

import com.markit.markithub.test.service.BasicFunction;
import com.thoughtworks.selenium.Selenium;

public abstract class StepBase implements Serializable,Step{

	private static final long serialVersionUID = 1L;
	private String name;
	private Selenium selenium;

	private StepResult stepResult;
	private StorySettings storySettings;

	protected BasicFunction basic = new BasicFunction();

	/**
	 * Constructor of StepBase.
	 * @param name
	 */
	public StepBase(String name){
		this.name = name;
	}

	/**
	 * The name/description of the step.
	 * @return name - The name of the step
	 */
	public String getName(){
		return this.name;
	}

	public void setStorySettings(StorySettings storySettings){
		this.storySettings = storySettings;
	}

	public StorySettings getStorySettings(){
		return storySettings;
	}

	/**
	 * Set the (@link Selenium) instance for the step.
	 * @param selenium - The Selenium instance
	 */
	public void setSeleniumInstance(Selenium selenium){
		this.selenium = selenium;
	}

	/**
	 * Get the selenium instance of the step.
	 * @return selenium - The Selenium instance.
	 */
	public Selenium getSeleniumInstance(){
		return selenium;
	}

	/**
	 * A thing required as a prior condition for something else to happen.
	 * Not to be Overridden, Not that you can.
	 */
	public final void validate(){
		if(selenium == null){
			throw new RuntimeException("No Selenium Instance available");
		}
	}

	/**
	 * The code NOT to be timed.
	 */
	public void primer() throws Exception{

	}

	/**
	 * The code to be timed.
	 */
	public void execute() throws Exception{

	}

	/**
	 * Code required or need to return the browser to a state. I.e switch window's e.g. MSOpen .
	 */
	public void teardown() throws RuntimeException {

	}

	/**
	 * The Default takeScreenshot method.
	 * @param screenshotName - The File for the screenshot.
	 */
	public void takeScreenshot(String screenshotName, File outputFile){
		basic.takeNativeScreenshot(screenshotName,selenium,outputFile);

	}

	public void setStepResult(StepResult stepResult){
		this.stepResult = stepResult;
	}

	public StepResult getStepResult(){
		return this.stepResult;
	}
}
