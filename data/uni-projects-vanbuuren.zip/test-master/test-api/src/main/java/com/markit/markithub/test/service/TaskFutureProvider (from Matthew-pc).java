package com.markit.markithub.test.service;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Future;

import com.markit.markithub.test.model.StepResult;
import com.markit.markithub.test.model.TaskResult;

/**
 * Responsible for maintaining a list of {@link TaskResultResult} futures
 *
 * Will need to be responsible for possible synchronised access
 */
public class TaskFutureProvider implements FutureManager<TaskResult<StepResult>> {
	private final Set<Future<TaskResult<StepResult>>> futures;

	public TaskFutureProvider() {
		futures = new HashSet<Future<TaskResult<StepResult>>>();
	}

	public Set<Future<TaskResult<StepResult>>> getFutures() {
		return futures;
	}

	public void addFuture(Future<TaskResult<StepResult>> future) {
		if (!futures.add(future)) {
			throw new RuntimeException("Future with same hash/eq");
		}
	}

	public void removeFutures(Set<Future<TaskResult<StepResult>>> future) {
		futures.remove(future);
	}
}
