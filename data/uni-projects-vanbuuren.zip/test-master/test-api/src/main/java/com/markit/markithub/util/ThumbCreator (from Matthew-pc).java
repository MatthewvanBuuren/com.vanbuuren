package com.markit.markithub.util;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

/**
 * Thumb nail creation
 * Only tested on png's
 */
public class ThumbCreator {

	/**
	 * Creates a thumbnail for a given file.
	 * 
	 * @param orig File original
 	 * @param string - name postfix
	 * @throws IOException 
	 */
	public void thumb(File orig, String extension) throws IOException {
		BufferedImage image = loadImage(orig);
		File output = getThumbFile(orig, extension);
		int[] dim = getNewWidthAndHeight(image.getWidth(), image.getHeight());
		BufferedImage thumb = resize(image, dim[0], dim[1]);
		saveImage(thumb, output);
	}
	
	private File getThumbFile(File orig, String extension) {
		int split = orig.getName().lastIndexOf(".");
		String name = orig.getName().substring(0, split) + extension + ".png";
		return new File(orig.getParent(), name);
	}
	
	private BufferedImage resize(BufferedImage org, int newWidth, int newHeight) {
		int w = org.getWidth();
		int h = org.getHeight();
		BufferedImage dimg = new BufferedImage(newWidth, newHeight, 1);
		Graphics2D g = dimg.createGraphics();
		g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g.drawImage(org, 0, 0, newWidth, newHeight, 0, 0, w, h, null);
		g.dispose();
		return dimg;
	}
	
	private int[] getNewWidthAndHeight(int width, int height) {
		while (height > 150) {
			width = (int) (width * 0.9);
			height = (int) (height * 0.9);
		}
		return new int[] {width, height};
	}

	public static BufferedImage loadImage(File file) throws IOException {
		return ImageIO.read(file);
	}
	
	private static void saveImage(BufferedImage img, File thumb) throws IOException {
		ImageIO.write(img, "png", thumb);
	}

}

