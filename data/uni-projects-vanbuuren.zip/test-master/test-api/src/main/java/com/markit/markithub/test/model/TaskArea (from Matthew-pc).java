package com.markit.markithub.test.model;

import java.util.List;


/**
 * Used to make a Library of Tasks. An example would be the Login area
 * which would be a way of wrapping up all the Login Tasks.
 */
public interface TaskArea {

	/**
	 * Get the name for this division of {@link Task tasks}
	 */
	public String getName();

	/**
	 * Get the {@link Task tasks} which are contained within this area.
	 */
	public List<Task> getTasks();

}
