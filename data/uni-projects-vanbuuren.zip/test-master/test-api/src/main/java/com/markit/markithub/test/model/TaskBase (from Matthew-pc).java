package com.markit.markithub.test.model;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.ArrayList;
import java.util.List;

import javax.swing.event.SwingPropertyChangeSupport;

import com.thoughtworks.selenium.Selenium;

public abstract class TaskBase implements Task {

	private static final long serialVersionUID = 1L;

	private List<StepBase> allSteps = new ArrayList<StepBase>();
	private String url;
	private State state;
    private final PropertyChangeSupport propertyChangeSupport;

    public TaskBase() {
        propertyChangeSupport = new SwingPropertyChangeSupport(this);
        state = State.PENDING;
	}

	public List<StepBase> getSteps() {
		return allSteps;
	}

	public void addStep(StepBase step){
		allSteps.add(step);
	}

	public void setSelenium(Selenium selenium) {
		for (Step step : getSteps()) {
			step.setSeleniumInstance(selenium);
		}
	}

	public State getState(){
		return this.state;
	}

	public void setState(State state){
        State old = this.state;
        this.state = state;
        firePropertyChange("state", old, state);
	}

	public void setUrl(String url){
		this.url = url;
	}

	public String getUrl(){
		return url;
	}

	public TaskResult<StepResult> getTaskResult(){
		TaskResult<StepResult> taskResult  = new SimpleTaskResult<StepResult>(getName());
		for(Step step : allSteps){
			taskResult.addStepResult(step.getStepResult());
		}
		return taskResult;
	}

	@Override
	protected TaskBase clone() throws CloneNotSupportedException {
		return (TaskBase) super.clone();
	}

	//Property change support
    public final PropertyChangeSupport getPropertyChangeSupport() {
        return propertyChangeSupport;
    }

    public final void addPropertyChangeListener(PropertyChangeListener listener) {
        getPropertyChangeSupport().addPropertyChangeListener(listener);
    }

    public final void removePropertyChangeListener(PropertyChangeListener listener) {
        getPropertyChangeSupport().removePropertyChangeListener(listener);
    }

    public final void firePropertyChange(String propertyName, Object oldValue,
            Object newValue) {
        getPropertyChangeSupport().firePropertyChange(propertyName,
            oldValue, newValue);
    }

	@Override
	public String toString() {
		return getName();
	}

}
