package com.markit.markithub.test.model;

import java.util.ArrayList;
import java.util.List;

public class SimpleTaskResult<S> implements TaskResult<StepResult> {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private State state;
	private List<StepResult> allResults;


	public SimpleTaskResult(String name){
		this.name = name;
		allResults = new ArrayList<StepResult>();
	}

	public String getName() {
		return name;
	}

	public Result getResult() {
		int lastRecordPosition = allResults.size() - 1;
		for(int currentPosition = 0 ; currentPosition <= lastRecordPosition ; currentPosition++){
			StepResult stepResult = allResults.get(currentPosition);
			if(stepResult.getResult().equals(Result.failed)){
				return Result.failed;
			}
			if(stepResult.getResult().equals(Result.suspect)){
				return Result.suspect;
			}
			if(currentPosition == lastRecordPosition){
				if(stepResult.getResult().equals(Result.succeeded)){
					return Result.succeeded;
				}
			}
		}
		return Result.stateless;
	}

	public List<StepResult> getStepResults() {
		return allResults;
	}

	public int getNumberOfStepResults() {
		return allResults.size();
	}

	public void addStepResult(StepResult stepResult) {
		allResults.add(stepResult);
	}

	public void setState(State state) {
		this.state = state;
	}

	public State getState(){
		return this.state;
	}

	public boolean isFinished(){
		return state.equals(State.FINISHED);
	}

}
