package com.markit.markithub.test.service;

import java.io.File;
import java.util.concurrent.TimeoutException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.markit.markithub.test.exception.UnexpectedStateException;
import com.markit.markithub.util.ThumbCreator;
import com.thoughtworks.selenium.Selenium;
import com.thoughtworks.selenium.SeleniumException;

public class BasicFunction {

	private static final int MAX_WAIT_TIME = 60;
	public ThumbCreator thumbCreator = new ThumbCreator();
	public static final String SCREENSHOT_ORIG_EXTENSION = ".png";
	public static final String SCREENSHOT_THUMB_PREFIX = "_thumb";

	private static final Logger logger = LoggerFactory
			.getLogger(BasicFunction.class);

	/**
	 * Assert that a Alert is present.
	 *
	 * @param selenium - Selenium - The selenium instance.
	 * @throws Exception
	 */
	public void assertAlert(Selenium selenium) throws Exception{
		if(!selenium.isAlertPresent()){
			throw new Exception("No Alert Present");
		}else{
			throw new SeleniumException(selenium.getAlert());
		}
	}

	/**
	 * Call mouseOver,mouseDown,mouseUp,mouseOut selenium commands on a locator.
	 *
	 * @param locator - String - The locator of the element
	 * @param selenium - Selenium - The (@link Selenium) instance to use.
	 * @throws Exception
	 */
	public void pressButtonSlow(String locator, Selenium selenium) throws Exception {
		selenium.focus(locator);
		selenium.mouseOver(locator);
		selenium.mouseDown(locator);
		selenium.mouseUp(locator);
		selenium.mouseOut(locator);
	}

	/**
	 * Call mouseOver,mouseDown,mouseUp,mouseOut selenium commands on a locator.
	 *
	 * @param locator - String - The locator of the element
	 * @param selenium - Selenium - The (@link Selenium) instance to use.
	 * @throws Exception
	 */
	public void pressButtonSlowest(String locator, Selenium selenium) throws Exception {
		selenium.focus(locator);
		selenium.mouseOver(locator);
		if(selenium.isElementPresent(locator)){selenium.mouseDown(locator);}
		if(selenium.isElementPresent(locator)){selenium.mouseUp(locator);}
		if(selenium.isElementPresent(locator)){selenium.mouseOut(locator);}
	}

	/**
	 * Call click selenium command on a locator.
	 *
	 * @param locator - String - The locator of the element
	 * @param selenium - Selenium - The (@link Selenium) instance to use.
	 * @throws Exception
	 */
	public void pressButton(String locator, Selenium selenium) throws Exception {
		selenium.focus(locator);
		selenium.click(locator);
	}

	/**
	 * Press backspace the specified amount of times on the element locator.
	 * @param locator - String - The locator of the element
	 * @param amount - int - The amount of characters to be removed.
	 * @param selenium - Selenium - The (@link Selenium) instance to use.
	 * @throws Exception
	 */
	public void pressBackSpace(String locator, int amount, Selenium selenium) throws Exception {
		pressButton(locator, selenium);
		for (int x = 0; x < amount; x ++) {
			selenium.keyPress(locator,"\\08");
		}
		selenium.keyUp(locator,"\\08");
		selenium.fireEvent(locator,"keyUp");
	}

	/**
	 * Check that the element locator is present.
	 *
	 * @param locator - String - The locator of the element
	 * @param selenium - Selenium - The (@link Selenium) instance to use.
	 * @throws Exception
	 */
	public void assertElementPresent(String locator,Selenium selenium) throws Exception{
		if(!selenium.isElementPresent(locator)){
			throw new UnexpectedStateException("Missing Element: " + locator);
		}else{
			selenium.highlight(locator);
		}
	}

	/**
	 * Check that the element locator is not present.
	 *
	 * @param locator - String - The locator of the element
	 * @param selenium - Selenium - The (@link Selenium) instance to use.
	 * @throws Exception
	 */
	public void assertElementNotPresent(String locator,Selenium selenium) throws Exception{
		if(selenium.isElementPresent(locator)){
			throw new UnexpectedStateException("Found Element: " + locator);
		}
	}

	/**
	 * Check that the element is checked.
	 *
	 * @param locator - String - The locator of the element
	 * @param selenium - Selenium - The @link Selenium instance to use.
	 * @throws Exception
	 */
	public void assertElementSelected(String locator,Selenium selenium) throws Exception{
		if(!selenium.isChecked(locator)){
			throw new UnexpectedStateException("Not Checked: " + locator);
		}
	}

	/**
	 * Check the element has the text given.
	 *
	 * @param locator - String - The locator of the element
	 * @param text - String - The text to compare it to.
	 * @param selenium - Selenium - The (@link Selenium) instance to use.
	 * @throws Exception
	 */
	public void assertText(String locator, String text, Selenium selenium)throws Exception{
		if(!selenium.getValue(locator).equals(text)){
			throw new UnexpectedStateException("Missing Text: " + locator);
		}
	}

	/**
	 * Call captureScreenshot selenium command, Output the file with screenshot.
	 *
	 * @param filename - String - The name for the file to be output.
	 * @param selenium - Selenium - The (@link Selenium) instance to use.
	 * @param outputFile - File - The parent file to place the new file under.
	 */
	public void takeScreenshot(String filename, Selenium selenium,File outputFile) {
		File orig = new File(outputFile, filename + SCREENSHOT_ORIG_EXTENSION);
		selenium.captureScreenshot(outputFile.getAbsolutePath()
				+ File.separator + filename + ".png");
		try {
			thumbCreator.thumb(orig, SCREENSHOT_THUMB_PREFIX);
		} catch (Exception e) {
			logger.error("Error creating thumb, ", e);
		}
	}

	/**
	 * Call captureEntirePageScreenshot selenium command, Output the file with screenshot.
	 *
	 * @param filename - String - The name for the file to be output.
	 * @param selenium - Selenium - The (@link Selenium) instance to use.
	 * @param outputFile - File - The parent file to place the new file under.
	 */
	public void takeNativeScreenshot(String filename, Selenium selenium,File outputFile) {
		File orig = new File(outputFile, filename + SCREENSHOT_ORIG_EXTENSION);
		selenium.captureEntirePageScreenshot(outputFile.getAbsolutePath()
				+ File.separator + filename + ".png", "background=#fff");
		try {
			thumbCreator.thumb(orig, SCREENSHOT_THUMB_PREFIX);
		} catch (Exception e) {
			logger.error("Error creating thumb, ", e);
		}
	}

	/**
	 * Simulating pressing the enter key while on a locator.
	 *
	 * @param locator - String - The locator of the element
	 * @param selenium - Selenium - The (@link Selenium) instance to use.
	 */
	public void enterKey(String locator, Selenium selenium) {
		selenium.focus(locator);
		selenium.keyDown(locator, "13");
		selenium.keyUp(locator, "13");
	}

	/**
	 * Type a string into a element, Also corrects bugs found in typing special characters i.e. &,*.
	 *
	 * @param locator - String - The locator of the element
	 * @param value - String - The String to be typed.
	 * @param selenium - Selenium - The (@link Selenium) instance to use.
	 * @throws Exception
	 */
	public void typeString(String locator, String value, Selenium selenium)
			throws Exception {
		selenium.click(locator);
		selenium.focus(locator);
		selenium.type(locator, value);
		if (value.contains("&") || value.contains("*") || value.contains(".")
				|| value.contains("1")) {
			selenium.keyUp(locator, "\\08");
		} else {
			selenium.keyUp(locator, getLastChar(value));
		}
		selenium.fireEvent(locator, "keyUp");
	}

	/**
	 * Select the dropdown list element locator with the name given.
	 *
	 * @param locator - String - The locator of the element
	 * @param name - String - The name of the dropdown element.
	 * @param selenium - Selenium - The (@link Selenium) instance to use.
	 * @throws Exception
	 */
	public void selectDropdown(String locator, String name, Selenium selenium)throws Exception {
		selenium.select(locator, name);
	}

	/**
	 * Wait for the locator of the element to be present.
	 *
	 * @param locator - String - The locator of the element
	 * @param selenium - Selenium - The (@link Selenium) instance to use.
	 * @throws Exception - TimeoutException is thrown if the element is not found in time.
	 */
	public void waitForElementPresent(String locator, Selenium selenium)
			throws Exception {
		waitForElementPresent(locator, MAX_WAIT_TIME, selenium);
	}

	/**
	 * Wait for either element locator to be present.
	 *
	 * @param locator - String - The first locator
	 * @param altLocator - String - The second locator
	 * @param selenium - Selenium - The (@link Selenium) instance to use.
	 * @throws Exception - TimeoutException is thrown if the element is not found in time.
	 */
	public void waitForEitherElementPresent(String locator, String altLocator, Selenium selenium)throws Exception {
		waitForEitherElementPresent(locator, altLocator, MAX_WAIT_TIME, selenium);
	}

	/**
	 * Wait for both element locators to be present.
	 *
	 * @param locator - String - The first locator
	 * @param locator2 - String - The second locator
	 * @param selenium - Selenium - The selenium instance
	 * @throws Exception - TimeoutException is thrown if the element is not found in time.
	 */
	public void waitForBothElementsPresent(String locator, String altLocator,Selenium selenium) throws Exception {
		waitForBothElementsPresent(locator, altLocator, MAX_WAIT_TIME, selenium);
	}

	/**
	 * Wait for the locator of the element to NOT be present.
	 *
	 * @param locator - String - The locator of the element
	 * @param selenium - Selenium - The (@link Selenium) instance to use
	 * @throws Exception - TimeoutException is thrown if the element is not found in time.
	 */
	public void waitForElementNotPresent(String locator, Selenium selenium)throws Exception {
		waitForElementNotPresent(locator, MAX_WAIT_TIME, selenium);
	}

	/**
	 * Wait for the element locator to be present and visible.
	 *
	 * @param locator - The element locator
	 * @param selenium - Selenium - The selenium instance to use.
	 * @throws Exception - TimeoutException is thrown if the element is not found in time.
	 */
	public void waitForElementPresentandVisible(String locator,
			Selenium selenium) throws Exception {
		waitForElementPresentandVisible(locator, MAX_WAIT_TIME, selenium);
	}

	/**
	 * Wait for the an element locator to be hidden then to reappear.
	 *
	 *@param locator - The element locator
	 * @param selenium - Selenium - The selenium instance to use.
	 * @throws Exception - TimeoutException is thrown if the element is not found in time.
	 */
	public void waitForRenew(String locator, Selenium selenium)throws Exception {
		waitForRenew(locator, MAX_WAIT_TIME, selenium);
	}

	/**
	 * Wait for the element locator to be present and not visible.
	 *
	 * @param locator - The element locator
	 * @param selenium - Selenium - The selenium instance to use.
	 * @throws Exception - TimeoutException is thrown if the element is not found in time.
	 */
	public void waitForElementNotVisible(String locator, Selenium selenium)throws Exception {
		waitForElementNotVisible(locator, MAX_WAIT_TIME, selenium);
	}

	//Private Methods
	private void waitForRenew(String locator, int timeoutS, Selenium selenium)throws Exception{
		for(int x = 0 ;; x++){
			if(x > timeoutS){
				throw new TimeoutException();
			}
			try{
				if(!selenium.isVisible(locator)){
					break;
				}
				Thread.sleep(1000);
			}catch(Exception e){

			}
		}
		for(int x = 0 ;; x++){
			if(x > timeoutS){
				throw new TimeoutException();
			}
			try{
				if(selenium.isVisible(locator)){
					break;
				}
				Thread.sleep(1000);
			}catch(Exception e){

			}
		}
	}

	private void waitForElementPresent(String locator, int timeoutS,
			Selenium selenium) throws Exception {
		for (int x = 0;; x++) {
			if (x > timeoutS) {
				throw new TimeoutException();
			}
			try {
				if (selenium.isElementPresent(locator)) {
					break;
				}
				Thread.sleep(1000);
			} catch (Exception e) {

			}
		}
	}

	private void waitForEitherElementPresent(String locator,String altLocator,int timeoutS,Selenium selenium) throws Exception{
		for (int x = 0;; x++) {
			if (x > timeoutS) {
				throw new TimeoutException();
			}
			try {
				if (selenium.isElementPresent(locator)|| selenium.isElementPresent(altLocator)) {
					break;
				}
				Thread.sleep(1000);
			} catch (Exception e) {

			}
		}
	}

	private void waitForBothElementsPresent(String locator, String altLocator,int timeoutS, Selenium selenium) throws Exception {
		for (int x = 0;; x++) {
			if (x > timeoutS) {
				throw new TimeoutException();
			}
			try {
				if (selenium.isElementPresent(locator)
						&& selenium.isElementPresent(altLocator)) {
					break;
				}
				Thread.sleep(1000);
			} catch (Exception e) {

			}
		}
	}

	private void waitForElementNotPresent(String locator, int timeoutS,
			Selenium selenium) throws Exception {
		for (int x = 0;; x++) {
			if (x > timeoutS) {
				throw new TimeoutException();
			}
			try {
				if (!selenium.isElementPresent(locator)) {
					break;
				}
				Thread.sleep(1000);
			} catch (Exception e) {

			}
		}
	}

	private void waitForElementNotVisible(String locator, int timeoutS,
			Selenium selenium) throws Exception {
		for (int x = 0;; x++) {
			if (x >= timeoutS) {
				throw new TimeoutException();
			}
			try {
				if (!selenium.isVisible(locator)) {
					break;
				}
				Thread.sleep(1000);
			} catch (Exception e) {

			}
		}
	}

	private void waitForElementPresentandVisible(String locator, int timeoutS,
			Selenium selenium) throws Exception {
		for (int x = 0;; x++) {
			if (x >= timeoutS) {
				throw new TimeoutException();
			}
			try {
				if (selenium.isElementPresent(locator)
						&& selenium.isVisible(locator)) {
					break;
				}
				Thread.sleep(1000);
			} catch (Exception e) {

			}
		}
	}

	private String getLastChar(String arg) {
		return new String(new char[] { arg.charAt(arg.length() - 1) });
	}
}
