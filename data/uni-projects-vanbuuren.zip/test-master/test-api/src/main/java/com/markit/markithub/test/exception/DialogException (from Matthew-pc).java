package com.markit.markithub.test.exception;

public class DialogException extends Exception{

	private static final long serialVersionUID = 1L;

	/**
	 * An exception thrown when a dialog has appeared/expected.
	 *
	 * @param message - String - The message about the exception
	 * @param cause - Throwable - The throwable which contains as a cause, The filename that caused the dialog.
	 */
	public DialogException(String message, Throwable cause){
		super(message,cause);
	}
}
