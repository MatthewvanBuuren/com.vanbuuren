package com.markit.markithub.test.model;

public class SeleniumStartOptions {

	public static final String captureNetworkTraffic_True = "captureNetworkTraffic=true";
	//Default is already false, Shouldn't need to be used.
	public static final String captureNetworkTraffic_False = "captureNetworkTraffic=false";



}
