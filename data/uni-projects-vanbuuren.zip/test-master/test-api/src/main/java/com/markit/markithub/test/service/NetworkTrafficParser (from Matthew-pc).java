package com.markit.markithub.test.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Matthew.VanBuuren
 * Parse captureNetworkTraffic() String into HttpReponses.
 */
public class NetworkTrafficParser {

	private List<HttpResponse> responses;

	private static final Logger logger = LoggerFactory.getLogger(NetworkTrafficParser.class);

	public NetworkTrafficParser(String networkTraffic){
		this.responses = chunkResponses(networkTraffic);
	}

	protected List<HttpResponse> chunkResponses(String networkTraffic) {
		List<HttpResponse> responses = new ArrayList<HttpResponse>();
		int endOfFirstPacketIndex = 0;
		int strOfFirstPacketIndex = 0;
		String bucket = networkTraffic;
		String singleResponse = "";

		while (bucket.length() > 28){
			strOfFirstPacketIndex = bucket.indexOf("<entry");
			endOfFirstPacketIndex = bucket.indexOf("</entry>");
			if(!(endOfFirstPacketIndex==-1)){endOfFirstPacketIndex = endOfFirstPacketIndex + 8;} // Index from the end of the </Entry>
			if (!(strOfFirstPacketIndex == -1) && !(endOfFirstPacketIndex == -1) && !(strOfFirstPacketIndex > endOfFirstPacketIndex)){
			singleResponse = bucket.substring(strOfFirstPacketIndex,endOfFirstPacketIndex);
			responses.add(getSingleResponse(singleResponse));
			bucket = bucket.substring(endOfFirstPacketIndex,bucket.length());
			}else{
				if((strOfFirstPacketIndex == -1)){break;}
				if((endOfFirstPacketIndex == -1)){break;}
				if(strOfFirstPacketIndex > endOfFirstPacketIndex){bucket = bucket.substring(strOfFirstPacketIndex,bucket.length()-1);}
			}
		}
		return responses;
	}

	private HttpResponse getSingleResponse(String networkTraffic){

		String firstPacket = networkTraffic;
		String code = "";
		String method = "";
		String host = "";
		String contenttype = "";
		String fileName = "";

		String specialcontenttype = "";

		int codePos = firstPacket.indexOf("statusCode=")+ 12;
		if(!(codePos == -1)){
				code = firstPacket.substring(codePos, (codePos + 3));
		}

		int methodPos = firstPacket.indexOf("method=")+ 9;
		if(!(methodPos == -1)){
		String method3 = firstPacket.substring(methodPos, (methodPos + 3));
		String method4 = firstPacket.substring(methodPos, (methodPos + 4));

			if(method3.equals("GET")){
				method = method3;
			}
			if(method4.equals("HEAD")){
				method = method4;
			}
			if(method4.equals("POST")){
				method = method4;
			}
		}

		List<String> validExten = new ArrayList<String>();
		validExten.add(".xls");
		validExten.add(".html");
		validExten.add(".txt");
		validExten.add(".gif");
		validExten.add(".pdf");

		for(String Extension : validExten){
			if(firstPacket.contains(Extension)){
				int filePosEnd = firstPacket.indexOf(Extension);
				int fileFirstPosStr = firstPacket.indexOf("url=") + 4;
				int filePosStr = filePosEnd - 1;
				for (int x = 0; x < (filePosEnd - fileFirstPosStr)  ; x++){
					String tmp = Character.toString(firstPacket.charAt(filePosEnd - x));
					if(tmp.equals("/")){
						filePosStr = filePosEnd - x + 1;
						break;
					}
				}
				fileName = firstPacket.substring(filePosStr,filePosEnd);
			}
		}


		int hostPosStr = firstPacket.indexOf("<header name=\"Host\">")+ 20;
		int hostPosEnd = firstPacket.indexOf("</header>", hostPosStr);
		if(!(hostPosStr == -1) || !(hostPosEnd == -1)){
		host = firstPacket.substring(hostPosStr,hostPosEnd);
		}

		int contenttypePosStr = firstPacket.indexOf("<header name=\"Content-Type\">")+ 28;
		int contenttypePosEnd = firstPacket.indexOf("</header>", contenttypePosStr);
		if(!(contenttypePosStr == -1) || !(contenttypePosEnd == -1)){
		contenttype = firstPacket.substring(contenttypePosStr,contenttypePosEnd);
		}

		int specialcontenttypePosStr = firstPacket.indexOf("fileType=")+ 9;
		int specialcontenttypePosEnd = specialcontenttypePosStr + 3;
		if(!(specialcontenttypePosStr == 8) || !(specialcontenttypePosEnd == 11)){
			specialcontenttype = firstPacket.substring(specialcontenttypePosStr,specialcontenttypePosEnd);
		}

		// Used in debug to record responses to terminal
		logger.debug("Http Response: " + code + " " + method + " " + host + " " + contenttype + " " + fileName + " " + specialcontenttype);
		HttpResponse temp = new HttpResponse(code,method,host,contenttype,fileName,specialcontenttype);
		return temp;
	}

	public HttpResponse getResponse(int number){
		return responses.get(number);
	}

	public int getNumberOfResponses (){
		return responses.size();
	}

	public List<HttpResponse> getResponses() {
		return responses;
	}
}
