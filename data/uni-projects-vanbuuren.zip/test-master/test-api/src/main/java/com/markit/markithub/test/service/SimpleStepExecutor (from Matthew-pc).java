package com.markit.markithub.test.service;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.markit.markithub.test.exception.DialogException;
import com.markit.markithub.test.model.Result;
import com.markit.markithub.test.model.SimpleStepResult;
import com.markit.markithub.test.model.StepBase;
import com.markit.markithub.test.model.StepExecutor;
import com.markit.markithub.test.model.StepResult;
import com.markit.markithub.test.model.StorySettings;

public class SimpleStepExecutor implements StepExecutor{

	private DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss-");
	private Date date;
	private final StorySettings storySettings;

	private static Logger logger = LoggerFactory.getLogger(SimpleStepExecutor.class);
	public SimpleStepExecutor(StorySettings storySettings){
		this.storySettings = storySettings;
	}

	public StepResult run(StepBase step,File outputFile){
		date = new Date();
		StepResult result = new SimpleStepResult(step.getName());
		String screenshotName = dateFormat.format(date) + standardizeName(step.getName());
		try{
			step.setStorySettings(storySettings);
			step.validate();
			step.primer();
			long timeThen = System.currentTimeMillis();
			step.execute();
			long timeNow = System.currentTimeMillis() - timeThen;
			result.setTimeTaken(String.valueOf(timeNow)+ " Ms");
			step.takeScreenshot(screenshotName,outputFile);
			setScreenshotName(screenshotName,result);
			result.setResult(Result.succeeded);
		}
		catch(DialogException de){
			step.takeScreenshot(screenshotName, outputFile);
			setScreenshotName(screenshotName,result);
			PopupManagement popupManagement = new PopupManagement();
			popupManagement.closePopup(de.getCause().getMessage());
			result.setResult(Result.succeeded);
		}
		catch(Exception  rt){
			try {
				step.takeScreenshot(screenshotName,outputFile);
				setScreenshotName(screenshotName,result);
				result.setTimeTaken("FAILED: " + rt);
				result.setResult(Result.failed);
				logger.error("Error running step",  rt);
			}
			catch(Exception e){
				result.setResult(Result.suspect);
				result.setTimeTaken("PROGRAMMER FAIL: " + e);
				logger.error("Fail safe methods i.e takeScreenshot have failed.",e);
			}

		}
		finally {
			step.teardown();
		}
		return result;
	}

	private String standardizeName(String name) {
		String newString = name;
		String editString = name;
		List<String> allAnomilies = new ArrayList<String>();
		allAnomilies.add("'");
		for(String anom : allAnomilies){
			if(name.contains(anom)){
				editString = name.replaceAll(anom,"");
			}
			newString = editString;
		}
		return newString;
	}

	public void setScreenshotName(String screenshotName,StepResult result){
		result.setScreenshotName("<a href='" + screenshotName + ".png'><img src='" + screenshotName + "_thumb.png'/></a>");
	}
}
