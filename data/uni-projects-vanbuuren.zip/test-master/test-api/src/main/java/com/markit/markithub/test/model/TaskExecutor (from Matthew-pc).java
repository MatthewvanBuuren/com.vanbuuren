package com.markit.markithub.test.model;

public interface TaskExecutor {

	public TaskResult<StepResult> getTaskResult();
}
