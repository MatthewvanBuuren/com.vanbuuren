package com.markit.markithub.test.Data;

/**
 * For convenience of not having to hard-code selenium locators everywhere
 * XPath etc.
 */
public class Locators {

	// Login Page
	public static final String LOGIN_USERNAME = "//div/input[@id='username']";
	public static final String LOGIN_PASSWORD = "//div/input[@type='password']";
	public static final String LOGIN_SUBMIT = "//div/input[@type='submit']";

	// Tags
	public static final String TAG_TERM_HIGH_YIELD = "//div[contains(@class,'orderedCriteriaWidget') and text()=\"'High Yield'\"]";
	public static final String TAG_HIGH_YIELD = "//div[contains(@class,'orderedCriteriaWidget') and text()='High Yield']";
	public static final String TAG_RESEARCHSTRATEGY = "//div[contains(@class,'orderedCriteriaWidget') and text()='Research / Strategy']";

	// Hub Banner Buttons
	public static final String BANNER_SEARCH_LOADING_NEWS_HIDDEN = "//div[contains(@style,'display: none') and contains(@class,'loadingNews')]";
	public static final String BANNER_SEARCH_LOADING_RESEARCH_HIDDEN = "//div[contains(@style,'display: none') and contains(@class,'loadingResearch')]";
	public static final String BANNER_SEARCH_TABLET_RESULT_VISIBLE = "//div[contains(@style,'display: none') and contains(@class,'loadingResearch')]";
	public static final String BANNER_SEARCH_BUTTON = "//div[contains(@class,'searchButton')]";
	public static final String BANNER_SEARCH_INPUT = "//input[contains(@class,'searchTextBox')]";
	//TODO: Specify what a successful QuickSearch Load is...
	public static final String BANNER_QUICKSEARCH_DROPDOWN_LOAD = "//div[contains(@class,'shTitle') and contains(text(),'Compan')]";
//	public static final String BANNER_QUICKSEARCH_DROPDOWN_LOAD="//div[contains(@class,'searchHelper')]";

	public static final String BANNER_QUICKSEARCH_DROPDOWN_LOADING_HIDDEN = "//div[contains(@class,'searchControl')]/div[contains(@class,'loadingPanel') and contains(@style,'display: none')]";
	public static final String BANNER_HEADLINES_BUTTON = "css=div.headlinesButton";
	public static final String BANNER_DIRECTORY_BUTTON = "css=div.directoryButton";
	public static final String BANNER_INDICATIONS_BUTTON = "css=div.indicationsButton";
	public static final String BANNER_NEWS_BUTTON = "css=div.newsButton";
	public static final String BANNER_SUPPORT = "//div[@class='supportFlyout']";
	public static final String BANNER_LOGIN = "//a[@class='logout']";
	public static       String BANNER_PROVIDER(String prov){ return "//div[@class = 'html-face' and contains(text(),'" + prov + "')]";}
	public static final String BANNER_ADDPROVIDER = "//div[@class = 'html-face' and contains(text(),'+ add provider')]";

	//Provider Tabs
	public static final String PROVIDER_BAM_TAB = "//div[contains(@class,'providerBarButtonPanel_" + PerProviderInfo.BAM.abrv + "')]/div";
	public static final String PROVIDER_BC_TAB = "//div[contains(@class,'providerBarButtonPanel_" + PerProviderInfo.BC.abrv + "')]/div";
	public static final String PROVIDER_BNP_TAB = "//div[contains(@class,'providerBarButtonPanel_" + PerProviderInfo.BNP.abrv + "')]/div";
	public static final String PROVIDER_C_TAB = "//div[contains(@class,'providerBarButtonPanel_" + PerProviderInfo.C.abrv + "')]/div";
	public static final String PROVIDER_CS_TAB = "//div[contains(@class,'providerBarButtonPanel_" + PerProviderInfo.CS.abrv + "')]/div";
	public static final String PROVIDER_DB_TAB = "//div[contains(@class,'providerBarButtonPanel_" + PerProviderInfo.DB.abrv + "')]/div";
	public static final String PROVIDER_GS_TAB = "//div[contains(@class,'providerBarButtonPanel_" + PerProviderInfo.GS.abrv + "')]/div";
	public static final String PROVIDER_JPM_TAB = "//div[contains(@class,'providerBarButtonPanel_" + PerProviderInfo.JPM.abrv + "')]/div";
	public static final String PROVIDER_MS_TAB = "//div[contains(@class,'providerBarButtonPanel_" + PerProviderInfo.MS.abrv + "')]/div";
	public static final String PROVIDER_RBC_TAB = "//div[contains(@class,'providerBarButtonPanel_" + PerProviderInfo.RBC.abrv + "')]/div";
	public static final String PROVIDER_UBS_TAB = "//div[contains(@class,'providerBarButtonPanel_" + PerProviderInfo.UBS.abrv + "')]/div";
	public static final String PROVIDER_DJ_TAB = "//div[contains(@class,'providerBarButtonPanel_" + PerProviderInfo.DJ.abrv + "')]/div";
	public static final String PROVIDER_MKT_TAB = "//div[contains(@class,'providerBarButtonPanel_" + PerProviderInfo.MKT.abrv + "')]/div";

	public static final String PROVIDER_INACTIVE_BAM = "//div[contains(@class,'providerBarButtonInactive')]/div[text()='" + PerProviderInfo.BAM.abrv + "']";
	public static final String PROVIDER_INACTIVE_BC = "//div[contains(@class,'providerBarButtonInactive')]/div[text()='" + PerProviderInfo.BC.abrv + "']";
	public static final String PROVIDER_INACTIVE_BNP = "//div[contains(@class,'providerBarButtonInactive')]/div[text()='" + PerProviderInfo.BNP.abrv + "']";
	public static final String PROVIDER_INACTIVE_C = "//div[contains(@class,'providerBarButtonInactive')]/div[text()='" + PerProviderInfo.C.abrv + "']";
	public static final String PROVIDER_INACTIVE_CS = "//div[contains(@class,'providerBarButtonInactive')]/div[text()='" + PerProviderInfo.CS.abrv + "']";
	public static final String PROVIDER_INACTIVE_DB = "//div[contains(@class,'providerBarButtonInactive')]/div[text()='" + PerProviderInfo.DB.abrv + "']";
	public static final String PROVIDER_INACTIVE_GS = "//div[contains(@class,'providerBarButtonInactive')]/div[text()='" + PerProviderInfo.GS.abrv + "']";
	public static final String PROVIDER_INACTIVE_JPM = "//div[contains(@class,'providerBarButtonInactive')]/div[text()='" + PerProviderInfo.JPM.abrv + "']";
	public static final String PROVIDER_INACTIVE_MS = "//div[contains(@class,'providerBarButtonInactive')]/div[text()='" + PerProviderInfo.MS.abrv + "']";
	public static final String PROVIDER_INACTIVE_RBC = "//div[contains(@class,'providerBarButtonInactive')]/div[text()='" + PerProviderInfo.RBC.abrv + "']";
	public static final String PROVIDER_INACTIVE_UBS = "//div[contains(@class,'providerBarButtonInactive')]/div[text()='" + PerProviderInfo.UBS.abrv + "']";
	public static final String PROVIDER_INACTIVE_DJ = "//div[contains(@class,'providerBarButtonInactive')]/div[text()='" + PerProviderInfo.DJ.abrv + "']";
	public static final String PROVIDER_INACTIVE_MKT = "//div[contains(@class,'providerBarButtonInactive')]/div[text()='" + PerProviderInfo.MKT.abrv + "']";

	public static final String PROVIDER_ACTIVE_BAM = "//div[contains(@class,'providerBarButtonActive')]/div[text()='" + PerProviderInfo.BAM.abrv + "']";
	public static final String PROVIDER_ACTIVE_BC = "//div[contains(@class,'providerBarButtonActive')]/div[text()='" + PerProviderInfo.BC.abrv + "']";
	public static final String PROVIDER_ACTIVE_BNP = "//div[contains(@class,'providerBarButtonActive')]/div[text()='" + PerProviderInfo.BNP.abrv + "']";
	public static final String PROVIDER_ACTIVE_C = "//div[contains(@class,'providerBarButtonActive')]/div[text()=" + PerProviderInfo.C.abrv + "C']";
	public static final String PROVIDER_ACTIVE_CS = "//div[contains(@class,'providerBarButtonActive')]/div[text()='" + PerProviderInfo.CS.abrv + "']";
	public static final String PROVIDER_ACTIVE_DB = "//div[contains(@class,'providerBarButtonActive')]/div[text()='" + PerProviderInfo.DB.abrv + "']";
	public static final String PROVIDER_ACTIVE_GS = "//div[contains(@class,'providerBarButtonActive')]/div[text()='" + PerProviderInfo.GS.abrv + "']";
	public static final String PROVIDER_ACTIVE_JPM = "//div[contains(@class,'providerBarButtonActive')]/div[text()='" + PerProviderInfo.JPM.abrv + "']";
	public static final String PROVIDER_ACTIVE_MS = "//div[contains(@class,'providerBarButtonActive')]/div[text()='" + PerProviderInfo.MS.abrv + "']";
	public static final String PROVIDER_ACTIVE_UBS = "//div[contains(@class,'providerBarButtonActive')]/div[text()='" + PerProviderInfo.UBS.abrv + "']";
	public static final String PROVIDER_ACTIVE_DJ = "//div[contains(@class,'providerBarButtonActive')]/div[text()='" + PerProviderInfo.DJ.abrv + "']";
	public static final String PROVIDER_ACTIVE_MKT = "//div[contains(@class,'providerBarButtonActive')]/div[text()='" + PerProviderInfo.MKT.abrv + "']";


	// Headlines
	public static final String HEADLINES_LIST_VIEW = "//div[contains(@class,'btnList_View')]";
	public static final String HEADLINES_TABLET_VIEW = "//div[contains(@class,'btnTablet_View')]";
	public static final String HEADLINES_RESEARCHANDNEWS= "//div[contains(@class,'btnResearchNews')]";
	public static final String HEADLINES_RESEARCHONLY = "//div[contains(@class,'btnResearchOnly')]";
	public static final String HEADLINES_DEPTH = "//div[contains(@class,'navHeaderListBox')]";
	public static final String HEADLINES_COLUMN1_PREV = "//div[position()=2]/div/div/div/div[contains(@class,'nextButton')]";
	public static       String HEADLINES_COLUMN1_NUM(int x){return "//div[position()=2]/div/div/div/div[contains(text(),'" + x + "')]";}
	public static final String HEADLINES_COLUMN1_NEXT = "//div[position()=2]/div/div/div/div[contains(@class,'nextButton')]";
	public static       String HEADLINES_COLUMN1_RESULT(int x){ return "//div[position()=2]/div/div[@class='hlItemBox' and position()=" + x + "]";}
	public static final String HEADLINES_COLUMN2_PREV = "//div[position()=3]/div/div/div/div[contains(@class,'prevButton')]";
	public static       String HEADLINES_COLUMN2_NUM(int x){return "//div[position()=3]/div/div/div/div[contains(text(),'" + x + "')]";}
	public static final String HEADLINES_COLUMN2_NEXT = "//div[position()=3]/div/div/div/div[contains(@class,'nextButton')]";
	public static       String HEADLINES_COLUMN2_RESULT(int x){ return "//div[position()=3]/div/div[@class='hlItemBox' and position()=" + x + "]";}
	public static final String HEADLINES_TABLET_GROUPBY = "//select[@class='gwt-ListBox']";
	public static       String HEADLINES_TABLET_TITLE_NUM(int x){ return "//div[position()=" + x +"]/div[@class='hGroupHeader']";}
	public static       String HEADLINES_TABLET_LIST_NUM(int x,int y){ return "//div[position()=" + x + "]/div[@class='blue_custom_scroll']/div/div/div/div[position()=" + y + "]/div";}
	public static       String HEADLINES_TABLET_LIST_NUM_HIGHLIGHTED(int x,int y){ return "//div[position()=" + x + "]/div[@class='blue_custom_scroll']/div/div/div/div[position()=" + y + " and contains(@class,'hlItemBox-hover')]/div";}
	public static       String HEADLINES_TABLET_VIEWALL_NUM(int x){ return "//div[position()=" + x +"]/div[@class='hgMoreLikeThis']";}
	public static final String HEADLINES_FILTERBY_INFO = "//div[@class='exploreByWhatIsThis']";
	public static       String HEADLINES_FILTERBY_NUMTYPE_NUM(int type,int x){ return "//div[contains(@class,'tagList') and position()=" + type + "]/div/div[position()=" + x + "]";}
	public static       String HEADLINES_FILTERBY_STRINGTYPE_STRING(String type,String x){ return "//div[@mptag='" + type + "']/div/span[text()='" + x + "']";}
	public static final String HEADLINES_FITLERBY_AUTHOR_SEARCH = "//input[@class='authorsTagSuggestBox']";
	public static final String HEADLINES_TABLET_SECTORNOTSPECIFIED = "//div[contains(@class,'hGroupHeader') and contains(text(),'SECTOR')]";
	public static final String HEADLINES_TABLET_PRODUCTNOTSPECIFIED = "//div[contains(@class,'hGroupHeader') and contains(text(),'PRODUCT')]";
	public static final String HEADLINES_TABLET_CONTENTNOTSPECIFIED = "//div[contains(@class,'hGroupHeader') and contains(text(),'CONTENT TYPE')]";
	public static final String HEADLINES_TABLET_AUTHORNOTSPECIFIED = "//div[contains(@class,'hGroupHeader') and contains(text(),'AUTHOR')]";
	public static final String HEADLINES_TABLET_REGIONNOTSPECIFIED = "//div[contains(@class,'hGroupHeader') and contains(text(),'REGION')]";

	// Footer
	public static final String FOOTER_PRIVACY = "link=Terms of Use";
	public static final String FOOTER_TERMS = "link=Privacy Policy";
}
