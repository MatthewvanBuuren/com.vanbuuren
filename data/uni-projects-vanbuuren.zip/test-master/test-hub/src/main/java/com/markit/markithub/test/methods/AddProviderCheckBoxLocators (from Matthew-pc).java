package com.markit.markithub.test.methods;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.markit.markithub.test.Data.PerProviderInfo;
import com.thoughtworks.selenium.Selenium;

public class AddProviderCheckBoxLocators {

	private static final Logger logger = LoggerFactory.getLogger(AddProviderCheckBoxLocators.class);

	// Selenium.getXPathCount does not work on getting
	// number of checkBoxes, It breaks after x amount of providers.
	private static final int MAX_PROVIDERS = 1000;

	private static List<CurrentlyAvailableBox> allProviders = new ArrayList<CurrentlyAvailableBox>();


	public AddProviderCheckBoxLocators(Selenium selenium){
		String name = "";
		for(int x = 1 ; x <= MAX_PROVIDERS ; x++){
			if(selenium.isElementPresent("//div[@class='PrimaryProviderItem' and position()="+x+"]/div[@class='labelWithSelectorBox']/span/label")){
				name = selenium.getText("//div[@class='PrimaryProviderItem' and position()="+x+"]/div[@class='labelWithSelectorBox']/span/label");
			} else {
				break;
			}
			for(PerProviderInfo perProv : PerProviderInfo.allProviders()){
				if(perProv.fullName.equals(name)){
					allProviders.add(new CurrentlyAvailableBox(x,perProv));
					break;
				}
				logger.debug("Could not match 'Currently Available Provider' in list by name.");
			}
		}
	}

	public CurrentlyAvailableBox getCurrentlyAvailableBox(PerProviderInfo perProv){
		for(CurrentlyAvailableBox cab : allProviders){
			if(cab.provider.equals(perProv)){
				return cab;
			}
		}
		logger.debug("That PerProviderInfo: " + perProv.fullName + " isnt available.");
		return null;
	}

}
