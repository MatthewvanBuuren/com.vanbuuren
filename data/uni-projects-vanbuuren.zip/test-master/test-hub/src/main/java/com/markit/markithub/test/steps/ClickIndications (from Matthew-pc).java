package com.markit.markithub.test.steps;

import com.markit.markithub.test.Data.IndicationsLocators;
import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.model.StepBase;

public class ClickIndications extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Click Indications";

	public ClickIndications(){
		super(name);
	}

	public void execute() throws Exception{
		basic.pressButtonSlow(Locators.BANNER_INDICATIONS_BUTTON,super.getSeleniumInstance());
		basic.waitForElementPresent(IndicationsLocators.INDICATIONS_MAIN_LOAD, super.getSeleniumInstance());
	}
}
