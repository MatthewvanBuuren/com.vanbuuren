package com.markit.markithub.test.Data;

public class NocLocators {

	public static final String CONTENTSOURCE_BAM = "//div/span[contains(text(),'BofA Merrill Lynch')]";
	public static final String CONTENTSOURCE_BC = "//div/span[contains(text(),'Barclays Capital')]";
	public static final String CONTENTSOURCE_BNP = "//div/span[contains(text(),'BNP Paribas')]";
	public static final String CONTENTSOURCE_C = "//div/span[contains(text(),'Citi')]";
	public static final String CONTENTSOURCE_CS = "//div/span[contains(text(),'Credit Suisse')]";
	public static final String CONTENTSOURCE_DB = "//div/span[contains(text(),'Deutsche Bank')]";
	public static final String CONTENTSOURCE_GS = "//div/span[contains(text(),'Goldman Sachs')]";
	public static final String CONTENTSOURCE_JPM = "//div/span[contains(text(),'J.P.Morgan')]";
	public static final String CONTENTSOURCE_MS = "//div/span[contains(text(),'Morgan Stanley')]";
	public static final String CONTENTSOURCE_RBC = "//div/span[contains(text(),'Royal Bank Of Canada')]";
	public static final String CONTENTSOURCE_UBS = "//div/span[contains(text(),'UBS')]";
	public static final String CONTENTSOURCE_DJ = "//div/span[contains(text(),'Dow Jones')]";
	public static final String CONTENTSOURCE_MKT = "//div/span[contains(text(),'Markit')]";

	public static final String RESEARCH_FIRST = "//div[not(contains(@style,'display: none'))]/div[@class='headlineList']/div[contains(@class,'hlItemBox') and position()=1]/div[contains(@class,'hlItem')]";

}
