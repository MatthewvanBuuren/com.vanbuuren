package com.markit.markithub.test.steps.addprovider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.markit.markithub.test.Data.AddProviderLocators;
import com.markit.markithub.test.Data.SubProvider;
import com.markit.markithub.test.model.StepBase;
import com.thoughtworks.selenium.SeleniumException;

public class SuggestNewProviderIncomplete extends StepBase{

	private static final long serialVersionUID = 1L;
	private static final Logger logger = LoggerFactory.getLogger(SuggestNewProviderIncomplete.class);
	public static final String name = "Fill out suggest provider";

	public SuggestNewProviderIncomplete() {
		super(name);
	}

	public void execute() throws Exception{
		if(!super.getSeleniumInstance().isElementPresent(SubProvider.BANKS.hidden_table)){
			basic.pressButtonSlow(SubProvider.BANKS.getAlreadyAProviderCheckBoxWithPanel(2), super.getSeleniumInstance());
			basic.pressButtonSlow(SubProvider.BANKS.getInviteProviderCheckBoxWithPanel(2), super.getSeleniumInstance());
			basic.typeString(SubProvider.BANKS.getInviteProviderContactEmail(3), "Test - Email", super.getSeleniumInstance());
			basic.typeString(SubProvider.BANKS.getInviteProviderSalesPerson(3), "Test - Contact", super.getSeleniumInstance());
			try{
				basic.pressButtonSlow(AddProviderLocators.ADDPROVIDER_SUBMIT, super.getSeleniumInstance());
				throw new Exception("There was no alert/error.");
			}catch(SeleniumException se){
				logger.info("Squashed Selenium Exception: ",se);
			}
		}
	}
}
