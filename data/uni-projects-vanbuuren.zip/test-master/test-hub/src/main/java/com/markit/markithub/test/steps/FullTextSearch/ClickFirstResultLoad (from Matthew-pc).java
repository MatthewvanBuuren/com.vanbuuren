package com.markit.markithub.test.steps.FullTextSearch;

import java.io.File;

import com.markit.markithub.test.Data.FullTextSearchLocators;
import com.markit.markithub.test.methods.ResponseFinder;
import com.markit.markithub.test.model.StepBase;

public class ClickFirstResultLoad extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Click first result and assert that document loads";

	public ClickFirstResultLoad(){
		super(name);
	}

	public void execute() throws Exception{
		ResponseFinder resFind= new ResponseFinder();
		resFind.get200GETResponse(FullTextSearchLocators.FTS_RESEARCH_RESULT_ONE , super.getSeleniumInstance());
	}

	public void takeScreenshot(String filename, File outputFile){
		basic.takeScreenshot(filename, super.getSeleniumInstance(), outputFile);
	}
}
