package com.markit.markithub.test.steps;

import com.markit.markithub.test.Data.DirectoryLocators;
import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.model.StepBase;

public class ClickDirectory extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Click Directory";

	public ClickDirectory(){
		super(name);
	}

	public void execute() throws Exception{
		basic.pressButtonSlow(Locators.BANNER_DIRECTORY_BUTTON,super.getSeleniumInstance());
		basic.waitForElementPresent(DirectoryLocators.DIRECTORY_ADVANCED_SEARCH_CONTACT_LIST, super.getSeleniumInstance());
	}
}
