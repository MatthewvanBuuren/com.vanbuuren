package com.markit.markithub.test.Data;

/**
 * For convenience of not having to hard-code selenium locators everywhere
 * XPath etc.
 */
public class QuickAcessLocators {

	//Dropdown Menu
	public static final String QCK_DROPDOWN_X = "//div[contains(@class,'btnClose')]";
	public static final String QCK_DROPDOWN_CLOSE_AWAY = "//div[contains(@class,'exploreByWhatIsThis')]";

	//Result
	public static final String QCK_DROPDOWN_AMAZON = "//div[contains(@class,'shTag') and contains(text(),'Amazon.com')]";

	//Sort Vews
	public static final String QCK_SORTBY_DATE = "//div[contains(@class,'btnSortByDate')]";
	public static final String QCK_SORTBY_RELEVANCE = "//div[contains(@class,'btnSortByRelevance')]";
}
