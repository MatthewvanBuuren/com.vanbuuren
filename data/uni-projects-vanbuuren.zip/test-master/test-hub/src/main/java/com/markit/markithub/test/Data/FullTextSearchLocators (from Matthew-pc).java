package com.markit.markithub.test.Data;

public class FullTextSearchLocators {

	// Full Text Search
	public static final String FTS_SEARCH_NORESULT = "//div/span[contains(text(),'No records found.')]";
	public static final String FTS_SEARCH_TERM1_DEBT = "Debt";
	public static final String FTS_SEARCH_TERM1_DEBT_RESULT = "//div[@class='hliHeadline' and contains(text(),'"+FTS_SEARCH_TERM1_DEBT+"')]";
	public static final String FTS_SEARCH_TERM2_GREECE = "Greece";
	public static final String FTS_SEARCH_TERM2_GREECE_RESULT = "//div[@class='hliHeadline' and contains(text(),'"+FTS_SEARCH_TERM2_GREECE+"')]";
	public static final String FTS_SEARCH_TERM3_HIGHYIELD = "High Yield";
	public static final String FTS_SEARCH_TERM3_HIGHYIELD_RESULT = "//div[@class='hliHeadline' and contains(text(),'"+FTS_SEARCH_TERM3_HIGHYIELD+"')]";
	public static final String FTS_SEARCH_TERM4_JAPAN = "Japan";
	public static final String FTS_SEARCH_TERM4_JAPAN_RESULT = "//div[@class='hliHeadline' and contains(text(),'"+FTS_SEARCH_TERM4_JAPAN+"')]";
	public static final String FTS_SEARCH_TERM5_FORD = "Ford";
	public static final String FTS_SEARCH_TERM5_FORD_RESULT = "//div[@class='hliHeadline' and contains(text(),'"+FTS_SEARCH_TERM5_FORD+"')]";
	public static final String FTS_SEARCH_TERM6_FORDWILD = "Ford*";
	public static final String FTS_SEARCH_TERM6_FORDWILD_RESULT = "//div[@class='hliHeadline' and contains(text(),'"+FTS_SEARCH_TERM5_FORD+"')]";
	public static final String FTS_SEARCH_TERM7_FORDFASSAD = "Fordfassad";
	public static final String FTS_SEARCH_TERM7_FORDFASSAD_RESULT = "//div[@class='hliHeadline' and contains(text(),'"+FTS_SEARCH_TERM7_FORDFASSAD+"')]";
	public static final String FTS_SEARCH_TERM8_FASSAD = "fassad";
	public static final String FTS_SEARCH_TERM8_FASSAD_RESULT = "//div[@class='hliHeadline' and contains(text(),'"+FTS_SEARCH_TERM8_FASSAD+"')]";
	public static final String FTS_SEARCH_TERM9_HIGHYIELDWILD = "High Yield*";
	public static final String FTS_SEARCH_TERM9_HIGHYIELDWILD_RESULT = "//div[@class='hliHeadline' and contains(text(),'"+FTS_SEARCH_TERM3_HIGHYIELD+"')]";
	public static final String FTS_SEARCH_TERM10_HIGHYIELDFASSAD = "High Yieldfassad";
	public static final String FTS_SEARCH_TERM10_HIGHYIELDFASSAD_RESULT = "//div[@class='hliHeadline' and contains(text(),'"+FTS_SEARCH_TERM10_HIGHYIELDFASSAD+"')]";

	//RESULT
	public static final String FTS_RESEARCH_RESULT_ONE = "//div[position()=2]/div[contains(@class,'headlineList')]/div[contains(@class,'hlItemBox') and position()=1]";
	public static final String FTS_RESEARCH_RESULT_ONE_HIGHLIGHTED = "//div[position()=2]/div[contains(@class,'headlineList')]/div[contains(@class,'hlItemBox-hover') and position()=1]";
	public static final String FTS_RESEARCH_RESULT_FIFTEEN = "//div[position()=2]/div[contains(@class,'headlineList')]/div[contains(@class,'hlItemBox') and position()=15]";
	public static final String FTS_RESEARCH_RESULT_FIFTEEN_HIGHLIGHTED = "//div[position()=2]/div[contains(@class,'headlineList')]/div[contains(@class,'hlItemBox-hover') and position()=15]";
	public static final String FTS_RESEARCH_NEXT = "//div[position()=2]/div/div[@class='pageBarBox']/div/div[contains(@class,'nextButton')]";
	public static final String FTS_RESEARCH_1 = "//div[position()=2]/div/div[@class='pageBarBox']/div/div[contains(@class,'pageBarButton') and contains(text(),'1')]";
	public static final String FTS_RESEARCH_2 = "//div[position()=2]/div/div[@class='pageBarBox']/div/div[contains(@class,'pageBarButton') and contains(text(),'2')]";
	public static final String FTS_RESEARCH_5 = "//div[position()=2]/div/div[@class='pageBarBox']/div/div[contains(@class,'pageBarButton') and contains(text(),'5')]";
	public static final String FTS_RESEARCH_PREV = "//div[position()=2]/div/div[@class='pageBarBox']/div/div[contains(@class,'prevButton')]";
	public static final String FTS_NEWS_RESULT_ONE = "//div[position()=3]/div[contains(@class,'headlineList')]/div[contains(@class,'hlItemBox') and position()=1]";
	public static final String FTS_NEWS_RESULT_FIFTEEN = "//div[position()=3]/div[contains(@class,'headlineList')]/div[contains(@class,'hlItemBox') and position()=15]";
	public static final String FTS_NEWS_RESULT_ONE_HIGHLIGHTED = "//div[position()=3]/div[contains(@class,'headlineList')]/div[contains(@class,'hlItemBox-hover') and position()=1]";
	public static final String FTS_NEWS_RESULT_FIFTEEN_HIGHLIGHTED = "//div[position()=3]/div[contains(@class,'headlineList')]/div[contains(@class,'hlItemBox-hover') and position()=15]";
	public static final String FTS_NEWS_NEXT = "//div[position()=3]/div/div[@class='pageBarBox']/div/div[contains(@class,'nextButton')]";
	public static final String FTS_NEWS_PREV = "//div[position()=3]/div/div[@class='pageBarBox']/div/div[contains(@class,'prevButton')]";
	public static final String FTS_NEWS_2 = "//div[position()=3]/div/div[@class='pageBarBox']/div/div[contains(@class,'pageBarButton') and contains(text(),'2')]";
	public static final String FTS_NEWS_2_HOVER = "//div[position()=3]/div/div[@class='pageBarBox']/div/div[contains(@class,'pageBarButton-hover') and contains(text(),'2')]";
	public static final String FTS_NEWS_5 = "//div[position()=3]/div/div[@class='pageBarBox']/div/div[contains(@class,'pageBarButton') and contains(text(),'5')]";
	public static final String FTS_NEWS_5_HOVER = "//div[position()=3]/div/div[@class='pageBarBox']/div/div[contains(@class,'pageBarButton-hover') and contains(text(),'5')]";
	public static final String FTS_NEWS_6 = "//div[position()=3]/div/div[@class='pageBarBox']/div/div[contains(@class,'pageBarButton') and contains(text(),'6')]";

	// TAGS
	public static final String FTS_TAG_CLEAR = "//div[contains(@class,'orderedCriteriaControlClearAll')]";
	public static final String FTS_TAG_CLEAR_HIDDEN = "//div[contains(@class,'orderedCriteriaControlClearAll') and contains(@style,'display: none')]";
	public static final String FTS_TAG_HIGHYIELD = "//div[contains(@class,'orderedCriteriaWidget') and contains(text(),'High Yield')]";
	public static final String FTS_TAG_RESEARCH = "//div[contains(@class,'orderedCriteriaWidget') and contains(text(),'Research / Strategy')]";
	public static final String FTS_TAG_INDICIES = "//div[contains(@class,'orderedCriteriaWidget') and contains(text(),'Indices / Analytics')]";
	public static final String FTS_TAG_DESK = "//div[contains(@class,'orderedCriteriaWidget') and contains(text(),'Desk Comment')]";
	public static final String FTS_TAG_MARKET = "//div[contains(@class,'orderedCriteriaWidget') and contains(text(),'Market Data')]";
	public static final String FTS_TAG_NEWS = "//div[contains(@class,'orderedCriteriaWidget') and contains(text(),'News')]";
	public static final String FTS_TAG_NORTHAMERICA = "//div[contains(@class,'orderedCriteriaWidget') and contains(text(),'North America')]";
	public static final String FTS_TAG_AUTHOR = "//div[contains(@class,'orderedCriteriaWidget') and contains(text(),'"+FullTextSearchLocators.FILTERBY_AUTHOR+"')]";

	// FILTERBY
	public static final String FILTERBY_WHATISTHIS = "//div[contains(@class,'exploreByWhatIsThis')]";
	public static final String FILTERBY_WHATISTHIS_POPUP = "//div[contains(@class,'exploreByWhatIsThisPopup')]";

	public static final String FILTERBY_CONTENTSOURCE_BAM = "//div[@class='tagListItem']/span[contains(text(),'" + PerProviderInfo.BAM.fullName + "')]";
	public static final String FILTERBY_CONTENTSOURCE_BC = "//div[@class='tagListItem']/span[contains(text(),'" + PerProviderInfo.BC.fullName + "')]";
	public static final String FILTERBY_CONTENTSOURCE_BNP = "//div[@class='tagListItem']/span[contains(text(),'" + PerProviderInfo.BNP.fullName + "')]";
	public static final String FILTERBY_CONTENTSOURCE_C = "//div[@class='tagListItem']/span[contains(text(),'" + PerProviderInfo.C.fullName + "')]";
	public static final String FILTERBY_CONTENTSOURCE_CS = "//div[@class='tagListItem']/span[contains(text(),'" + PerProviderInfo.CS.fullName + "')]";
	public static final String FILTERBY_CONTENTSOURCE_DB = "//div[@class='tagListItem']/span[contains(text(),'" + PerProviderInfo.DB.fullName + "')]";
	public static final String FILTERBY_CONTENTSOURCE_GS = "//div[@class='tagListItem']/span[contains(text(),'" + PerProviderInfo.GS.fullName + "')]";
	public static final String FILTERBY_CONTENTSOURCE_JPM = "//div[@class='tagListItem']/span[contains(text(),'" + PerProviderInfo.JPM.fullName + "')]";
	public static final String FILTERBY_CONTENTSOURCE_MS = "//div[@class='tagListItem']/span[contains(text(),'" + PerProviderInfo.MS.fullName + "')]";
	public static final String FILTERBY_CONTENTSOURCE_UBS = "//div[@class='tagListItem']/span[contains(text(),'" + PerProviderInfo.UBS.fullName + "')]";
	public static final String FILTERBY_CONTENTSOURCE_DJ = "//div[@class='tagListItem']/span[contains(text(),'" + PerProviderInfo.DJ.fullName + "')]";
	public static final String FILTERBY_CONTENTSOURCE_MKT = "//div[@class='tagListItem']/span[contains(text(),'" + PerProviderInfo.MKT.fullName + "')]";


	public static final String FILTERBY_AUTHOR_MORE = "//div[position()=3]/div[contains(@class,'tagListToggle') and contains(text(),'More')]";
	public static final String FILTERBY_AUTHOR_LESS = "//div[position()=3]/div[contains(@class,'tagListToggle') and contains(text(),'Less')]";
	public static final String FILTERBY_PRODUCT_MORE = "//div[position()=4]/div[contains(@class,'tagListToggle') and contains(text(),'More')]";
	public static final String FILTERBY_PRODUCT_LESS = "//div[position()=4]/div[contains(@class,'tagListToggle') and contains(text(),'Less')]";
	public static final String FILTERBY_SECTOR_MORE = "//div[position()=5]/div[contains(@class,'tagListToggle') and contains(text(),'More')]";
	public static final String FILTERBY_SECTOR_LESS = "//div[position()=5]/div[contains(@class,'tagListToggle') and contains(text(),'Less')]";
	public static final String FILTERBY_INDUSTRY_MORE = "//div[position()=6]/div[contains(@class,'tagListToggle') and contains(text(),'More')]";
	public static final String FILTERBY_INDUSTRY_LESS = "//div[position()=6]/div[contains(@class,'tagListToggle') and contains(text(),'Less')]";
	public static final String FILTERBY_REGION_MORE = "//div[position()=7]/div[contains(@class,'tagListToggle') and contains(text(),'More')]";
	public static final String FILTERBY_REGION_LESS = "//div[position()=7]/div[contains(@class,'tagListToggle') and contains(text(),'Less')]";
	public static final String FILTERBY_COUNTRY_MORE = "//div[position()=8]/div[contains(@class,'tagListToggle') and contains(text(),'More')]";
	public static final String FILTERBY_COUNTRY_LESS = "//div[position()=8]/div[contains(@class,'tagListToggle') and contains(text(),'Less')]";

	public static final String FILTERBY_CONTENT_RESEARCH = "//div[@class='hsTagPanel']/div[position()=1]/div/div[contains(@class,'tagListItem') and position()=1]";
	public static final String FILTERBY_CONTENT_RESEARCH_HIGHLIGHTED = "//div[@class='hsTagPanel']/div[position()=1]/div/div[contains(@class,'tagListItem-selected') and position()=1]";
	public static final String FILTERBY_CONTENT_NEWS = "//div[@class='hsTagPanel']/div[position()=1]/div/div[contains(@class,'tagListItem') and position()=5]";
	public static final String FILTERBY_CONTENT_NEWS_HIGHLIGHTED = "//div[@class='hsTagPanel']/div[position()=1]/div/div[contains(@class,'tagListItem-selected') and position()=5]";
	public static final String FILTERBY_SOURCE_ONE = "//div[@class='hsTagPanel']/div[position()=2]/div/div[contains(@class,'tagListItem') and position()=1]";
	public static final String FILTERBY_SOURCE_ONE_HIGHLIGHTED = "//div[@class='hsTagPanel']/div[position()=2]/div/div[contains(@class,'tagListItem-selected') and position()=1]";
	public static final String FILTERBY_AUTHOR_ONE = "//div[@class='hsTagPanel']/div[position()=3]/div/div[contains(@class,'tagListItem') and position()=1]";
	public static final String FILTERBY_AUTHOR_ONE_HIGHLIGHTED = "//div[@class='hsTagPanel']/div[position()=3]/div/div[contains(@class,'tagListItem-selected') and position()=1]";
	public static final String FILTERBY_AUTHOR = "Dan Galves";
	public static final String FILTERBY_AUTHOR_AUTHOR = "//div[contains(@class,'tagListItem')]/span[contains(text(),'" + FILTERBY_AUTHOR + "')]";
	public static final String FILTERBY_AUTHOR_AUTHOR_HIGHLIGHTED = "//div[contains(@class,'tagListItem-selected')]/span[contains(text(),'"+FILTERBY_AUTHOR+"')]";
	public static final String FILTERBY_PRODUCT_ONE = "//div[@class='hsTagPanel']/div[position()=4]/div/div[contains(@class,'tagListItem') and position()=1]";
	public static final String FILTERBY_PRODUCT_ONE_HIGHLIGHTED = "//div[@class='hsTagPanel']/div[position()=4]/div/div[contains(@class,'tagListItem-selected') and position()=1]";
	public static final String FILTERBY_PRODUCT_FIXEDINCOME = "//div[contains(@class,'tagListItem')]/span[contains(text(),'Fixed Income')]";
	public static final String FILTERBY_PRODUCT_FIXEDINCOME_HIGHLIGHTED = "//div[contains(@class,'tagListItem-selected')]/span[contains(text(),'Fixed Income')]";
	public static final String FILTERBY_PRODUCT_HIGHYIELD = "//div[contains(@class,'tagListItem')]/span[contains(text(),'High Yield')]";
	public static final String FILTERBY_PRODUCT_HIGHYIELD_HIGHLIGHTED = "//div[contains(@class,'tagListItem-selected')]/span[contains(text(),'High Yield')]";
	public static final String FILTERBY_PRODUCT_ECONOMICS = "//div[contains(@class,'tagListItem')]/span[contains(text(),'Economics')]";
	public static final String FILTERBY_PRODUCT_ECONOMICS_HIGHLIGHTED = "//div[contains(@class,'tagListItem-selected')]/span[contains(text(),'Economics')]";
	public static final String FILTERBY_SECTOR_ONE = "//div[@class='hsTagPanel']/div[position()=5]/div/div[contains(@class,'tagListItem') and position()=1]";
	public static final String FILTERBY_SECTOR_ONE_HIGHLIGHTED = "//div[@class='hsTagPanel']/div[position()=5]/div/div[contains(@class,'tagListItem-selected') and position()=1]";
	public static final String FILTERBY_SECTOR_FINANCIALS = "//div[contains(@class,'tagListItem')]/span[contains(text(),'Financials')]";
	public static final String FILTERBY_SECTOR_FINANCIALS_HIGHLIGHTED = "//div[contains(@class,'tagListItem-selected')]/span[contains(text(),'Financials')]";
	public static final String FILTERBY_INDUSTRY_ONE = "//div[@class='hsTagPanel']/div[position()=6]/div/div[contains(@class,'tagListItem') and position()=1]";
	public static final String FILTERBY_INDUSTRY_ONE_HIGHLIGHTED = "//div[@class='hsTagPanel']/div[position()=6]/div/div[contains(@class,'tagListItem-selected') and position()=1]";
	public static final String FILTERBY_INDUSTRY_INSURANCE = "//div[contains(@class,'tagListItem')]/span[contains(text(),'Insurance')]";
	public static final String FILTERBY_INDUSTRY_INSURANCE_HIGHLIGHTED = "//div[contains(@class,'tagListItem-selected')]/span[contains(text(),'Insurance')]";
	public static final String FILTERBY_REGION_ONE = "//div[@class='hsTagPanel']/div[position()=7]/div/div[contains(@class,'tagListItem') and position()=1]";
	public static final String FILTERBY_REGION_ONE_HIGHLIGHTED = "//div[@class='hsTagPanel']/div[position()=7]/div/div[contains(@class,'tagListItem-selected') and position()=1]";
	public static final String FILTERBY_REGION_NORTHAMERICA = "//div[contains(@class,'tagListItem')]/span[contains(text(),'North America')]";
	public static final String FILTERBY_REGION_NORTHAMERICA_HIGHLIGHTED = "//div[contains(@class,'tagListItem-selected')]/span[contains(text(),'North America')]";
	public static final String FILTERBY_COUNTRY_ONE = "//div[@class='hsTagPanel']/div[position()=8]/div/div[contains(@class,'tagListItem') and position()=1]";
	public static final String FILTERBY_COUNTRY_ONE_HIGHLIGHTED = "//div[@class='hsTagPanel']/div[position()=8]/div/div[contains(@class,'tagListItem-selected') and position()=1]";
	public static final String FILTERBY_COUNTRY_UNITEDKINGDOM = "//div[contains(@class,'tagListItem')]/span[contains(text(),'United Kingdom')]";
	public static final String FILTERBY_COUNTRY_UNITEDKINGDOM_HIGHLIGHTED = "//div[contains(@class,'tagListItem-selected')]/span[contains(text(),'United Kingdom')]";

	//TABLEVIEW
	public static final String TABLETVIEW_LOADINGHEADLINES_HIDDEN = "//div[contains(@style,'display: none')]/div[contains(text(),'Loading Headlines')]";
	public static final String TABLETVIEW_HGROUPVIEW_HIDDEN = "//div[contains(@class,'hGroupView') and contains(@style,'display: none')]";
	public static final String TABLETVIEW_HSEARCHVIEW_HIDDEN = "//div[contains(@class,'hSearchView') and contains(@style,'display: none')]";

}
