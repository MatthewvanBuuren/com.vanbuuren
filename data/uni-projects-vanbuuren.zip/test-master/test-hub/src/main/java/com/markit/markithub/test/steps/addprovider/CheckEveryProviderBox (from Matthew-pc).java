package com.markit.markithub.test.steps.addprovider;

import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.Data.PerProviderInfo;
import com.markit.markithub.test.methods.AddProviderCheckBoxLocators;
import com.markit.markithub.test.model.StepBase;

public class CheckEveryProviderBox extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Assert all Inactive are present";

	public CheckEveryProviderBox() {
		super(name);
	}

	public void execute() throws Exception{
		AddProviderCheckBoxLocators chechBoxLocat= new AddProviderCheckBoxLocators(super.getSeleniumInstance());
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_BAM_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_BAM)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BAM).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BAM).getEquities(), super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_BC_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_BC)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BC).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BC).getEquities(), super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_BNP_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_BNP)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BNP).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BNP).getEquities(), super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_C_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_CS)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.C).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.C).getEquities(), super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_CS_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_CS)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.CS).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.CS).getEquities(), super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_DB_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_DB)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.DB).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.DB).getEquities(), super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_GS_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_GS)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.GS).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.GS).getEquities(), super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_JPM_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_JPM)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.JPM).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.JPM).getEquities(), super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_MS_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_MS)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MS).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MS).getEquities(), super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_RBC_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_RBC)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.RBC).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.RBC).getEquities(), super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_UBS_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_UBS)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.UBS).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.UBS).getEquities(), super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_MKT_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_MKT)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MKT).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MKT).getEquities(), super.getSeleniumInstance());
		}
	}
}
