package com.markit.markithub.test.steps.FullTextSearch;

import com.markit.markithub.test.Data.FullTextSearchLocators;
import com.markit.markithub.test.model.StepBase;

public class FilterByHighYield extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Filter By High Yield";

	public FilterByHighYield(){
		super(name);
	}

	public void execute() throws Exception{
		basic.pressButton(FullTextSearchLocators.FILTERBY_PRODUCT_HIGHYIELD, super.getSeleniumInstance());
		basic.waitForElementPresent(FullTextSearchLocators.FILTERBY_PRODUCT_HIGHYIELD_HIGHLIGHTED, super.getSeleniumInstance());
	}
}
