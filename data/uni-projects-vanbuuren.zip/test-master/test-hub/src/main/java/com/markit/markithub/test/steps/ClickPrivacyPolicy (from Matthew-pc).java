package com.markit.markithub.test.steps;

import com.markit.markithub.test.Data.NavigationLocators;
import com.markit.markithub.test.model.StepBase;
import com.markit.markithub.test.service.PopupManagement;

public class ClickPrivacyPolicy extends StepBase{

	private static final long serialVersionUID = 1L;
	public static final String name = "Click Privacy Policy";
	private static final PopupManagement popup = new PopupManagement();

	public ClickPrivacyPolicy(){
		super(name);
	}

	public void execute() throws Exception{
		basic.pressButton(NavigationLocators.NAVIGATION_PRIVACYPOLICY_LINK, super.getSeleniumInstance());
		super.getSeleniumInstance().selectWindow(NavigationLocators.NAVIGATION_PRIVACYPOLICY_WINDOW);
		//ResponseFinder responseFinder = new ResponseFinder();
	}

	public void teardown() {
		super.getSeleniumInstance().selectWindow(null);
		popup.closePopup(NavigationLocators.NAVIGATION_PRIVACYPOLICY_WINDOW);
	}
}
