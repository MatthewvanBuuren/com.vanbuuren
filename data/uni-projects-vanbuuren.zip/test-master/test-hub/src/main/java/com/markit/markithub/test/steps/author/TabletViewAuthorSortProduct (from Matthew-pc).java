package com.markit.markithub.test.steps.author;

import com.markit.markithub.test.Data.AuthorLocators;
import com.markit.markithub.test.Data.FullTextSearchLocators;
import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.model.StepBase;

public class TabletViewAuthorSortProduct extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Change Group By to 'Product'";

	public TabletViewAuthorSortProduct(){
		super(name);
	}

	public void execute() throws Exception{
		basic.selectDropdown(Locators.HEADLINES_TABLET_GROUPBY, "Product", super.getSeleniumInstance());
		basic.waitForBothElementsPresent(FullTextSearchLocators.TABLETVIEW_LOADINGHEADLINES_HIDDEN, FullTextSearchLocators.TABLETVIEW_HSEARCHVIEW_HIDDEN, super.getSeleniumInstance());
		basic.waitForEitherElementPresent(AuthorLocators.AUTH_TABLETVIEW_ELEMENT1_VIEWALL, FullTextSearchLocators.FTS_SEARCH_NORESULT, super.getSeleniumInstance());
	}
}
