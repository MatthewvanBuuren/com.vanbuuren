package com.markit.markithub.test.steps;

import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.Data.NewsLocators;
import com.markit.markithub.test.model.StepBase;

public class ClickNews extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Click News";

	public ClickNews(){
		super(name);
	}

	public void execute() throws Exception{
		basic.pressButtonSlow(Locators.BANNER_NEWS_BUTTON,super.getSeleniumInstance());
		basic.waitForElementPresent(NewsLocators.NEWS_MAIN_LOADING_HIDDEN, super.getSeleniumInstance());
	}
}
