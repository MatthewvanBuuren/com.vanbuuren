package com.markit.markithub.test.steps.addprovider;

import com.markit.markithub.test.Data.SubProvider;
import com.markit.markithub.test.model.StepBase;

public class ClickAllInviteProvider extends StepBase{

	private static final long serialVersionUID = 1L;
	public static final String name = "Click all 'Invite Provider' Checkbox's";

	public ClickAllInviteProvider() {
		super(name);
	}

	public void execute() throws Exception{
		for(SubProvider sub : SubProvider.getAll()){
			int NoOfProviderInvites = getInviteProviderCount(sub);
			if(NoOfProviderInvites > 0){

				for(int x = 2; x < (NoOfProviderInvites+2) ; x ++){
					basic.pressButtonSlow(sub.getInviteProviderCheckBoxWithPanel(x),super.getSeleniumInstance());
					basic.assertElementPresent(sub.getInviteProviderCheckBoxWithPanelTrue(x), super.getSeleniumInstance());
				}
			}
		}
	}

	private int getInviteProviderCount(SubProvider sub){
		int x = -1;
		for(x = 2 ; x < 100 ; x++){
			if(!super.getSeleniumInstance().isElementPresent(sub.getInviteProviderCheckBoxWithPanel(x))){
				if(!super.getSeleniumInstance().isElementPresent(sub.getInviteProviderCheckBoxWithPanel(x+1))){
					break;
				}
			}
		}
		if(x < 99){
		return x-2;
		} else {
			return -1;
		}
	}
}
