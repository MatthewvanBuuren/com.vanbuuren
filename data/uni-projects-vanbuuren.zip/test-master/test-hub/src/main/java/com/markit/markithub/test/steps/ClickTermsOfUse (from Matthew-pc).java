package com.markit.markithub.test.steps;

import com.markit.markithub.test.Data.NavigationLocators;
import com.markit.markithub.test.model.StepBase;
import com.markit.markithub.test.service.PopupManagement;

public class ClickTermsOfUse extends StepBase{

	private static final long serialVersionUID = 1L;
	public static final String name = "Click Terms of Use";
	private static final PopupManagement popup = new PopupManagement();

	public ClickTermsOfUse(){
		super(name);
	}

	public void execute() throws Exception{
		basic.pressButton(NavigationLocators.NAVIGATION_TERMSOFUSE_LINK, super.getSeleniumInstance());
		super.getSeleniumInstance().selectWindow(NavigationLocators.NAVIGATION_TERMSOFUSE_WINDOW);
		//TODO: some Kind of Load Event
	}

	public void teardown() {
		super.getSeleniumInstance().selectWindow(null);
		popup.closePopup(NavigationLocators.NAVIGATION_TERMSOFUSE_WINDOW);
	}
}
