package com.markit.markithub.test.steps.externalprovider;

import com.markit.markithub.test.Data.ExternalProviderLocator;
import com.markit.markithub.test.model.StepBase;

public class MSOpen extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Open page";
	public static final String WINDOW_NAME = "Morgan Stanley";
	public static final String TIMEOUT_MS = "30000";

	public MSOpen() {
		super(name);
	}

	@Override
	public void primer() throws Exception{
		super.getSeleniumInstance().windowFocus();
		super.getSeleniumInstance().windowMaximize();
		super.getSeleniumInstance().openWindow(ExternalProviderLocator.MS_URL,WINDOW_NAME);

	}

	public void execute() throws Exception{
		super.getSeleniumInstance().waitForPopUp(WINDOW_NAME, TIMEOUT_MS);
		super.getSeleniumInstance().selectWindow(WINDOW_NAME);
		super.getSeleniumInstance().windowFocus();
		super.getSeleniumInstance().windowMaximize();
	}
}
