package com.markit.markithub.test.steps.FullTextSearch;

import com.markit.markithub.test.Data.FullTextSearchLocators;
import com.markit.markithub.test.model.StepBase;

public class FilterByResearch extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Filter By Content Type Research - Strategy";

	public FilterByResearch(){
		super(name);
	}

	public void execute() throws Exception{
		basic.pressButton(FullTextSearchLocators.FILTERBY_CONTENT_RESEARCH, super.getSeleniumInstance());
		basic.waitForElementPresent(FullTextSearchLocators.FILTERBY_CONTENT_RESEARCH_HIGHLIGHTED, super.getSeleniumInstance());
	}
}
