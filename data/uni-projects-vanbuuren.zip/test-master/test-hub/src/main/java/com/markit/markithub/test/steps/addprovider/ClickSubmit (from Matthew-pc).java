package com.markit.markithub.test.steps.addprovider;

import com.markit.markithub.test.Data.AddProviderLocators;
import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.model.StepBase;

public class ClickSubmit extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Click Submit.";

	public ClickSubmit() {
		super(name);
	}

	public void execute() throws Exception{
		basic.pressButton(AddProviderLocators.ADDPROVIDER_SUBMIT , super.getSeleniumInstance());
		basic.waitForBothElementsPresent(Locators.BANNER_SEARCH_LOADING_RESEARCH_HIDDEN, Locators.BANNER_SEARCH_LOADING_NEWS_HIDDEN, super.getSeleniumInstance());
	}
}
