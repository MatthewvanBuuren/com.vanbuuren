package com.markit.markithub.test.steps.FullTextSearch;

import com.markit.markithub.test.Data.FullTextSearchLocators;
import com.markit.markithub.test.model.StepBase;

public class FilterByAuthor extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Filter By '" + FullTextSearchLocators.FILTERBY_AUTHOR + "'";

	public FilterByAuthor(){
		super(name);
	}

	public void execute() throws Exception{
		if(super.getSeleniumInstance().isElementPresent(FullTextSearchLocators.FILTERBY_AUTHOR_MORE)){
			super.getSeleniumInstance().click(FullTextSearchLocators.FILTERBY_AUTHOR_MORE);
		}
		basic.pressButton(FullTextSearchLocators.FILTERBY_AUTHOR_AUTHOR, super.getSeleniumInstance());
		basic.waitForElementPresent(FullTextSearchLocators.FILTERBY_AUTHOR_AUTHOR_HIGHLIGHTED, super.getSeleniumInstance());
	}
}
