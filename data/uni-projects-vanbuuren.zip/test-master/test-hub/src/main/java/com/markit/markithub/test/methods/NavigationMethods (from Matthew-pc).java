package com.markit.markithub.test.methods;

import com.thoughtworks.selenium.Selenium;

public class NavigationMethods {

	/**
	 * Simulate a user pressing back on the menu.
	 *
	 * @param selenium - Selenium - The selenium instance
	 * @throws Exception
	 */
	public static void goBack(Selenium selenium) throws Exception{
		selenium.goBack();
		Thread.sleep(500);
	}
}
