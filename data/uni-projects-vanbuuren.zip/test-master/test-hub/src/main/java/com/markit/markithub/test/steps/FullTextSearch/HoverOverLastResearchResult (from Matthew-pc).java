package com.markit.markithub.test.steps.FullTextSearch;

import com.markit.markithub.test.Data.FullTextSearchLocators;
import com.markit.markithub.test.model.StepBase;

public class HoverOverLastResearchResult extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Hover over last result";

	public HoverOverLastResearchResult(){
		super(name);
	}

	public void execute() throws Exception{
		super.getSeleniumInstance().mouseOver(FullTextSearchLocators.FTS_RESEARCH_RESULT_FIFTEEN);
		basic.waitForElementPresent(FullTextSearchLocators.FTS_RESEARCH_RESULT_FIFTEEN_HIGHLIGHTED, super.getSeleniumInstance());
	}
}
