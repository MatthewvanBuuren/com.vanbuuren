package com.markit.markithub.test.steps.author;

import com.markit.markithub.test.Data.AuthorLocators;
import com.markit.markithub.test.model.StepBase;

public class TypeSearch11 extends StepBase{

	private static final long serialVersionUID = 1L;
	public static final String name = "Type '"+AuthorLocators.AUTH_SEARCH_11+"'";

	public TypeSearch11(){
		super(name);
	}

	public void execute() throws Exception{
		basic.typeString(AuthorLocators.AUTH_SEARCH_INPUT, AuthorLocators.AUTH_SEARCH_11, super.getSeleniumInstance());
		basic.waitForElementPresent(AuthorLocators.AUTH_SEARCH_RESULT_BOLD_LASTNAME, super.getSeleniumInstance());
	}
}
