package com.markit.markithub.test.Data;

/**
 * For convenience of not having to hard-code selenium locators everywhere
 * XPath etc.
 */
public class NavigationLocators {

	public static final String NAVIGATION_TERMSOFUSE_LINK = "link=Terms of Use";
	public static final String NAVIGATION_TERMSOFUSE_WINDOW = "Markit Hub Terms Of Use";

	public static final String NAVIGATION_PRIVACYPOLICY_LINK = "link=Privacy Policy";
	public static final String NAVIGATION_PRIVACYPOLICY_WINDOW = "Markit Hub Privacy Policy";



}
