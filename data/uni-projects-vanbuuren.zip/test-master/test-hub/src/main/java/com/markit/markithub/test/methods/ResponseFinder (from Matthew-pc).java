package com.markit.markithub.test.methods;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeoutException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.markit.markithub.test.Data.PerProviderInfo;
import com.markit.markithub.test.exception.DialogException;
import com.markit.markithub.test.model.ContentType;
import com.markit.markithub.test.service.HttpResponse;
import com.markit.markithub.test.service.NetworkTrafficParser;
import com.thoughtworks.selenium.Selenium;

public class ResponseFinder {

	//Average file transfer speed = 1.1Min's == So 2.0 Minute Minimum Wait.
	public static final int DEFAULT_TIMEOUT_Sdiv2 = 60;

	public static final Logger logger = LoggerFactory.getLogger(ResponseFinder.class);
	/**
	 * Check on selenium server network traffic of http responses from the browser,
	 *  With a specified wait time.
	 *
	 * @param locator - String - The element that will trigger the traffic.
	 * @param selenium - Selenium - The Selenium instance to use.
	 */

	public HttpResponse get200GETResponse(String locator, Selenium selenium) throws Exception {
		return get200GETResponse(locator,selenium,DEFAULT_TIMEOUT_Sdiv2);
	}

	/**
	 * Check on selenium server network traffic of http responses from the browser,
	 *  With a specified wait time.
	 */

	private HttpResponse get200GETResponse(String locator, Selenium selenium, int timeout) throws Exception{
		String completeNetworkTraffic = "";
		String allNetworkTraffic = "";
		List<HttpResponse> allReponses = new ArrayList<HttpResponse>();
		allNetworkTraffic = selenium.captureNetworkTraffic("xml");
		selenium.click(locator);
		Thread.sleep(2000);
			for (int second = 0;;second ++) {
				if (second >= timeout) {
					outputReponses(allNetworkTraffic,allReponses);
					throw new TimeoutException("Timed out (" + DEFAULT_TIMEOUT_Sdiv2*2 + "s)");
				}
				completeNetworkTraffic = selenium.captureNetworkTraffic("xml");
				allNetworkTraffic = allNetworkTraffic + completeNetworkTraffic;
				NetworkTrafficParser parser = new NetworkTrafficParser(completeNetworkTraffic);
				// Loop through every response.
				for (HttpResponse response : parser.getResponses()) {
					// Check that is a 200=OK, And a GET method.
					if (response.code.equals("200") && response.method.equals("GET")) {
						//Identify which host the packet belongs to, There is a case of identical host name's.
						/*
						 * The Case is caused by duplicate providers hosting content on same url e.x. Db and Dj == hub.com,
						 *  Because of this there is no break in the for loop so that it will eventually hit the right provider.
						 */
						for(PerProviderInfo perProvider : PerProviderInfo.allProviders()){
							if(response.host.contains(perProvider.host)){
								//XLS File dialog
								if(response.contentType.equals(ContentType.XLS)){
									throw new DialogException("Xls File Dialog will be displayed.", new Throwable("Opening " + response.fileName + ".xls"));
								}
								if(response.contentType.equals(ContentType.PDF)){
									logger.info("Response with Content-Type Pdf found");
								}
								if(response.specialContentType.equals(perProvider.specialcontenttype)){
									return response;
								}
								// Check the content-type matches.
								List<String> filename = perProvider.headlinePayloads.get(response.contentType);
								if(filename != null){
									// If it requires checking for a file.
									if(filename.size() > 0){
										for(String file : filename){
											if(response.fileName.equals(file)){
												return response;
											}
										}
										break;
									}
									return response;
								}

							}
							outputReponses(allNetworkTraffic,allReponses);
						}
					}
					allReponses.add(response);
				}
				Thread.sleep(2000);
			}
	}

	/**
	 * Write every 200 response to "C:\Output\NetworkTraffic.txt", Used in
	 *  development to identify load events.
	 *
	 * @param allNetworkTraffic - String - The traffic captured by selenium.captureNetworkTraffic().
	 * @param allResponses - List<HttpResponse> - Every HttpResponse captured from all the traffic.
	 */
	private void outputReponses(String allNetworkTraffic,List<HttpResponse> allResponses){
		try{
			//TODO: Output to Logger.debug and remove fielWriter
			FileWriter fileWriter = new FileWriter(new File("C:\\Output\\NetworkTraffic.txt"));
			fileWriter.write(allNetworkTraffic);
			for(HttpResponse response : allResponses){
				fileWriter.write(response.toString() + "\n");
				logger.debug("NetworkTraffic - " + response.toString());
			}
			fileWriter.close();
		}catch(Exception e){
			System.out.println(e);
		}
	}
}
