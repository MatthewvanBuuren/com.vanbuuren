package com.markit.markithub.test.steps.author;

import com.markit.markithub.test.Data.AuthorLocators;
import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.model.StepBase;

public class ClickFullAuthor3 extends StepBase{

	private static final long serialVersionUID = 1L;
	public static final String name = "Click '"+AuthorLocators.AUTH_SEARCH3_FULL+"'";

	public ClickFullAuthor3(){
		super(name);
	}

	public void execute() throws Exception{
		basic.pressButton(AuthorLocators.AUTH_SEARCH_RESULT_FULLNAME3, super.getSeleniumInstance());
		basic.waitForBothElementsPresent(Locators.BANNER_SEARCH_LOADING_NEWS_HIDDEN, Locators.BANNER_SEARCH_LOADING_RESEARCH_HIDDEN, super.getSeleniumInstance());
		basic.assertElementPresent(AuthorLocators.AUTH_SEARCH_RESULT_FULLNAME3_TAG, super.getSeleniumInstance());
	}
}
