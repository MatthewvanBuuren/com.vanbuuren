package com.markit.markithub.test.Data;

/**
 * For convenience of not having to hard-code selenium locators everywhere
 * XPath etc.
 */
public class IndicationsLocators {

	// Indications
	public static final String INDICATIONS_MAIN_LOAD = "//input[@type='image']";
	public static final String INDIC_MAIN_RESULTS = "link=Last update";
	public static final String INDIC_MAIN_RESULT = "//tr[2]/td[10]";
	public static final String INDIC_MAIN_NO_RESULT = "link=here";

	public static final String INDIC_CORPORATE_TEXTBOX_ISSUER = "issuer";
	public static final String INDIC_CORPORATE_TEXTBOX_COUPON_LOW = "coupon_low";
	public static final String INDIC_CORPORATE_TEXTBOX_COUPON_HIGH = "coupon_high";
	public static final String INDIC_CORPORATE_TEXTBOX_MATURITY_LOW = "maturity_low";
	public static final String INDIC_CORPORATE_TEXTBOX_MATURITY_HIGH = "maturity_high";
	public static final String INDIC_CORPORATE_RADAR_TICKER = "//input[@name='Ticker']";
	public static final String INDIC_CORPORATE_BUTTON_BONDS = "//input[@type='image']";

	public static final String INDIC_AGENCIES_SCROLL_ISSUER = "//select[@name='issuer']";
	public static final String INDIC_AGENCIES_TEXTBOX_COUPON_LOW = "document.forms[1].elements[8]";
	public static final String INDIC_AGENCIES_TEXTBOX_COUPON_HIGH = "document.forms[1].elements[9]";
	public static final String INDIC_AGENCIES_TEXTBOX_MATURITY_LOW = "document.forms[1].elements[10]";
	public static final String INDIC_AGENCIES_TEXTBOX_MATURITY_HIGH = "document.forms[1].elements[11]";
	public static final String INDIC_AGENCIES_TEXTBOX_SIZE_LOW = "document.forms[1].elements[16]";
	public static final String INDIC_AGENCIES_TEXTBOX_SIZE_HIGH = "document.forms[1].elements[17]";
	public static final String INDIC_AGENCIES_BUTTON_BONDS = "//form[2]/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/input";

	public static final String INDIC_ABS_SCROLL_ASSETCLASS = "assettype";
	public static final String INDIC_ABS_TEXTBOX_WAL_LOW = "wal_low";
	public static final String INDIC_ABS_TEXTBOX_WAL_HIGH = "wal_high";
	public static final String INDIC_ABS_BUTTON_BONDS = "//tr[3]/td/input";

	public static final String INDIC_CMO_SCROLL_FIX_TRANCHE = "tranchetype";
	public static final String INDIC_CMO_TEXTBOX_FIX_WAL_LOW = "document.forms[3].elements[9]";
	public static final String INDIC_CMO_TEXTBOX_FIX_WAL_HIGH = "document.forms[3].elements[10]";
	public static final String INDIC_CMO_BUTTON_FIX_BONDS = "//form[4]/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[3]/td/input";
	public static final String INDIC_CMO_BUTTON_FLO_BONDS = "//form[5]/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[3]/td/input";

	public static final String INDIC_EME_SCROLL_FIX_COUNTRY = "country";
	public static final String INDIC_EME_BUTTON_FIX_BONDS = "//form[6]/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/input";


}
