package com.markit.markithub.test.steps;

import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.model.StepBase;

public class OpenHub extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Open page";

	public OpenHub() {
		super(name);
	}

	@Override
	public void primer() throws Exception{
		super.getSeleniumInstance().windowFocus();
		super.getSeleniumInstance().windowMaximize();
		super.getSeleniumInstance().open("/");
	}

	public void execute() throws Exception{
		basic.waitForElementPresent(Locators.LOGIN_SUBMIT, super.getSeleniumInstance());
	}
}
