package com.markit.markithub.test.steps.addprovider;

import com.markit.markithub.test.Data.AddProviderLocators;
import com.markit.markithub.test.Data.PerProviderInfo;
import com.markit.markithub.test.methods.AddProviderCheckBoxLocators;
import com.markit.markithub.test.model.StepBase;

public class CheckDJProviderBox extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Click Dj CheckBox";

	public CheckDJProviderBox() {
		super(name);
	}

	public void execute() throws Exception{
		AddProviderCheckBoxLocators chechBoxLocat= new AddProviderCheckBoxLocators(super.getSeleniumInstance());
		basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.DJ).getMainCheckbox(), super.getSeleniumInstance());
		basic.waitForElementPresentandVisible(AddProviderLocators.DJ_OTHER_TEXTBOX, super.getSeleniumInstance());
	}
}
