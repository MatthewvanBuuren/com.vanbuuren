package com.markit.markithub.test.steps.FullTextSearch;

import com.markit.markithub.test.Data.FullTextSearchLocators;
import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.model.StepBase;

public class ClearAll extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Click 'Clear All'.";

	public ClearAll(){
		super(name);
	}

	public void execute() throws Exception{
		basic.pressButton(FullTextSearchLocators.FTS_TAG_CLEAR, super.getSeleniumInstance());
		basic.waitForBothElementsPresent(Locators.BANNER_SEARCH_LOADING_NEWS_HIDDEN, Locators.BANNER_SEARCH_LOADING_RESEARCH_HIDDEN, super.getSeleniumInstance());
		basic.waitForElementPresent(FullTextSearchLocators.FTS_TAG_CLEAR_HIDDEN, super.getSeleniumInstance());
	}
}
