package com.markit.markithub.test.steps.addprovider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.markit.markithub.test.Data.AddProviderLocators;
import com.markit.markithub.test.model.StepBase;
import com.thoughtworks.selenium.SeleniumException;

public class ClickSubmitAlert extends StepBase{

	private static final long serialVersionUID = 1L;
	private static final Logger logger = LoggerFactory.getLogger(ClickSubmitAlert.class);
	public static final String name = "Click Submit, Expecting an alert.";

	public ClickSubmitAlert() {
		super(name);
	}

	public void execute() throws Exception{
		try{
		basic.pressButtonSlow(AddProviderLocators.ADDPROVIDER_SUBMIT , super.getSeleniumInstance());
		throw new Exception("There was no alert/error.");
		}catch(SeleniumException se){
			logger.info("Squashed Selenium Exception: ",se);
		}
	}
}
