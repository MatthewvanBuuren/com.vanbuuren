package com.markit.markithub.test.steps.FullTextSearch;

import com.markit.markithub.test.Data.FullTextSearchLocators;
import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.Data.PerProviderInfo;
import com.markit.markithub.test.model.StepBase;

public class FilterBySourceDb extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Filter by Source " + PerProviderInfo.CS.fullName;

	public FilterBySourceDb(){
		super(name);
	}

	public void execute() throws Exception{
		basic.pressButton(FullTextSearchLocators.FILTERBY_CONTENTSOURCE_CS, super.getSeleniumInstance());
		basic.waitForBothElementsPresent(Locators.BANNER_SEARCH_LOADING_NEWS_HIDDEN,Locators.BANNER_SEARCH_LOADING_RESEARCH_HIDDEN,super.getSeleniumInstance());
	}
}
