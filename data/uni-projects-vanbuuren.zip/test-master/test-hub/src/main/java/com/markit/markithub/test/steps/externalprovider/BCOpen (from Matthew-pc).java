package com.markit.markithub.test.steps.externalprovider;

import com.markit.markithub.test.Data.ExternalProviderLocator;
import com.markit.markithub.test.model.StepBase;

public class BCOpen extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Open page";

	public BCOpen() {
		super(name);
	}

	@Override
	public void primer() throws Exception{
		super.getSeleniumInstance().windowFocus();
		super.getSeleniumInstance().windowMaximize();
		super.getSeleniumInstance().open(ExternalProviderLocator.BC_URL);
	}

	public void execute() throws Exception{
		basic.waitForElementPresent(ExternalProviderLocator.BC_LOGIN_LOAD, super.getSeleniumInstance());
	}
}
