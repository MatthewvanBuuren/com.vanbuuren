package com.markit.markithub.test.Data;

/**
 * For convenience of not having to hard-code selenium locators everywhere
 * XPath etc.
 */
public class ExternalProviderLocator {

	//Bank of America
	public static final String BAM_URL = "https://bofacapital.bankofamerica.com/Home.jsp";
	public static final String BAM_LOGIN_LOAD = "link=exact:Forgot your user id?";
	public static final String BAM_LOGIN_USERNAME = "//input[@name='userid']";
	public static final String BAM_LOGIN_PASSWORD = "//input[@name='password']";
	public static final String BAM_LOGIN_SUBMIT = "cip-button-id-0";
	public static final String BAM_HOMEPAGE_LOAD = "//div/li/a[contains(text(),'Trading & Tools')]";

	//BNP Paribas
	public static final String BNP_URL = "https://globalmarkets.bnpparibas.com/";
	public static final String BNP_LOGIN_LOAD = "Submit";
	public static final String BNP_LOGIN_USERNAME = "USER";
	public static final String BNP_LOGIN_PASSWORD = "PASSWORD";
	public static final String BNP_LOGIN_BHID_BUTTON = "//input[@id='BONDHUBID']";
	public static final String BNP_LOGIN_SUBMIT = "Submit";
	public static final String BNP_HOMEPAGE_LOAD = "//a[@class='footer-link']";

	//Citi Group
	public static final String C_URL = "https://fidirect.citigroup.com/";
	public static final String C_LOGIN_LOAD = "//input[@type='image']";
	public static final String C_LOGIN_USERNAME = "userid";
	public static final String C_LOGIN_PASSWORD = "password";
	public static final String C_LOGIN_SUBMIT = "//input[@type='image']";
	public static final String C_HOMEPAGE_LOAD = "link=Click here";

	//Credit Suisse
	public static final String CS_URL = "http://research-and-analytics.csfb.com/";
	public static final String CS_LOGIN_LOAD = "//input[@value='Submit']";
	public static final String CS_LOGIN_USERNAME = "username";
	public static final String CS_LOGIN_PASSWORD = "password";
	public static final String CS_LOGIN_SUBMIT = "//input[@value='Submit']";
	public static final String CS_HOMEPAGE_LOAD = "link=More";

	// Deutsche Bank
	public static final String DB_HOMEPAGE_LOAD = "//div[contains(@style,'display: none') and contains(@class,'loadingPanel')]/div[text()='Loading Headlines']";

	//Goldman Sachs
	public static final String GS_URL = "https://portal.gs.com/gs/portal";
	public static final String GS_LOGIN_LOAD = "submit";
	public static final String GS_LOGIN_USERNAME = "username";
	public static final String GS_LOGIN_PASSWORD = "password";
	public static final String GS_LOGIN_SUBMIT = "submit";
	public static final String GS_HOMEPAGE_LOAD = "//div[@class='legacy']/a[1]/span";

	//J.P. Morgan
	public static final String JPM_URL = "http://www.morganmarkets.com/";
	public static final String JPM_LOGIN_LOAD = "//button[@type='submit']";
	public static final String JPM_LOGIN_USERNAME = "userName";
	public static final String JPM_LOGIN_PASSWORD = "password";
	public static final String JPM_LOGIN_SUBMIT = "//button[@type='submit']";
	public static final String JPM_HOMEPAGE_LOAD = "showHideDetail";

	//Barclays Capital
	public static final String BC_URL = "https://live.barcap.com/";
	public static final String BC_LOGIN_LOAD = "//input[@name='']";
	public static final String BC_LOGIN_USERNAME = "user";
	public static final String BC_LOGIN_PASSWORD = "password";
	public static final String BC_LOGIN_SUBMIT = "//input[@name='']";
	public static final String BC_HOMEPAGE_LOAD = "link=Next";

	//Morgan Stanley
	public static final String MS_URL = "https://secure.ms.com/";
	public static final String MS_LOGIN_LOAD = "//img[@alt='Enter']";
	public static final String MS_LOGIN_USERNAME = "login";
	public static final String MS_LOGIN_PASSWORD = "passwd";
	public static final String MS_LOGIN_SUBMIT = "//img[@alt='Enter']";
	public static final String MS_HOMEPAGE_LOAD = "link=Tools";

	//Royal Bank of Canada
	public static final String RBC_URL = "https://www.rbcinsight.com/";
	public static final String RBC_LOGIN_LOAD = "//div[contains(@id,'login-button')]";
	public static final String RBC_LOGIN_USERNAME = "user_id";
	public static final String RBC_LOGIN_PASSWORD = "user_password";
	public static final String RBC_LOGIN_SUBMIT = "//div[contains(@id,'login-button')]/a";
	public static final String RBC_HOMEPAGE_LOAD = "//div[contains(@id,'regions_0')]";

	//UBS
	public static final String UBS_URL = "http://clientportal.ibb.ubs.com/portal/index.jsp?page=fihome";
	public static final String UBS_LOGIN_LOAD = "//input[@value='Login']";
	public static final String UBS_LOGIN_USERNAME = "username";
	public static final String UBS_LOGIN_PASSWORD = "password";
	public static final String UBS_LOGIN_SUBMIT = "//input[@value='Login']";
	public static final String UBS_HOMEPAGE_LOAD = "//a[contains(text(),'Market Commentary')]";

	// Dow Jones
	public static final String DJ_HOMEPAGE_LOAD = "//div[contains(text(),'TOP STORIES')]";

	//Markit
	public static final String MKT_URL = "https://www.markit.com/en/";
	public static final String MKT_LOGIN_LOAD = "//form[@id='pricingloginid']/table/tbody/tr[9]/td[2]/table/tbody/tr/td[2]/a/img";
	public static final String MKT_LOGIN_USERNAME = "username";
	public static final String MKT_LOGIN_PASSWORD = "password";
	public static final String MKT_LOGIN_SELECT_NAME = "label=Markit Structured Finance";
	public static final String MKT_LOGIN_SELECT_BOX = "//select[@id='cbService']";
	public static final String MKT_LOGIN_SUBMIT = "//form[@id='pricingloginid']/table/tbody/tr[9]/td[2]/table/tbody/tr/td[2]/a/img";
	public static final String MKT_HOMEPAGE_LOAD = "//img[@src='images/welcome.png']";
	public static final String MKT_STRUCTUREDFINANCE_LOAD = "//tr[2]/td[1]/div[contains(@class,'gwt-Label clickable')]";
	public static final String MKT_HOMEPAGE_HOME = "//div[contains(@class,'gwt-TabBarItem')]/div[contains(text(),'UK')]";
}
