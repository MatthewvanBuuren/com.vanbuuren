package com.markit.markithub.test.steps.FullTextSearch;

import com.markit.markithub.test.Data.FullTextSearchLocators;
import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.model.StepBase;

public class JapanClick extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Search '" +FullTextSearchLocators.FTS_SEARCH_TERM4_JAPAN+ "' by Clicking Search";

	public JapanClick(){
		super(name);
	}

	public void execute() throws Exception{
		basic.typeString(Locators.BANNER_SEARCH_INPUT, FullTextSearchLocators.FTS_SEARCH_TERM4_JAPAN, super.getSeleniumInstance());
		basic.pressButtonSlow(Locators.BANNER_SEARCH_BUTTON, super.getSeleniumInstance());
		basic.waitForBothElementsPresent(Locators.BANNER_SEARCH_LOADING_RESEARCH_HIDDEN, Locators.BANNER_SEARCH_LOADING_NEWS_HIDDEN, super.getSeleniumInstance());
		basic.waitForElementPresent(FullTextSearchLocators.FTS_SEARCH_TERM4_JAPAN_RESULT,super.getSeleniumInstance());
	}
}
