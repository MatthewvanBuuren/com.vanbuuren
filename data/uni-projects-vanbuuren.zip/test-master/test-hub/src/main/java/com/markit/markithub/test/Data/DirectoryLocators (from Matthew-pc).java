package com.markit.markithub.test.Data;

/**
 * For convenience of not having to hard-code selenium locators everywhere
 * XPath etc.
 */
public class DirectoryLocators {

	// Directory
	public static final String DIRECTORY_SEARCH_NAME = "Joel Gamzon";
	public static final String DIRECTORY_SEARCH_RESULT_NAME = "//div/b[text()='" + DIRECTORY_SEARCH_NAME.substring(DIRECTORY_SEARCH_NAME.lastIndexOf(" ")+1, DIRECTORY_SEARCH_NAME.length()) + "']";
	public static final String DIRECTORY_SEARCH_COMPANY = "Markit Hub";
	public static final String DIRECTORY_SEARCH_RESULT_COMPANY = "//div/b[contains(text(),'Markit')]";
	public static final String DIRECTORY_SEARCH_J = "J";
	public static final String DIRECTORY_SEARCH_RESULT_J = "//div/b[contains(text(),'" + DIRECTORY_SEARCH_J + "')]";
	public static final String DIRECTORY_SEARCH_GOLDMAN = "Goldman";
	public static final String DIRECTORY_SEARCH_RESULT_GOLDMAN = "//div/b[contains(text(),'" + DIRECTORY_SEARCH_GOLDMAN + "')]";
	public static final String DIRECTORY_SEARCH_EMAIL = "mario.orphanou@markit.com";
	public static final String DIRECTORY_SEARCH_RESULT_EMAIL = "//a[contains(@href,'mailto:" + DIRECTORY_SEARCH_EMAIL + "')]";
	public static final String DIRECTORY_SEARCH_FIRSTNAME = DIRECTORY_SEARCH_NAME.substring(0, DIRECTORY_SEARCH_NAME.indexOf(" "));
	public static final String DIRECTORY_SEARCH_LASTNAME = DIRECTORY_SEARCH_NAME.substring(DIRECTORY_SEARCH_NAME.indexOf(" ")+1,DIRECTORY_SEARCH_NAME.length());

	public static final String DIRECTORY_SEARCH_INPUT = "//input[contains(@class,'simpleSearchInput')]";
	public static final String DIRECTORY_SEARCH_BUTTON = "//div[contains(@class,'go_button')]";
	public static final String DIRECTORY_RESULT_CELL = "css=td.dataCell";
	public static final String DIRECTORY_SEARCH_RESULTS_ROWS = "//table[@class = 'UserListContentPanel']/tbody/tr";
	public static final String DIRECTORY_JOEL_EMAIL = "//a[@href='mailto:joel.gamzon@markit.com']";
	public static final String DIRECTORY_ADVANCED_SEARCH = "//a[contains(text(),'Advanced Search')]";
	public static final String DIRECTORY_ADVANCED_SEARCH_CONTACT_LIST = "//div[text()='Contact List']";
	public static final String DIRECTORY_FIRST_NAME = "//tr[position()=2]/td/input";
	public static final String DIRECTORY_LAST_NAME = "//tr[position()=4]/td/input";
	public static final String DIRECTORY_COMPANY = "//tr[position()=6]/td/input";
	public static final String DIRECTORY_EMAIL = "//tr[position()=8]/td/input";
	public static final String DIRECTORY_CONNEX_BLOCKED = "//div[text()='Blocked']";
	public static final String DIRECTORY_CONNEX_CONTACTLIST = "//div[text()='Contact List']";
	public static final String DIRECTORY_CONNEX_HELP = "//div[text()='Help']";
	public static final String DIRECTORY_CONNEX_TEST = "//div[text()='test']";

}
