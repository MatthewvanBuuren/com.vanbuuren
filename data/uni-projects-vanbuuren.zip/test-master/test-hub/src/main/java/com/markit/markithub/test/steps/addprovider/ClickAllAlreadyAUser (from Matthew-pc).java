package com.markit.markithub.test.steps.addprovider;

import com.markit.markithub.test.Data.SubProvider;
import com.markit.markithub.test.model.StepBase;

public class ClickAllAlreadyAUser extends StepBase{

	private static final long serialVersionUID = 1L;
	public static final String name = "Click all 'Already a User' Checkbox's";

	public ClickAllAlreadyAUser() {
		super(name);
	}

	public void execute() throws Exception{
		for(SubProvider sub : SubProvider.getAll()){
			int NoOfProviderInvites = getInviteProviderCount(sub);
			if(NoOfProviderInvites > 0){
				int diff = 0;
				for(int x = 2; x < (NoOfProviderInvites+2) ; x ++){
					basic.pressButtonSlow(sub.getAlreadyAProviderCheckBoxWithPanel(x+diff),super.getSeleniumInstance());
					basic.assertElementPresent(sub.getInviteProviderSalesPerson(x+1+diff), super.getSeleniumInstance());
					diff++;
				}
			}
		}
	}

	private int getInviteProviderCount(SubProvider sub){
		int x = -1;
		for(x = 2 ; x < 100 ; x++){
			if(!super.getSeleniumInstance().isElementPresent(sub.getInviteProviderCheckBoxWithPanel(x))){
				if(!super.getSeleniumInstance().isElementPresent(sub.getInviteProviderCheckBoxWithPanel(x+1))){
					break;
				}
			}
		}
		if(x < 99){
		return x-2;
		} else {
			return -1;
		}
	}
}
