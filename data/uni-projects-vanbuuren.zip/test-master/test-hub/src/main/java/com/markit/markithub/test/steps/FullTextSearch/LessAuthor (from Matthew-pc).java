package com.markit.markithub.test.steps.FullTextSearch;

import com.markit.markithub.test.Data.FullTextSearchLocators;
import com.markit.markithub.test.model.StepBase;

public class LessAuthor extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Click 'FilterBy', 'Author', 'Less'";

	public LessAuthor(){
		super(name);
	}

	public void execute() throws Exception{
		basic.pressButton(FullTextSearchLocators.FILTERBY_AUTHOR_LESS, super.getSeleniumInstance());
		basic.waitForElementPresent(FullTextSearchLocators.FILTERBY_AUTHOR_MORE,super.getSeleniumInstance());
	}
}
