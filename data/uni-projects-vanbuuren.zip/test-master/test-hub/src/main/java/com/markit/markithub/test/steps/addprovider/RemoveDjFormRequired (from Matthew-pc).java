package com.markit.markithub.test.steps.addprovider;

import com.markit.markithub.test.Data.AddProviderLocators;
import com.markit.markithub.test.model.StepBase;

public class RemoveDjFormRequired extends StepBase{

	private static final long serialVersionUID = 1L;
	public static final String name = "Remove First,Last,Email and Phone elements.";

	public RemoveDjFormRequired() {
		super(name);
	}

	public void execute() throws Exception{
		basic.typeString(AddProviderLocators.DJ_FIRSTNAME, " ",super.getSeleniumInstance());
		basic.typeString(AddProviderLocators.DJ_LASTNAME, " ", super.getSeleniumInstance());
		basic.typeString(AddProviderLocators.DJ_PHONE, " ", super.getSeleniumInstance());
		basic.typeString(AddProviderLocators.DJ_EMAIL, " ", super.getSeleniumInstance());
	}
}
