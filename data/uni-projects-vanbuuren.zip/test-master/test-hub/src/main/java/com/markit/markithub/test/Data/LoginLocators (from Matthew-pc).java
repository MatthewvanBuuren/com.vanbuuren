package com.markit.markithub.test.Data;

public class LoginLocators {

	public static String LOGIN_FAIL_MESSAGE = "//div[contains(text(),'You have entered an invalid login id or password.')]";
}
