package com.markit.markithub.test.steps.externalprovider;

import com.markit.markithub.test.Data.ExternalProviderLocator;
import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.Data.PerProviderInfo;
import com.markit.markithub.test.model.StepBase;

public class GSLogin extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Login to "+PerProviderInfo.GS.fullName;

	public GSLogin() {
		super(name);
	}

	public void execute() throws Exception{
		basic.typeString(ExternalProviderLocator.GS_LOGIN_USERNAME,super.getStorySettings().getUsername(),super.getSeleniumInstance());
		basic.typeString(ExternalProviderLocator.GS_LOGIN_PASSWORD,super.getStorySettings().getPassword(),super.getSeleniumInstance());
		basic.pressButton(ExternalProviderLocator.GS_LOGIN_SUBMIT,super.getSeleniumInstance());
		basic.waitForElementPresent(Locators.BANNER_HEADLINES_BUTTON, super.getSeleniumInstance());
		basic.waitForElementPresent(ExternalProviderLocator.GS_HOMEPAGE_LOAD, super.getSeleniumInstance());
	}
}
