package com.markit.markithub.test.Data;

import java.util.ArrayList;
import java.util.List;

public class SubProvider {

	private static final List<SubProvider> allSubs = new ArrayList<SubProvider>();

	public String name;
	public String position;
	public String main_arrow;
	public String hidden_table;

	public SubProvider(String name, String position, String main_arrow, String hidden_table){
		this.name = name;
		this.position = position;
		this.main_arrow = main_arrow;
		this.hidden_table = hidden_table;
	}

	public static final SubProvider BANKS = new SubProvider(
			"Banks",
			"2",
			"//tr[1]/td/div[contains(text(),'Banks')]",
			"//tr[position()=2 and contains(@style,'display: none')]"
			);
	public static final SubProvider RESEARCH = new SubProvider(
			"Research",
			"4",
			"//tr[3]/td/div[contains(text(),'Research')]",
			"//tr[position()=4 and contains(@style,'display: none')]"
			);
	public static final SubProvider MARKET = new SubProvider(
			"Market",
			"6",
			"//tr[5]/td/div[contains(text(),'Market')]",
			"//tr[position()=6 and contains(@style,'display: none')]"
			);
	public static final SubProvider NEWS = new SubProvider(
			"News",
			"8",
			"//tr[7]/td/div[contains(text(),'News')]",
			"//tr[position()=8 and contains(@style,'display: none')]"
			);
	public static final SubProvider MULTIPRODUCT = new SubProvider(
			"Multi-Product",
			"10",
			"//tr[9]/td/div[contains(text(),'Multi-Product')]",
			"//tr[position()=10 and contains(@style,'display: none')]"
			);


	public String  getInviteProviderCheckBoxWithPanel(int listNo){
		return "//tr[position()="+ position +"]/td/div/table/tbody/tr[" + listNo + "]/td[2]/div/input";
	}

	public String  getInviteProviderCheckBoxWithPanelTrue(int listNo){
		return "//tr[position()="+ position +"]/td/div/table/tbody/tr[" + listNo + "]/td[2]/div[@aria-pressed='true']";
	}

	public String  getAlreadyAProviderCheckBoxWithPanel(int listNo){
		return "//tr[position()="+ position +"]/td/div/table/tbody/tr[" + listNo + "]/td[3]/div/input";
	}

	public String getInviteProviderSalesPerson(int listNo){
		return "//tr[position()="+ position +"]/td/div/table/tbody/tr[" + listNo + "]/td/table/tbody/tr[1]/td[2]/input";
	}

	public String getInviteProviderContactEmail(int listNo){
		return "//tr[position()="+ position +"]/td/div/table/tbody/tr[" + listNo + "]/td/table/tbody/tr[2]/td[2]/input";
	}

	public static List<SubProvider> getAll() {
		allSubs.add(BANKS);
		allSubs.add(RESEARCH);
		allSubs.add(MARKET);
		allSubs.add(NEWS);
		allSubs.add(MULTIPRODUCT);
		return allSubs;
	}
}
