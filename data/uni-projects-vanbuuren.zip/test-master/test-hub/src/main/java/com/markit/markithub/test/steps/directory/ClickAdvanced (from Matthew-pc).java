package com.markit.markithub.test.steps.directory;

import com.markit.markithub.test.Data.DirectoryLocators;
import com.markit.markithub.test.model.StepBase;

public class ClickAdvanced extends StepBase{

	private static final long serialVersionUID = 1L;
	public static final String name = "Click 'Advanced Search'";

	public ClickAdvanced(){
		super(name);
	}

	public void execute() throws Exception{
		basic.pressButton(DirectoryLocators.DIRECTORY_ADVANCED_SEARCH,super.getSeleniumInstance());
		basic.waitForElementPresent(DirectoryLocators.DIRECTORY_ADVANCED_SEARCH_CONTACT_LIST, super.getSeleniumInstance());
	}
}
