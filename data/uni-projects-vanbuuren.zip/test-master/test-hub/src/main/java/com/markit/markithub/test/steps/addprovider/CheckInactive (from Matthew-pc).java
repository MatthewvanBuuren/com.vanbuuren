package com.markit.markithub.test.steps.addprovider;

import com.markit.markithub.test.Data.AddProviderLocators;
import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.model.StepBase;

public class CheckInactive extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Assert all Inactive are present";

	public CheckInactive() {
		super(name);
	}

	public void execute() throws Exception{
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_BAM_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_BAM)){
			basic.assertElementPresent(AddProviderLocators.ADDPROVIDER_AVAILABLE_BAM, super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_BC_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_BC)){
			basic.assertElementPresent(AddProviderLocators.ADDPROVIDER_AVAILABLE_BC, super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_BNP_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_BNP)){
			basic.assertElementPresent(AddProviderLocators.ADDPROVIDER_AVAILABLE_BNP, super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_C_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_C)){
			basic.assertElementPresent(AddProviderLocators.ADDPROVIDER_AVAILABLE_C, super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_CS_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_CS)){
			basic.assertElementPresent(AddProviderLocators.ADDPROVIDER_AVAILABLE_CS, super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_DB_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_DB)){
			basic.assertElementPresent(AddProviderLocators.ADDPROVIDER_AVAILABLE_DB, super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_GS_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_GS)){
			basic.assertElementPresent(AddProviderLocators.ADDPROVIDER_AVAILABLE_GS, super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_JPM_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_JPM)){
			basic.assertElementPresent(AddProviderLocators.ADDPROVIDER_AVAILABLE_JPM, super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_MS_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_MS)){
			basic.assertElementPresent(AddProviderLocators.ADDPROVIDER_AVAILABLE_MS, super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_RBC_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_MS)){
			basic.assertElementPresent(AddProviderLocators.ADDPROVIDER_AVAILABLE_RBC, super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_UBS_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_UBS)){
			basic.assertElementPresent(AddProviderLocators.ADDPROVIDER_AVAILABLE_UBS, super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_MKT_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_MKT)){
			basic.assertElementPresent(AddProviderLocators.ADDPROVIDER_AVAILABLE_MKT, super.getSeleniumInstance());
		}
		basic.assertElementPresent(AddProviderLocators.ADDPROVIDER_AVAILABLE_DJ, super.getSeleniumInstance());
	}
}
