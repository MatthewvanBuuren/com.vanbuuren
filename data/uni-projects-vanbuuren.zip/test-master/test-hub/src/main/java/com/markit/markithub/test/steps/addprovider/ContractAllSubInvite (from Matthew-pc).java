package com.markit.markithub.test.steps.addprovider;

import com.markit.markithub.test.Data.SubProvider;
import com.markit.markithub.test.model.StepBase;

public class ContractAllSubInvite extends StepBase{

	private static final long serialVersionUID = 1L;
	public static final String name = "Expand all Sub-Invite Boxes";

	public ContractAllSubInvite() {
		super(name);
	}

	public void execute() throws Exception{
		if(!super.getSeleniumInstance().isElementPresent(SubProvider.BANKS.hidden_table)){
			basic.pressButton(SubProvider.BANKS.main_arrow, super.getSeleniumInstance());
		}
		if(!super.getSeleniumInstance().isElementPresent(SubProvider.RESEARCH.hidden_table)){
			basic.pressButton(SubProvider.RESEARCH.main_arrow, super.getSeleniumInstance());
		}
		if(!super.getSeleniumInstance().isElementPresent(SubProvider.MARKET.hidden_table)){
			basic.pressButton(SubProvider.MARKET.main_arrow, super.getSeleniumInstance());
		}
		if(!super.getSeleniumInstance().isElementPresent(SubProvider.NEWS.hidden_table)){
			basic.pressButton(SubProvider.NEWS.main_arrow, super.getSeleniumInstance());
		}
		if(!super.getSeleniumInstance().isElementPresent(SubProvider.MULTIPRODUCT.hidden_table)){
			basic.pressButton(SubProvider.MULTIPRODUCT.main_arrow, super.getSeleniumInstance());
		}
		basic.assertElementPresent(SubProvider.BANKS.hidden_table, super.getSeleniumInstance());
		basic.assertElementPresent(SubProvider.RESEARCH.hidden_table, super.getSeleniumInstance());
		basic.assertElementPresent(SubProvider.MARKET.hidden_table, super.getSeleniumInstance());
		basic.assertElementPresent(SubProvider.NEWS.hidden_table, super.getSeleniumInstance());
		basic.assertElementPresent(SubProvider.MULTIPRODUCT.hidden_table, super.getSeleniumInstance());
	}
}
