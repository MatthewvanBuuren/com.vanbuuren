package com.markit.markithub.test.Data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.markit.markithub.test.model.ContentType;
import com.markit.markithub.test.model.SpecialContentType;

public class PerProviderInfo {

	public static final List<PerProviderInfo> allProviders = new ArrayList<PerProviderInfo>();

	public final String fullName;
	public final String abrv;
	public final String host;
	public final Map<ContentType, List<String>> headlinePayloads;
	public final SpecialContentType specialcontenttype;

	public PerProviderInfo(String fullName, String abrv, String host, Map<ContentType, List<String>> headlinePayloads, SpecialContentType specialcontenttype){
		this.fullName = fullName;
		this.abrv = abrv;
		this.host = host;
		this.headlinePayloads = headlinePayloads;
		this.specialcontenttype = specialcontenttype;
	}

	public static final PerProviderInfo BAM = new PerProviderInfo(
			"BofA Merrill Lynch",
			"BAM",
			"ml.com",
			createSinglePdfMap(),
			SpecialContentType.NOT_SPECIFIED
			);

	public static final PerProviderInfo BC = new PerProviderInfo(
			"Barclays Capital",
			"BC",
			"barcap.com",
			createDoublePdfJvs(""),
			SpecialContentType.PDF
			);
	public static final PerProviderInfo BNP = new PerProviderInfo(
			"BNP Paribas",
			"BNP",
			"bnpparibas.com",
			createDoublePdfGifMap("banner-bg","dcs"),
			SpecialContentType.NOT_SPECIFIED
			);
	public static final PerProviderInfo C = new PerProviderInfo(
			"Citi",
			"C",
			"citigroup.com",
			createDoublePdfGifMap("homeicon"),
			SpecialContentType.NOT_SPECIFIED
			);
	public static final PerProviderInfo CS = new PerProviderInfo(
			"Credit Suisse",
			"CS",
			"csfb.com",
			createSinglePdfMap(),
			SpecialContentType.NOT_SPECIFIED
			);
	public static final PerProviderInfo DB = new PerProviderInfo(
			"Deutsche Bank",
			"DB",
			"hub.com",
			createSinglePdfMap(),
			SpecialContentType.NOT_SPECIFIED
			);
	public static final PerProviderInfo GS = new PerProviderInfo(
			"Goldman Sachs",
			"GS",
			"gs.com",
			createGoldmanSachsMap(),
			SpecialContentType.NOT_SPECIFIED
			);
	public static final PerProviderInfo JPM = new PerProviderInfo(
			"J.P.Morgan",
			"JPM",
			"jpmorgan.com",
			createSinglePdfMap(),
			SpecialContentType.NOT_SPECIFIED
			);
	public static final PerProviderInfo MS = new PerProviderInfo(
			"Morgan Stanley",
			"MS",
			"secure.ms.com",
			createSinglePdfMap(),
			SpecialContentType.NOT_SPECIFIED
			);
	public static final PerProviderInfo RBC = new PerProviderInfo(
			"Royal Bank Of Canada",
			"RBC",
			"www.rbcinsight.com",
			createSinglePdfMap(),
			SpecialContentType.NOT_SPECIFIED
			);
	public static final PerProviderInfo UBS = new PerProviderInfo(
			"UBS",
			"UBS",
			"ubs.com",
			createDoublePdfGifMap("icon_console_email"),
			SpecialContentType.NOT_SPECIFIED
			);
	public static final PerProviderInfo DJ = new PerProviderInfo(
			"Dow Jones",
			"DJ",
			"hub.com",
			createDoublePdfGifMap("dj_logo"),
			SpecialContentType.NOT_SPECIFIED
			);
	public static final PerProviderInfo MKT = new PerProviderInfo(
			"Markit",
			"MKT",
			"markit.com",
			createSinglePdfMap(),
			SpecialContentType.NOT_SPECIFIED
			);


	public static Map<ContentType, List<String>> createSinglePdfMap() {
		Map<ContentType, List<String>> map = new HashMap<ContentType, List<String>>();
		List<String> emptyList = new ArrayList<String>();
		map.put(ContentType.PDF, emptyList);
		return map;
	}

	public static Map<ContentType, List<String>> createDoublePdfGifMap(String filename){
		Map<ContentType, List<String>> map = new HashMap<ContentType, List<String>>();
		List<String> emptyList = new ArrayList<String>();
		List<String> allFiles = new ArrayList<String>();
		allFiles.add(filename);
		map.put(ContentType.PDF, emptyList);
		map.put(ContentType.GIF, allFiles);
		return map;
	}

	public static Map<ContentType, List<String>> createDoublePdfGifMap(String filename,String filename2,String filename3){
		Map<ContentType, List<String>> map = new HashMap<ContentType, List<String>>();
		List<String> emptyList = new ArrayList<String>();
		List<String> allFiles = new ArrayList<String>();
		allFiles.add(filename);
		allFiles.add(filename2);
		allFiles.add(filename3);
		map.put(ContentType.PDF, emptyList);
		map.put(ContentType.GIF, allFiles);
		return map;
	}

	public static Map<ContentType, List<String>> createDoublePdfGifMap(String filename,String filename2){
		Map<ContentType, List<String>> map = new HashMap<ContentType, List<String>>();
		List<String> emptyList = new ArrayList<String>();
		List<String> allFiles = new ArrayList<String>();
		allFiles.add(filename);
		allFiles.add(filename2);
		map.put(ContentType.PDF, emptyList);
		map.put(ContentType.GIF, allFiles);
		return map;
	}

	public static Map<ContentType, List<String>>  createDoublePdfJvs(String filename){
		Map<ContentType, List<String>> map = new HashMap<ContentType, List<String>>();
		List<String> emptyList = new ArrayList<String>();
		List<String> allFiles = new ArrayList<String>();
		map.put(ContentType.PDF, emptyList);
		map.put(ContentType.JVS, allFiles);
		return map;
	}

	public static Map<ContentType, List<String>> createGoldmanSachsMap(){
		Map<ContentType, List<String>> map = new HashMap<ContentType, List<String>>();
		List<String> emptyList = new ArrayList<String>();
		List<String> allFiles = new ArrayList<String>();
		allFiles.add("close");
		allFiles.add("banner-bg");
		allFiles.add("btn");
		allFiles.add("blue_dup_13x13");
		allFiles.add("arrow_off_15x15");
		allFiles.add("arrow_on_15x15");
		allFiles.add("document");
		allFiles.add("gs360_prod");
		allFiles.add("checkbox_on_12x12");
		allFiles.add("perforation");
		allFiles.add("ms_dot");
		map.put(ContentType.PDF, emptyList);
		map.put(ContentType.GIF, allFiles);
		return map;
	}

	public static List<PerProviderInfo> allProviders(){
		allProviders.add(BAM);
		allProviders.add(BC);
		allProviders.add(BNP);
		allProviders.add(C);
		allProviders.add(CS);
		allProviders.add(DB);
		allProviders.add(GS);
		allProviders.add(JPM);
		allProviders.add(MS);
		allProviders.add(RBC);
		allProviders.add(UBS);
		allProviders.add(DJ);
		allProviders.add(MKT);
		return allProviders;

	}
}
