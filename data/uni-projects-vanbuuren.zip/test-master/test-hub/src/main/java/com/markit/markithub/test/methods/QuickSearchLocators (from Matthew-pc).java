package com.markit.markithub.test.methods;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.thoughtworks.selenium.Selenium;

public class QuickSearchLocators {

	private static final Logger logger = LoggerFactory.getLogger(QuickSearchLocators.class);
	private Selenium selenium;

	private static Map<String,Integer> allGroups = new HashMap<String,Integer>();
	private static String[][] grid;


	public QuickSearchLocators(Selenium selenium){
		this.selenium = selenium;
		int largestValue = 0;
		largestValue = selenium.getXpathCount("//div[contains(@class,'shTagBox')]/div").intValue();
		for(int x = 1 ; x <= selenium.getXpathCount("//div[@class='shHeadlineGroup']").intValue() ; x++){
			int count = selenium.getXpathCount("//div[@class='shHeadlineGroup' and position()=" + x + "]/div").intValue()-1;
			if(count > largestValue){
				largestValue = count;
			}
		}
		grid = new String[selenium.getXpathCount("//div[@class='shHeadlineGroup']").intValue()+1][largestValue+1];
		allGroups.put("Companies", 0);
		addLocators();
	}

	private void addLocators(){
		try{
			//shCompanies only Companies
			for(int y = 2 ; y <= selenium.getXpathCount("//div[contains(@class,'shTagBox')]/div").intValue() ; y++){
				grid[0][y-1] = "//div[@class='shTagBox' and position()="+y+"]/div";
			}
			//shHeadlines i.e Research,News,etc
			for(int x = 1 ; x <= selenium.getXpathCount("//div[contains(@class,'shHeadlineGroup')]").intValue() ; x++){
				for(int y = 2 ; y <= selenium.getXpathCount("//div[contains(@class,'shHeadlineGroup') and position()=" + x + "]/div").intValue() ; y++){
					grid[x][y-1] = "//div[contains(@class,'shHeadlineGroup') and position()=" + x + "]/div[position()=" + y + "]/div[contains(@class,'shHeadline')]";
				}
				allGroups.put(selenium.getText("//div[contains(@class,'shHeadlineGroup') and position()=" + x + "]/div/div[contains(@class,'shTitle')]"),x);
			}
		}catch(Exception w){
			logger.error("Error loading quickSearchElements");
		}
	}

	/**
	 * Returns the locator of the Quick search element or a faulty locator if that headline doesnt exist.
	 * @param group - String - The Filter by Group i.e Research/Strategy,News
	 * @param elem - Integer - The headline for that group
	 * @return The locator of that headline.
	 */
	public String getHeadline(String group,int elem){
		String headline ="";
		try{
			headline = grid[allGroups.get(group)][elem];
		}catch(Exception e){
			logger.error("Group/Element number out of bounds",e);
			headline = "Group/Element number out of bounds";
		}
		return headline;
	}

}
