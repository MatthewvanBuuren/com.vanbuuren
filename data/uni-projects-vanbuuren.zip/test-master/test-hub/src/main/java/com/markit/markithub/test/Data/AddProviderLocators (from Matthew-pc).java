package com.markit.markithub.test.Data;

public class AddProviderLocators {

	public static final String ADDPROVIDER_MAIN_LOAD = "//div[contains(@class,'SubmitButton')]";
	public static final String ADDPROVIDER_SUBMIT = "//div[contains(@class,'SubmitButton')]";

	public static final String SUGGEST_OTHER_PROVIDER = "//a[contains(text(),'Suggest another')]";
	public static final String SUGGEST_OTHER_COUNT = "//div/table[contains(@class,'formContainer')]/tbody/tr";

	public static String SUGGEST_OTHER_PROVIDER(int listNo){
		return "//div/table[contains(@class,'formContainer')]/tbody/tr[position()=" + listNo + "]/td[1]/input";
	}
	public static String SUGGEST_OTHER_URL(int listNo){
		return "//div/table[contains(@class,'formContainer')]/tbody/tr[position()=" + listNo + "]/td[2]/input";
	}

	public static final String ADDPROVIDER_AVAILABLE_DJ = "//div/div/span/label[text()='" + PerProviderInfo.DJ.fullName + "']";

	public static final String ADDPROVIDER_AVAILABLE_BAM = "//div/div/span/label[text()='" + PerProviderInfo.BAM.fullName + "']";
	public static final String ADDPROVIDER_AVAILABLE_BC = "//div/div/span/label[text()='" + PerProviderInfo.BC.fullName + "']";
	public static final String ADDPROVIDER_AVAILABLE_BNP = "//div/div/span/label[text()='" + PerProviderInfo.BNP.fullName + "']";
	public static final String ADDPROVIDER_AVAILABLE_C = "//div/div/span/label[text()='" + PerProviderInfo.C.fullName + "']";
	public static final String ADDPROVIDER_AVAILABLE_CS = "//div/div/span/label[text()='" + PerProviderInfo.CS.fullName + "']";
	public static final String ADDPROVIDER_AVAILABLE_DB = "//div/div/span/label[text()='" + PerProviderInfo.DB.fullName + "']";
	public static final String ADDPROVIDER_AVAILABLE_GS = "//div/div/span/label[text()='" + PerProviderInfo.GS.fullName + "']";
	public static final String ADDPROVIDER_AVAILABLE_JPM = "//div/div/span/label[text()='" + PerProviderInfo.JPM.fullName + "']";
	public static final String ADDPROVIDER_AVAILABLE_MS = "//div/div/span/label[text()='" + PerProviderInfo.MS.fullName + "']";
	public static final String ADDPROVIDER_AVAILABLE_RBC = "//div/div/span/label[text()='" + PerProviderInfo.RBC.fullName + "']";
	public static final String ADDPROVIDER_AVAILABLE_UBS = "//div/div/span/label[text()='" + PerProviderInfo.UBS.fullName + "']";
	public static final String ADDPROVIDER_AVAILABLE_MKT = "//div/div/span/label[text()='" + PerProviderInfo.MKT.fullName + "']";

	public static final String DJ_FIRSTNAME = "//input[@name='firstName']";
	public static final String DJ_COMPANY = "//input[@name='companyName']";
	public static final String DJ_EMAIL = "//input[@name='email']";
	public static final String DJ_BUSINESS_AREA = "//select[@name='businessArea']";
	public static final String DJ_BUSINESS_AREA_NAME = "label=Wealth Management";
	public static final String DJ_LASTNAME = "//input[@name='lastName']";
	public static final String DJ_JOB_TITLE = "//input[@name='jobTitle']";
	public static final String DJ_PHONE = "//input[@name='phone']";
	public static final String DJ_COUNTRY = "//select[@name='country']";
	public static final String DJ_COUNTRY_NAME = "label=Netherlands";

	public static final String DJ_BLOOMBERG = "//input[@name='useDjVia' and @value='Bloomberg']";
	public static final String DJ_REUTERS = "//input[@name='useDjVia' and @value='Reuters']";
	public static final String DJ_THOMSON = "//input[@name='useDjVia' and @value='Thomson']";
	public static final String DJ_FACTSET = "//input[@name='useDjVia' and @value='FactSet']";
	public static final String DJ_CAPIQ = "//input[@name='useDjVia' and @value='CapIQ']";
	public static final String DJ_MARKIT_DESKTOP = "//input[@name='useDjVia' and @value='Markit Desktop']";
	public static final String DJ_OTHER = "//input[@name='isUseDjViaOtherSelected']";
	public static final String DJ_OTHER_TEXTBOX = "//input[@name='useDjViaOther']";

	public static final String DJ_SIGNUP = "//input[@name='LikeAccess']";
	public static final String DJ_NOT_INTERESTED = "//input[@name='NotInterested']";
	public static final String DJ_SEND = "//input[@value='Send']";
	public static final String DJ_CANCEL = "//button[@type='button']";
	public static final String DJ_TERMS_OF_USE = "link=Terms Of Use";
	public static final String DJ_TERMSOFUSE_WINDOW = "DowJonesTermsofUse.pdf (application/pdf Object)";

	public static final String DJ_ERROR_RED = "//div[contains(@class,'requiredFieldsError') and text()='* required fields']";
}
