package com.markit.markithub.test.steps.directory;

import com.markit.markithub.test.Data.DirectoryLocators;
import com.markit.markithub.test.model.StepBase;

public class SearchBlank extends StepBase{

	private static final long serialVersionUID = 1L;
	public static final String name = "Blank Search";

	public SearchBlank(){
		super(name);
	}

	public void execute() throws Exception{
		basic.pressButtonSlow(DirectoryLocators.DIRECTORY_SEARCH_BUTTON,super.getSeleniumInstance());
		basic.assertAlert(super.getSeleniumInstance());
	}
}
