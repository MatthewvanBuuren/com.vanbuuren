package com.markit.markithub.test.steps;

import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.methods.QuickSearchLocators;
import com.markit.markithub.test.model.StepBase;

public class TestDevStep extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Click a document/result";


	public TestDevStep(){
		super(name);
	}

	public void execute() throws Exception{
		basic.typeString(Locators.BANNER_SEARCH_INPUT, "Japan", super.getSeleniumInstance());
		basic.waitForElementPresent(Locators.BANNER_QUICKSEARCH_DROPDOWN_LOAD, super.getSeleniumInstance());
		//Must be initialized here because this is where selenium is set.
		QuickSearchLocators quickLocators = new QuickSearchLocators(super.getSeleniumInstance());
		System.out.println(quickLocators.getHeadline("Companies", 1));
		System.out.println(quickLocators.getHeadline("News", 2));
	}
}
