package com.markit.markithub.test.steps;

import com.markit.markithub.test.Data.AddProviderLocators;
import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.model.StepBase;

public class ClickAddProvider extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Click Add Provider";

	public ClickAddProvider(){
		super(name);
	}

	public void execute() throws Exception{
		basic.pressButtonSlow(Locators.BANNER_ADDPROVIDER,super.getSeleniumInstance());
		basic.waitForElementPresent(AddProviderLocators.ADDPROVIDER_MAIN_LOAD, super.getSeleniumInstance());
	}
}
