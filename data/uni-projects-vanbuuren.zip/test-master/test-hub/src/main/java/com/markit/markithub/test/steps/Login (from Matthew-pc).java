package com.markit.markithub.test.steps;

import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.model.StepBase;

public class Login extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Login to Hub";

	public Login() {
		super(name);
	}

	public void execute() throws Exception{
		basic.typeString(Locators.LOGIN_USERNAME,super.getStorySettings().getUsername(),super.getSeleniumInstance());
		basic.typeString(Locators.LOGIN_PASSWORD,super.getStorySettings().getPassword(),super.getSeleniumInstance());
		basic.pressButton(Locators.LOGIN_SUBMIT,super.getSeleniumInstance());
		basic.waitForBothElementsPresent(Locators.BANNER_SEARCH_LOADING_RESEARCH_HIDDEN, Locators.BANNER_SEARCH_LOADING_NEWS_HIDDEN, super.getSeleniumInstance());
	}
}
