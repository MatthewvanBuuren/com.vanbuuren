package com.markit.markithub.test.methods;

import com.markit.markithub.test.Data.PerProviderInfo;

public class CurrentlyAvailableBox {

	public int position;
	public PerProviderInfo provider;

	public CurrentlyAvailableBox(int position,PerProviderInfo provider){
		this.position = position;
		this.provider = provider;
	}

	public String getMainCheckbox(){
		return "//div[contains(@class,'PrimaryProviderPanel')]/div[position()="+position+"]/div/span[contains(@class,'gwt-CheckBox selector')]/input";
	}

	public String getCredit(){
		return "//div[contains(@class,'PrimaryProviderPanel')]/div[position()="+position+"]/div/span[contains(@class,'gwt-CheckBox service') and position()=1]/input";
	}

	public String getEquities(){
		return "//div[contains(@class,'PrimaryProviderPanel')]/div[position()="+position+"]/div/span[contains(@class,'gwt-CheckBox service') and position()=2]/input";
	}

	public String getFX(){
		return "//div[contains(@class,'PrimaryProviderPanel')]/div[position()="+position+"]/div/span[contains(@class,'gwt-CheckBox service') and position()=3]/input";
	}

	public String getIndicationOfInterest(){
		return "//div[contains(@class,'PrimaryProviderPanel')]/div[position()="+position+"]/div/span[contains(@class,'gwt-CheckBox service') and position()=4]/input";
	}

	public String getMacroEconomics(){
		return "//div[contains(@class,'PrimaryProviderPanel')]/div[position()="+position+"]/div/span[contains(@class,'gwt-CheckBox service') and position()=5]/input";
	}

	public String getRates(){
		return "//div[contains(@class,'PrimaryProviderPanel')]/div[position()="+position+"]/div/span[contains(@class,'gwt-CheckBox service') and position()=6]/input";
	}

	public String getAlreadyASubscriber(){
		return "//div[contains(@class,'PrimaryProviderPanel')]/div[position()="+position+"]/div/div/div/span/input";
	}

	public String getName(){
		return "//div[contains(@class,'PrimaryProviderPanel')]/div[position()="+position+"]/div/div/div[position()=2]/input";
	}

	public String getEmail(){
		return "//div[contains(@class,'PrimaryProviderPanel')]/div[position()="+position+"]/div/div/div[position()=3]/input";
	}

	public String getComments(){
		return "//div[contains(@class,'PrimaryProviderPanel')]/div[position()="+position+"]/div/div/div[position()=4]/input";
	}
}
