package com.markit.markithub.test.steps.FullTextSearch;

import com.markit.markithub.test.Data.FullTextSearchLocators;
import com.markit.markithub.test.model.StepBase;

public class HoverOverWhatIsThis extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Hovwe over 'What is this?'";

	public HoverOverWhatIsThis(){
		super(name);
	}

	public void execute() throws Exception{
		super.getSeleniumInstance().mouseOver(FullTextSearchLocators.FILTERBY_WHATISTHIS);
		basic.waitForElementPresent(FullTextSearchLocators.FILTERBY_WHATISTHIS_POPUP,super.getSeleniumInstance());
	}
}
