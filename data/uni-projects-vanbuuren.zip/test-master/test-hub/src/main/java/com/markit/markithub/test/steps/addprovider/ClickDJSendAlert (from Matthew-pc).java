package com.markit.markithub.test.steps.addprovider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.markit.markithub.test.Data.AddProviderLocators;
import com.markit.markithub.test.model.StepBase;
import com.thoughtworks.selenium.SeleniumException;

public class ClickDJSendAlert extends StepBase{

	private static final long serialVersionUID = 1L;
	private static final Logger logger = LoggerFactory.getLogger(ClickDJSendAlert.class);

	public static final String name = "Clicking Send Expecting Error.";

	public ClickDJSendAlert() {
		super(name);
	}

	public void execute() throws Exception{
		try{
			basic.pressButton(AddProviderLocators.DJ_SEND , super.getSeleniumInstance());
		}catch(SeleniumException se){
			logger.info("Squashed Selenium Exception: ",se);
		}
		basic.waitForElementPresent(AddProviderLocators.DJ_ERROR_RED, super.getSeleniumInstance());
	}
}
