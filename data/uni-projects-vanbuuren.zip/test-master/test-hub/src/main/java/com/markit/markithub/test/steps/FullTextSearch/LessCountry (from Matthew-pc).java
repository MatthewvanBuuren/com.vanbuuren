package com.markit.markithub.test.steps.FullTextSearch;

import com.markit.markithub.test.Data.FullTextSearchLocators;
import com.markit.markithub.test.model.StepBase;

public class LessCountry extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Click 'FilterBy', 'Country', 'Less'";

	public LessCountry(){
		super(name);
	}

	public void execute() throws Exception{
		basic.pressButton(FullTextSearchLocators.FILTERBY_COUNTRY_LESS, super.getSeleniumInstance());
		basic.waitForElementPresent(FullTextSearchLocators.FILTERBY_COUNTRY_MORE,super.getSeleniumInstance());
	}
}
