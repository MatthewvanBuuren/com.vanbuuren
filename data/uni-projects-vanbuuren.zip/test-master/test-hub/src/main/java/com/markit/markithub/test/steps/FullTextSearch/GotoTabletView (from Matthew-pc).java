package com.markit.markithub.test.steps.FullTextSearch;

import com.markit.markithub.test.Data.FullTextSearchLocators;
import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.model.StepBase;

public class GotoTabletView extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Go to Tablet View";

	public GotoTabletView(){
		super(name);
	}

	public void execute() throws Exception{
		basic.pressButton(Locators.HEADLINES_TABLET_VIEW, super.getSeleniumInstance());
		basic.waitForEitherElementPresent(Locators.HEADLINES_TABLET_VIEWALL_NUM(1), FullTextSearchLocators.FTS_SEARCH_NORESULT, super.getSeleniumInstance());
	}
}
