package com.markit.markithub.test.steps.addprovider;

import com.markit.markithub.test.Data.AddProviderLocators;
import com.markit.markithub.test.model.StepBase;

public class SuggestAnotherNewProvider extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Suggest 10! Providers";

	public SuggestAnotherNewProvider() {
		super(name);
	}

	public void execute() throws Exception{
		for(int x = 1 ; x<10 ; x++){
			for(int y = 2 ; x+2 > y ; y++){
				basic.typeString(AddProviderLocators.SUGGEST_OTHER_PROVIDER(y), "Test - Provider", super.getSeleniumInstance());
				basic.typeString(AddProviderLocators.SUGGEST_OTHER_URL(y), "Test - Url.com", super.getSeleniumInstance());
			}
			basic.pressButton(AddProviderLocators.SUGGEST_OTHER_PROVIDER, super.getSeleniumInstance());
		}
		basic.pressButtonSlow(AddProviderLocators.ADDPROVIDER_SUBMIT, super.getSeleniumInstance());
	}
}
