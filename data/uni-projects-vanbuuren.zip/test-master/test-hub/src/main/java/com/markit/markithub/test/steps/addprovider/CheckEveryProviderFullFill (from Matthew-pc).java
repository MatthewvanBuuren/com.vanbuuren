package com.markit.markithub.test.steps.addprovider;

import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.Data.PerProviderInfo;
import com.markit.markithub.test.methods.AddProviderCheckBoxLocators;
import com.markit.markithub.test.model.StepBase;

public class CheckEveryProviderFullFill extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Assert all Inactive are present";

	public CheckEveryProviderFullFill() {
		super(name);
	}

	public void execute() throws Exception{
		AddProviderCheckBoxLocators chechBoxLocat= new AddProviderCheckBoxLocators(super.getSeleniumInstance());
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_BAM_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_BAM)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BAM).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BAM).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BAM).getCredit(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BAM).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BAM).getFX(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BAM).getIndicationOfInterest(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BAM).getMacroEconomics(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BAM).getRates(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BAM).getAlreadyASubscriber(), super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BAM).getName(), "Test - Name", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BAM).getEmail(), "Test - Email", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BAM).getComments(), "Test - Comments", super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_BC_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_BC)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BC).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BC).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BC).getCredit(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BC).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BC).getFX(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BC).getIndicationOfInterest(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BC).getMacroEconomics(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BC).getRates(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BC).getAlreadyASubscriber(), super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BC).getName(), "Test - Name", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BC).getEmail(), "Test - Email", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BC).getComments(), "Test - Comments", super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_BNP_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_BNP)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BNP).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BNP).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BNP).getCredit(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BNP).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BNP).getFX(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BNP).getIndicationOfInterest(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BNP).getMacroEconomics(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BNP).getRates(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BNP).getAlreadyASubscriber(), super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BNP).getName(), "Test - Name", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BNP).getEmail(), "Test - Email", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.BNP).getComments(), "Test - Comments", super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_C_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_CS)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.C).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.C).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.C).getCredit(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.C).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.C).getFX(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.C).getIndicationOfInterest(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.C).getMacroEconomics(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.C).getRates(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.C).getAlreadyASubscriber(), super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.C).getName(), "Test - Name", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.C).getEmail(), "Test - Email", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.C).getComments(), "Test - Comments", super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_CS_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_CS)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.CS).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.CS).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.CS).getCredit(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.CS).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.CS).getFX(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.CS).getIndicationOfInterest(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.CS).getMacroEconomics(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.CS).getRates(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.CS).getAlreadyASubscriber(), super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.CS).getName(), "Test - Name", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.CS).getEmail(), "Test - Email", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.CS).getComments(), "Test - Comments", super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_DB_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_DB)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.DB).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.DB).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.DB).getCredit(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.DB).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.DB).getFX(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.DB).getIndicationOfInterest(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.DB).getMacroEconomics(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.DB).getRates(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.DB).getAlreadyASubscriber(), super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.DB).getName(), "Test - Name", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.DB).getEmail(), "Test - Email", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.DB).getComments(), "Test - Comments", super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_GS_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_GS)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.GS).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.GS).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.GS).getCredit(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.GS).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.GS).getFX(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.GS).getIndicationOfInterest(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.GS).getMacroEconomics(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.GS).getRates(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.GS).getAlreadyASubscriber(), super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.GS).getName(), "Test - Name", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.GS).getEmail(), "Test - Email", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.GS).getComments(), "Test - Comments", super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_JPM_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_JPM)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.JPM).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.JPM).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.JPM).getCredit(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.JPM).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.JPM).getFX(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.JPM).getIndicationOfInterest(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.JPM).getMacroEconomics(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.JPM).getRates(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.JPM).getAlreadyASubscriber(), super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.JPM).getName(), "Test - Name", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.JPM).getEmail(), "Test - Email", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.JPM).getComments(), "Test - Comments", super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_MS_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_MS)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MS).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MS).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MS).getCredit(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MS).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MS).getFX(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MS).getIndicationOfInterest(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MS).getMacroEconomics(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MS).getRates(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MS).getAlreadyASubscriber(), super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MS).getName(), "Test - Name", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MS).getEmail(), "Test - Email", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MS).getComments(), "Test - Comments", super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_RBC_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_RBC)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.RBC).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.RBC).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.RBC).getCredit(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.RBC).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.RBC).getFX(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.RBC).getIndicationOfInterest(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.RBC).getMacroEconomics(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.RBC).getRates(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.RBC).getAlreadyASubscriber(), super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.RBC).getName(), "Test - Name", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.RBC).getEmail(), "Test - Email", super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_UBS_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_UBS)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.UBS).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.UBS).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.UBS).getCredit(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.UBS).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.UBS).getFX(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.UBS).getIndicationOfInterest(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.UBS).getMacroEconomics(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.UBS).getRates(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.UBS).getAlreadyASubscriber(), super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.UBS).getName(), "Test - Name", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.UBS).getEmail(), "Test - Email", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.UBS).getComments(), "Test - Comments", super.getSeleniumInstance());
		}
		if(super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_MKT_TAB) && super.getSeleniumInstance().isElementPresent(Locators.PROVIDER_INACTIVE_MKT)){
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MKT).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresentandVisible(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MKT).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MKT).getCredit(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MKT).getEquities(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MKT).getFX(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MKT).getIndicationOfInterest(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MKT).getMacroEconomics(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MKT).getRates(), super.getSeleniumInstance());
			basic.pressButton(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MKT).getAlreadyASubscriber(), super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MKT).getName(), "Test - Name", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MKT).getEmail(), "Test - Email", super.getSeleniumInstance());
			basic.typeString(chechBoxLocat.getCurrentlyAvailableBox(PerProviderInfo.MKT).getComments(), "Test - Comments", super.getSeleniumInstance());
		}
	}
}
