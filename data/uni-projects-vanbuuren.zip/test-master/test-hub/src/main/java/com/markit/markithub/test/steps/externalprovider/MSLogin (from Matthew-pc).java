package com.markit.markithub.test.steps.externalprovider;

import java.io.File;

import com.markit.markithub.test.Data.ExternalProviderLocator;
import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.Data.PerProviderInfo;
import com.markit.markithub.test.model.StepBase;

public class MSLogin extends StepBase {

	private static final long serialVersionUID = 1L;

	public static final String name = "Login to "+PerProviderInfo.MS.fullName;

	public MSLogin() {
		super(name);
	}

	public void execute() throws Exception{
		basic.typeString(ExternalProviderLocator.MS_LOGIN_USERNAME,super.getStorySettings().getUsername(),super.getSeleniumInstance());
		basic.typeString(ExternalProviderLocator.MS_LOGIN_PASSWORD,super.getStorySettings().getPassword(),super.getSeleniumInstance());
		basic.pressButton(ExternalProviderLocator.MS_LOGIN_SUBMIT,super.getSeleniumInstance());
		basic.waitForElementPresent(Locators.BANNER_HEADLINES_BUTTON, super.getSeleniumInstance());
		basic.waitForElementPresent(ExternalProviderLocator.MS_HOMEPAGE_LOAD, super.getSeleniumInstance());
	}

	public void takeScreenshot(String screenshotName, File outputFile){
		basic.takeScreenshot(screenshotName,super.getSeleniumInstance(),outputFile);
	}

	public void teardown() throws RuntimeException {
		super.getSeleniumInstance().selectWindow(null);
		super.getSeleniumInstance().windowFocus();
		super.getSeleniumInstance().windowMaximize();
	}
}
