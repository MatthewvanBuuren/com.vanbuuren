package com.markit.markithub.test.steps.directory;

import com.markit.markithub.test.Data.DirectoryLocators;
import com.markit.markithub.test.model.StepBase;

public class SearchMarioEmail extends StepBase{

	private static final long serialVersionUID = 1L;
	public static final String name = "Search " + DirectoryLocators.DIRECTORY_SEARCH_EMAIL;

	public SearchMarioEmail(){
		super(name);
	}

	public void execute() throws Exception{
		basic.typeString(DirectoryLocators.DIRECTORY_SEARCH_INPUT, DirectoryLocators.DIRECTORY_SEARCH_EMAIL, super.getSeleniumInstance());
		basic.pressButtonSlow(DirectoryLocators.DIRECTORY_SEARCH_BUTTON,super.getSeleniumInstance());
		basic.waitForElementPresent(DirectoryLocators.DIRECTORY_ADVANCED_SEARCH_CONTACT_LIST, super.getSeleniumInstance());
		basic.waitForElementPresent(DirectoryLocators.DIRECTORY_SEARCH_RESULT_EMAIL , super.getSeleniumInstance());
	}
}
