package com.markit.markithub.test.steps.FullTextSearch;

import com.markit.markithub.test.Data.FullTextSearchLocators;
import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.model.StepBase;

public class FilterByUnitedKingdom extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Filter by Country - United Kingdom";

	public FilterByUnitedKingdom(){
		super(name);
	}

	public void execute() throws Exception{
		basic.pressButton(FullTextSearchLocators.FILTERBY_COUNTRY_UNITEDKINGDOM, super.getSeleniumInstance());
		basic.waitForBothElementsPresent(Locators.BANNER_SEARCH_LOADING_RESEARCH_HIDDEN, Locators.BANNER_SEARCH_LOADING_NEWS_HIDDEN, super.getSeleniumInstance());
		basic.waitForElementPresent(FullTextSearchLocators.FILTERBY_COUNTRY_UNITEDKINGDOM_HIGHLIGHTED,super.getSeleniumInstance());
	}
}
