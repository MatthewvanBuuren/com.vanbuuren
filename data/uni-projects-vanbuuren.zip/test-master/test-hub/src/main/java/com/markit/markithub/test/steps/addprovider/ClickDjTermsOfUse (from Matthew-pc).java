package com.markit.markithub.test.steps.addprovider;

import java.io.File;

import com.markit.markithub.test.Data.AddProviderLocators;
import com.markit.markithub.test.model.StepBase;
import com.markit.markithub.test.service.PopupManagement;

public class ClickDjTermsOfUse extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Clicking Cancel.";
	private static final PopupManagement popup = new PopupManagement();

	public ClickDjTermsOfUse() {
		super(name);
	}

	public void execute() throws Exception{
		basic.pressButton(AddProviderLocators.DJ_TERMS_OF_USE , super.getSeleniumInstance());
		super.getSeleniumInstance().selectWindow(AddProviderLocators.DJ_TERMSOFUSE_WINDOW);
		super.getSeleniumInstance().windowFocus();
		super.getSeleniumInstance().windowMaximize();
		//TODO: some Kind of Load Event, Its is a pdf that loads so some kind of pdf loading check
	}

	public void takeScreenshot(String screenshotName, File outputFile){
		basic.takeScreenshot(screenshotName,super.getSeleniumInstance(),outputFile);
	}

	public void teardown() throws RuntimeException{
		super.getSeleniumInstance().selectWindow(null);
		super.getSeleniumInstance().windowFocus();
		popup.closePopup(AddProviderLocators.DJ_TERMSOFUSE_WINDOW);
	}
}
