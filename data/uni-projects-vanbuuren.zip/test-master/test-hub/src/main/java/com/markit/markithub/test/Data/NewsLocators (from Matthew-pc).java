package com.markit.markithub.test.Data;

/**
 * For convenience of not having to hard-code selenium locators everywhere
 * XPath etc.
 */
public class NewsLocators {

	// News
	public static final String NEWS_MAIN_LOADING_HIDDEN = "//div[contains(@style,'display: none') and contains(@class,'loadingNews')]";



}
