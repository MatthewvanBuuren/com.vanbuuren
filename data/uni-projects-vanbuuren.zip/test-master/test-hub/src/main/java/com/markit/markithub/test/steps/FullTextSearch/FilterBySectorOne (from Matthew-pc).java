package com.markit.markithub.test.steps.FullTextSearch;

import com.markit.markithub.test.Data.FullTextSearchLocators;
import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.model.StepBase;

public class FilterBySectorOne extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Filter By Sector One";

	public FilterBySectorOne(){
		super(name);
	}

	public void execute() throws Exception{
		basic.pressButton(FullTextSearchLocators.FILTERBY_SECTOR_ONE, super.getSeleniumInstance());
		basic.waitForBothElementsPresent(Locators.BANNER_SEARCH_LOADING_NEWS_HIDDEN,Locators.BANNER_SEARCH_LOADING_RESEARCH_HIDDEN,super.getSeleniumInstance());
		basic.assertElementPresent(FullTextSearchLocators.FILTERBY_SECTOR_ONE_HIGHLIGHTED, super.getSeleniumInstance());
	}
}
