package com.markit.markithub.test.steps.author;

import com.markit.markithub.test.Data.AuthorLocators;
import com.markit.markithub.test.Data.FullTextSearchLocators;
import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.model.StepBase;

public class ClearAllAuthorSearchTwo extends StepBase{

	private static final long serialVersionUID = 1L;
	public static final String name = "Remove the '"+AuthorLocators.AUTH_SEARCH2_FULL+"' search, By clicking the 'Clear All' TAG.";

	public ClearAllAuthorSearchTwo(){
		super(name);
	}

	public void execute() throws Exception{
		basic.pressButton(FullTextSearchLocators.FTS_TAG_CLEAR, super.getSeleniumInstance());
		basic.waitForBothElementsPresent(Locators.BANNER_SEARCH_LOADING_NEWS_HIDDEN, Locators.BANNER_SEARCH_LOADING_RESEARCH_HIDDEN, super.getSeleniumInstance());
		basic.assertElementNotPresent(AuthorLocators.AUTH_SEARCH_RESULT_FULLNAME2_HIGHLIGHTED, super.getSeleniumInstance());
	}
}
