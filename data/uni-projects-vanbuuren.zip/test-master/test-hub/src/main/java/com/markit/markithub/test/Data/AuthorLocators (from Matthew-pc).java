package com.markit.markithub.test.Data;

/**
 * For convenience of not having to hard-code selenium locators everywhere
 * XPath etc.
 */
public class AuthorLocators {

	//Author Search
	public static final String AUTH_SEARCH_FULL = "Michael Chang";

	public static final String AUTH_SEARCH_1 = AUTH_SEARCH_FULL.substring(0,1);
	public static final String AUTH_SEARCH_2 = AUTH_SEARCH_FULL.substring(0,2);
	public static final String AUTH_SEARCH_3 = AUTH_SEARCH_FULL.substring(0,3);
	public static final String AUTH_SEARCH_4 = AUTH_SEARCH_FULL.substring(0,4);
	public static final String AUTH_SEARCH_5 = AUTH_SEARCH_FULL.substring(0,5);
	public static final String AUTH_SEARCH_6 = AUTH_SEARCH_FULL.substring(0,6);
	public static final String AUTH_SEARCH_7 = AUTH_SEARCH_FULL.substring(0,7);

	public static final String AUTH_SEARCH_11 = AUTH_SEARCH_FULL.substring(0,getLastSpace(AUTH_SEARCH_FULL)+2);

	//2nd Author Search
	public static final String AUTH_SEARCH2_FULL = "Douglas Karson";

	public static final String AUTH_SEARCH2_1 = AUTH_SEARCH2_FULL.substring(getLastSpace(AUTH_SEARCH2_FULL)+1,getLastSpace(AUTH_SEARCH2_FULL)+2);
	public static final String AUTH_SEARCH2_2 = AUTH_SEARCH2_FULL.substring(getLastSpace(AUTH_SEARCH2_FULL)+1,getLastSpace(AUTH_SEARCH2_FULL)+3);
	public static final String AUTH_SEARCH2_3 = AUTH_SEARCH2_FULL.substring(getLastSpace(AUTH_SEARCH2_FULL)+1,getLastSpace(AUTH_SEARCH2_FULL)+4);
	public static final String AUTH_SEARCH2_4 = AUTH_SEARCH2_FULL.substring(0,getLastSpace(AUTH_SEARCH2_FULL)+2);
	public static final String AUTH_SEARCH2_4_FIRSTNAME = AUTH_SEARCH2_FULL.substring(0,getLastSpace(AUTH_SEARCH2_FULL));
	public static final String AUTH_SEARCH2_4_LASTNAME = AUTH_SEARCH2_1;
	public static final String AUTH_SEARCH2_4_NOTBOLD = AUTH_SEARCH2_FULL.substring(getLastSpace(AUTH_SEARCH2_FULL)+2);

	//3rd Author Search
	public static final String AUTH_SEARCH3_FULL = "Bruce Kasman";

	public static final String AUTH_SEARCH3_1 = AUTH_SEARCH3_FULL.substring(getLastSpace(AUTH_SEARCH3_FULL)+1,getLastSpace(AUTH_SEARCH3_FULL)+4);

	//4Th Author Search
	public static final String AUTH_SEARCH4_FULL = "Fritz Engelhard";

	public static final String AUTH_SEARCH4_1 = AUTH_SEARCH4_FULL.substring(0,5);

	//Main Elements
	public static final String AUTH_SEARCH_INPUT  = "//div[contains(@class,'hsTagPanel')]/div[position()=3]/input";
	public static final String AUTH_SEARCH_RESULT_BOLD_TERM(String term){return "//tr[1]/td/b[text()='" + term + "']";};
	public static final String AUTH_SEARCH_RESULT_NOTBOLD_TERM(String term){return "//tr[1]/td[text()='" + term + "']";};
	public static final String AUTH_SEARCH_RESULT_BOLD_LASTNAME = "//tr[position()=1]/td/b[contains(text(),'"+AUTH_SEARCH_FULL.substring(getLastSpace(AUTH_SEARCH_FULL)+1,getLastSpace(AUTH_SEARCH_FULL)+2)+"')]";
	public static final String AUTH_SEARCH_RESULT_FULLNAME = "//tr/td[contains(text(),'"+AUTH_SEARCH_FULL.substring(getLastSpace(AUTH_SEARCH_FULL), AUTH_SEARCH_FULL.length())+"')]";
	public static final String AUTH_SEARCH_RESULT_FULLNAME2 = "//td[contains(.,'"+AUTH_SEARCH2_FULL+"')and contains(@role,'menuitem')]";
	public static final String AUTH_SEARCH_RESULT_FULLNAME3 = "//td[contains(.,'"+AUTH_SEARCH3_FULL+"')and contains(@role,'menuitem')]";
	public static final String AUTH_SEARCH_RESULT_FULLNAME_11 = "//td[contains(@role,'menuitem') and contains(.,'"+AUTH_SEARCH_FULL.substring(getLastSpace(AUTH_SEARCH_FULL)+1, AUTH_SEARCH_FULL.length())+"')]";
	public static final String AUTH_SEARCH_RESULT_FULLNAME_TAG = "//div[contains(@class,'orderedCriteriaWidget') and contains(text(),'"+AUTH_SEARCH_FULL+"')]";
	public static final String AUTH_SEARCH_RESULT_FULLNAME2_TAG = "//div[contains(@class,'orderedCriteriaWidget') and contains(text(),'"+AUTH_SEARCH2_FULL+"')]";
	public static final String AUTH_SEARCH_RESULT_FULLNAME3_TAG = "//div[contains(@class,'orderedCriteriaWidget') and contains(text(),'"+AUTH_SEARCH3_FULL+"')]";

	public static final String AUTH_SEARCH_RESULT_FULLNAME_HIGHLIGHTED = "//div/div[contains(@class,'tagListItem-selected')]/span[contains(text(),'"+AUTH_SEARCH_FULL+"')]";
	public static final String AUTH_SEARCH_RESULT_FULLNAME2_HIGHLIGHTED = "//div/div[contains(@class,'tagListItem-selected')]/span[contains(text(),'"+AUTH_SEARCH2_FULL+"')]";

	//Special Elements
	public static final String AUTH_TABLETVIEW_ELEMENT1_VIEWALL = "//div[contains(@class,'hGroup') and position()=1]/div[contains(@class,'hgMoreLikeThis')]";

	//Private Methods
	private static final int getLastSpace(String strng){
		return strng.lastIndexOf(" ");
	}

}
