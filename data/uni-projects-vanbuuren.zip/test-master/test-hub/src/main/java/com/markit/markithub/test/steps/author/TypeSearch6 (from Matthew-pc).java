package com.markit.markithub.test.steps.author;

import com.markit.markithub.test.Data.AuthorLocators;
import com.markit.markithub.test.model.StepBase;

public class TypeSearch6 extends StepBase{

	private static final long serialVersionUID = 1L;
	public static final String name = "Type '"+AuthorLocators.AUTH_SEARCH_6+"'";

	public TypeSearch6(){
		super(name);
	}

	public void execute() throws Exception{
		basic.typeString(AuthorLocators.AUTH_SEARCH_INPUT, AuthorLocators.AUTH_SEARCH_6, super.getSeleniumInstance());
		basic.waitForElementPresent(AuthorLocators.AUTH_SEARCH_RESULT_BOLD_TERM(AuthorLocators.AUTH_SEARCH_6), super.getSeleniumInstance());
	}
}
