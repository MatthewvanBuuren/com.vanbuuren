package com.markit.markithub.test.steps.FullTextSearch;

import com.markit.markithub.test.Data.FullTextSearchLocators;
import com.markit.markithub.test.model.StepBase;

public class HoverOverFirstResearchResult extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Hover over first result";

	public HoverOverFirstResearchResult(){
		super(name);
	}

	public void execute() throws Exception{
		super.getSeleniumInstance().mouseOver(FullTextSearchLocators.FTS_RESEARCH_RESULT_ONE);
		basic.waitForElementPresent(FullTextSearchLocators.FTS_NEWS_RESULT_ONE_HIGHLIGHTED, super.getSeleniumInstance());
	}
}
