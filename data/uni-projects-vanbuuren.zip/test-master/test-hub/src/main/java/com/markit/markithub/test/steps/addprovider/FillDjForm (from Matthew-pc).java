package com.markit.markithub.test.steps.addprovider;

import com.markit.markithub.test.Data.AddProviderLocators;
import com.markit.markithub.test.model.StepBase;

public class FillDjForm extends StepBase{

	private static final long serialVersionUID = 1L;
	public static final String name = "Fill Dj Form";

	public FillDjForm() {
		super(name);
	}

	public void execute() throws Exception{
			basic.typeString(AddProviderLocators.DJ_FIRSTNAME, "Test - First Name",super.getSeleniumInstance());
			basic.typeString(AddProviderLocators.DJ_COMPANY, "Test - Company", super.getSeleniumInstance());
			basic.typeString(AddProviderLocators.DJ_EMAIL, "Test - Email@Email.com", super.getSeleniumInstance());
			basic.selectDropdown(AddProviderLocators.DJ_BUSINESS_AREA, AddProviderLocators.DJ_BUSINESS_AREA_NAME, super.getSeleniumInstance());
			basic.typeString(AddProviderLocators.DJ_LASTNAME, "Test - Last Name", super.getSeleniumInstance());
			basic.typeString(AddProviderLocators.DJ_JOB_TITLE, "Test - Job Title", super.getSeleniumInstance());
			basic.typeString(AddProviderLocators.DJ_PHONE, "Test - Phone - 000-000-00-000", super.getSeleniumInstance());
			basic.selectDropdown(AddProviderLocators.DJ_COUNTRY, AddProviderLocators.DJ_COUNTRY_NAME, super.getSeleniumInstance());
			basic.pressButton(AddProviderLocators.DJ_BLOOMBERG, super.getSeleniumInstance());
			basic.pressButton(AddProviderLocators.DJ_REUTERS, super.getSeleniumInstance());
			basic.pressButton(AddProviderLocators.DJ_THOMSON, super.getSeleniumInstance());
			basic.pressButton(AddProviderLocators.DJ_FACTSET, super.getSeleniumInstance());
			basic.pressButton(AddProviderLocators.DJ_CAPIQ, super.getSeleniumInstance());
			basic.pressButton(AddProviderLocators.DJ_MARKIT_DESKTOP, super.getSeleniumInstance());
			basic.pressButton(AddProviderLocators.DJ_OTHER, super.getSeleniumInstance());
			basic.typeString(AddProviderLocators.DJ_OTHER_TEXTBOX, "Test - Other", super.getSeleniumInstance());
	}
}
