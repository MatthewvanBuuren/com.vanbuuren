package com.markit.markithub.test.steps.addprovider;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.markit.markithub.test.Data.AddProviderLocators;
import com.markit.markithub.test.Data.Locators;
import com.markit.markithub.test.Data.PerProviderInfo;
import com.markit.markithub.test.methods.AddProviderCheckBoxLocators;
import com.markit.markithub.test.model.StepBase;
import com.thoughtworks.selenium.Selenium;

public class AssertSubscriptionsStored extends StepBase{

	private static final long serialVersionUID = 1L;
	private static final Map<String, String> allSubscribers = new HashMap<String,String>();
	public static final String name = "Assert that the subscription detials are stored.";
	private static final Logger logger = LoggerFactory.getLogger(AssertSubscriptionsStored.class);

	private static final String KEYS_BLOOMBERG = "Bloomberg";
	private static final String KEYS_REUTERS = "Reuters";
	private static final String KEYS_THOMSON = "Thomson";
	private static final String KEYS_FACTSET = "FactSet";
	private static final String KEYS_CAPIQ = "CapIQ";
	private static final String KEYS_MARKIT = "Markit";
	private static final String KEYS_OTHER = "Other";
	private static final String KEYS_OTHERTEXT = "OtherText";
	private static final String KEYS_SIGNUP = "SignUp";
	private static final String KEYS_NOTINTERESTED = "NotInterested";


	public AssertSubscriptionsStored() {
		super(name);
	}

	public void execute() throws Exception{
		AddProviderCheckBoxLocators chechBox = new AddProviderCheckBoxLocators(super.getSeleniumInstance());
		allSubscribers.put(KEYS_BLOOMBERG, isSelected(AddProviderLocators.DJ_BLOOMBERG,super.getSeleniumInstance()));
		allSubscribers.put(KEYS_REUTERS, isSelected(AddProviderLocators.DJ_REUTERS,super.getSeleniumInstance()));
		allSubscribers.put(KEYS_THOMSON, isSelected(AddProviderLocators.DJ_THOMSON,super.getSeleniumInstance()));
		allSubscribers.put(KEYS_FACTSET, isSelected(AddProviderLocators.DJ_FACTSET,super.getSeleniumInstance()));
		allSubscribers.put(KEYS_CAPIQ, isSelected(AddProviderLocators.DJ_CAPIQ,super.getSeleniumInstance()));
		allSubscribers.put(KEYS_MARKIT, isSelected(AddProviderLocators.DJ_MARKIT_DESKTOP,super.getSeleniumInstance()));
		allSubscribers.put(KEYS_OTHER, isSelected(AddProviderLocators.DJ_OTHER,super.getSeleniumInstance()));
		if(super.getSeleniumInstance().isChecked(AddProviderLocators.DJ_OTHER)){
			allSubscribers.put(KEYS_OTHERTEXT, super.getSeleniumInstance().getValue(AddProviderLocators.DJ_OTHER_TEXTBOX).toString());
		}else{
			allSubscribers.put(KEYS_OTHERTEXT, " ");
		}
		allSubscribers.put(KEYS_SIGNUP, isSelected(AddProviderLocators.DJ_SIGNUP,super.getSeleniumInstance()));
		allSubscribers.put(KEYS_NOTINTERESTED, isSelected(AddProviderLocators.DJ_NOT_INTERESTED,super.getSeleniumInstance()));

		if(!super.getSeleniumInstance().isChecked(AddProviderLocators.DJ_CAPIQ)){
			basic.pressButton(AddProviderLocators.DJ_CAPIQ,super.getSeleniumInstance());
		}
		if(!super.getSeleniumInstance().isChecked(AddProviderLocators.DJ_MARKIT_DESKTOP)){
			basic.pressButton(AddProviderLocators.DJ_MARKIT_DESKTOP,super.getSeleniumInstance());
		}
		if(!super.getSeleniumInstance().isChecked(AddProviderLocators.DJ_OTHER)){
			basic.pressButton(AddProviderLocators.DJ_OTHER,super.getSeleniumInstance());
		}
		basic.typeString(AddProviderLocators.DJ_OTHER_TEXTBOX, "Test - Other", super.getSeleniumInstance());

		basic.pressButton(AddProviderLocators.DJ_SEND, super.getSeleniumInstance());
		basic.waitForElementPresent(Locators.BANNER_SEARCH_LOADING_RESEARCH_HIDDEN, super.getSeleniumInstance());
		basic.pressButtonSlow(Locators.BANNER_ADDPROVIDER, super.getSeleniumInstance());
		basic.waitForElementPresent(AddProviderLocators.ADDPROVIDER_SUBMIT, super.getSeleniumInstance());
		basic.pressButton(chechBox.getCurrentlyAvailableBox(PerProviderInfo.DJ).getMainCheckbox(), super.getSeleniumInstance());
		basic.waitForElementPresent(AddProviderLocators.DJ_OTHER, super.getSeleniumInstance());

		basic.assertElementSelected(AddProviderLocators.DJ_CAPIQ, super.getSeleniumInstance());
		basic.assertElementSelected(AddProviderLocators.DJ_MARKIT_DESKTOP, super.getSeleniumInstance());
		basic.assertElementSelected(AddProviderLocators.DJ_OTHER, super.getSeleniumInstance());
		basic.assertText(AddProviderLocators.DJ_OTHER_TEXTBOX, "Test - Other", super.getSeleniumInstance());
	}

	public void teardown()throws RuntimeException{
		try{
			AddProviderCheckBoxLocators chechBox = new AddProviderCheckBoxLocators(super.getSeleniumInstance());
			super.getSeleniumInstance().open(super.getStorySettings().getUrl());
			basic.waitForElementPresent(Locators.LOGIN_SUBMIT, super.getSeleniumInstance());
			basic.typeString(Locators.LOGIN_USERNAME, super.getStorySettings().getUsername(), super.getSeleniumInstance());
			basic.typeString(Locators.LOGIN_PASSWORD, super.getStorySettings().getPassword(), super.getSeleniumInstance());
			basic.pressButton(Locators.LOGIN_SUBMIT, super.getSeleniumInstance());
			basic.waitForElementPresent(Locators.BANNER_SEARCH_LOADING_RESEARCH_HIDDEN, super.getSeleniumInstance());
			basic.pressButtonSlow(Locators.BANNER_ADDPROVIDER, super.getSeleniumInstance());
			basic.waitForElementPresent(AddProviderLocators.ADDPROVIDER_MAIN_LOAD, super.getSeleniumInstance());
			basic.pressButton(chechBox.getCurrentlyAvailableBox(PerProviderInfo.DJ).getMainCheckbox(), super.getSeleniumInstance());
			basic.waitForElementPresent(AddProviderLocators.DJ_OTHER, super.getSeleniumInstance());

			returnState(AddProviderLocators.DJ_BLOOMBERG, allSubscribers.get(KEYS_BLOOMBERG), super.getSeleniumInstance());
			returnState(AddProviderLocators.DJ_REUTERS, allSubscribers.get(KEYS_REUTERS), super.getSeleniumInstance());
			returnState(AddProviderLocators.DJ_THOMSON, allSubscribers.get(KEYS_THOMSON), super.getSeleniumInstance());
			returnState(AddProviderLocators.DJ_FACTSET, allSubscribers.get(KEYS_FACTSET), super.getSeleniumInstance());
			returnState(AddProviderLocators.DJ_CAPIQ, allSubscribers.get(KEYS_CAPIQ), super.getSeleniumInstance());
			returnState(AddProviderLocators.DJ_MARKIT_DESKTOP, allSubscribers.get(KEYS_MARKIT), super.getSeleniumInstance());
			returnState(AddProviderLocators.DJ_OTHER, allSubscribers.get(KEYS_OTHER), super.getSeleniumInstance());
			basic.typeString(AddProviderLocators.DJ_OTHER_TEXTBOX , allSubscribers.get(KEYS_OTHERTEXT), super.getSeleniumInstance());
			returnState(AddProviderLocators.DJ_SIGNUP, allSubscribers.get(KEYS_SIGNUP), super.getSeleniumInstance());
			returnState(AddProviderLocators.DJ_NOT_INTERESTED, allSubscribers.get(KEYS_NOTINTERESTED), super.getSeleniumInstance());
			basic.pressButton(AddProviderLocators.DJ_SEND, super.getSeleniumInstance());
		}catch(Exception e){
			logger.error("Error restoring detials, ",e);
		}
	}

	private String isSelected(String locator,Selenium selenium){
		if(selenium.isChecked(locator)){
		return "Y";
		}
		return "N";
	}

	private void returnState(String locator, String prev, Selenium selenium) throws Exception{
		if(prev.equals("Y")){
			if(isSelected(locator,super.getSeleniumInstance()).equals("N")){
				basic.pressButton(locator, super.getSeleniumInstance());
			}
		}else {
			if(isSelected(locator,super.getSeleniumInstance()).equals("Y")){
				basic.pressButton(locator, super.getSeleniumInstance());
			}
		}
	}
}
