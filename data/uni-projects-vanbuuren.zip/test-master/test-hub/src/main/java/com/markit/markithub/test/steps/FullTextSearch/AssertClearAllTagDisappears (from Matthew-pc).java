package com.markit.markithub.test.steps.FullTextSearch;

import com.markit.markithub.test.Data.FullTextSearchLocators;
import com.markit.markithub.test.model.StepBase;

public class AssertClearAllTagDisappears extends StepBase{

	private static final long serialVersionUID = 1L;

	public static final String name = "Assert the 'Clear All' tab disappears.";

	public AssertClearAllTagDisappears(){
		super(name);
	}

	public void execute() throws Exception{
		basic.assertElementPresent(FullTextSearchLocators.FTS_TAG_CLEAR_HIDDEN, super.getSeleniumInstance());
	}
}
